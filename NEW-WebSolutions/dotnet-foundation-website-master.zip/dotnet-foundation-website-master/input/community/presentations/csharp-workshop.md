﻿---
type: workshop
id: csharp-workshop
title: C# 9 Workshop
repo: dotnet-presentations/csharp-workshop
link: https://github.com/dotnet-presentations/csharp-workshop
---

Are you ready to get started with C# 9? This 2 hour introductory C# workshop will take you through everything you need to know to use the latest and greatest features of C#.
