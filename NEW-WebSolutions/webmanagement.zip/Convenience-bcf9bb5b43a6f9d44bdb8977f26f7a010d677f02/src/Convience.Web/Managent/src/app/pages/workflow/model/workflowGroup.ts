export class WorkFlowGroup {
    id?: number;
    upId?: string;
    name?: string;
    sort?: number;
}