---
Title: David Babayan
Pronouns: he/him
Location: Yerevan, Armenia
Email: me@davidbabayan.com
Language:
  - Armenian
  - English
  - Russian
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - Blazor
  - C#
  - Microsoft 365
  - Microsoft Graph
  - Microsoft Teams
  - Product Management
  - Razor
  - Serverless
  - Visual Studio Code
  - Windows Development
Blog: http://davidbabayan.com/blog
Twitter: https://twitter.com/davidbabayan4
GitHub: https://github.com/davidbabayan
LinkedIn: https://linkedin.com/in/david-babayan
Twitch: https://twitch.tv/davidbabayan4
YouTube: https://www.youtube.com/channel/UCQu1RdagZCEiPbwbC9lIQvg
Instagram: https://instagram.com/davidbabayan
Mentor: true
Mentee: true
---
Senior Product and Marketing Manager with 6+ year experience. Software developer with 8+ years of experience. Strategic Marketer with extansive experience in IT industry.

- Ourcome-Driven Innovation evangelist.
- JavaScript and C# ninja.
- PowerApps fun and developer #PowerAddicted
- Microsoft Flow developer #FlowAddicted

Ex-Microsoft Lumia Representative in Armenia!

4 years of teaching at universities. 

Product Panagement, Project Management, Business Manangement, Programming and Leadership trainer. Business mentor and Agile coach. 

200+ trainings and lectures around the world.
