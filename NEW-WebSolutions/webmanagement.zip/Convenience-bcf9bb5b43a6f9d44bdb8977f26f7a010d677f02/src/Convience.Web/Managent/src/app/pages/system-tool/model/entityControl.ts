export class EntityControl {

    constructor(
        public id: number,
        public property: string,
        public type: string,
        public length: string,
        public isRequired: string) { }
}