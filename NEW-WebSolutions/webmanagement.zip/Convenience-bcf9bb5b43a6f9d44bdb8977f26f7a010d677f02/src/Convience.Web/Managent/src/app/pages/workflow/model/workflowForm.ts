export class WorkFlowForm{
    height?:number;
    width?:number;
    background?:string;
}