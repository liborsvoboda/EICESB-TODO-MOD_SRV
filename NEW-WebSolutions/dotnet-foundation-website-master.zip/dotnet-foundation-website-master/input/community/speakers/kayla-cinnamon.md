Title: Kayla Cinnamon
Location: Redmond, Washington
Email: cinnamon@microsoft.com
Language:
  - English
Topics:
  - Open Source
  - Product Management
  - Windows Development
Blog: https://devblogs.microsoft.com/commandline/author/cinnamonmicrosoft-com/
Feed: https://devblogs.microsoft.com/commandline/author/cinnamon@microsoft.com/feed/
Twitter: https://twitter.com/cinnamon_msft
GitHub: https://github.com/cinnamon-msft
LinkedIn: https://www.linkedin.com/in/kaylacinnamon/
Instagram: https://www.instagram.com/kayla_cinnamon/
Mentor: true
Mentee: true
---
Hey! I'm Kayla Cinnamon and I am a Program Manager at Microsoft, currently delivering [Windows Terminal](https://aka.ms/terminal) and [Cascadia Code](https://github.com/microsoft/cascadia-code).

I recently graduated with my master's degree in human-computer interaction and I have a background in software engineering and user interface design.

Some of my favorite hobbies include playing board games, cooking, and watching hockey.

Feel free to reach out to me on [Twitter](https://twitter.com/cinnamon_msft) if you'd like to chat!
