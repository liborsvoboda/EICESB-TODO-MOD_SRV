﻿namespace DatabaseManager.Model
{
    public class TableRecordCount
    {
        public string TableName { get; set; }
        public int RecordCount { get; set; }
    }
}
