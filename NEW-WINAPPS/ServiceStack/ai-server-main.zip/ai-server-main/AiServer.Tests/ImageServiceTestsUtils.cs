using ServiceStack;

namespace AiServer.Tests;

public partial class ImageIntegrationTests
{
    public JsonApiClient CreateClient()
    {
        ConfigureSecrets.ApplySecrets();
        var client = TestUtils.CreateAdminClient();
        var bearerToken = client.BearerToken;
        // Ignore local SSL Errors
        var handler = HttpUtils.HttpClientHandlerFactory();
        handler.ServerCertificateCustomValidationCallback = (httpRequestMessage, cert, cetChain, policyErrors) => true;
        var httpClient = new HttpClient(handler, disposeHandler:client.HttpMessageHandler == null) {
            BaseAddress = new Uri(client.BaseUri),
        };
        httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");
        client = new JsonApiClient(httpClient);
        return client;
    }

    private ConfigureSecrets ConfigureSecrets = new();
}