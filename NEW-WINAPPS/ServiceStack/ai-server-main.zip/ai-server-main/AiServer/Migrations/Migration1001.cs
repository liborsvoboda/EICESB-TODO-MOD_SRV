using AiServer.ServiceModel;
using ServiceStack.DataAnnotations;
using ServiceStack.OrmLite;
using ServiceStack.Text;

namespace AiServer.Migrations;

public class Migration1001 : MigrationBase
{
    /// <summary>
    ///  An API Provider that can process tasks
    /// </summary>
    public class ApiProvider
    {
        [AutoIncrement]
        public int Id { get; set; }
            
        /// <summary>
        /// The unique name for this API Provider
        /// </summary>
        [Index(Unique = true)]
        public string Name { get; set; }
            
        /// <summary>
        /// The behavior for this API Provider
        /// </summary>
        public int ApiTypeId { get; set; }
            
        /// <summary>
        /// The Environment Variable for the API Key to use for this Provider
        /// </summary>
        public string? ApiKeyVar { get; set; }

        /// <summary>
        /// The API Key to use for this Provider
        /// </summary>
        public string? ApiKey { get; set; }
        
        /// <summary>
        /// Send the API Key in the Header instead of Authorization Bearer
        /// </summary>
        public string? ApiKeyHeader { get; set; }
            
        /// <summary>
        /// Override Base URL for the API Provider
        /// </summary>
        public string? ApiBaseUrl { get; set; }
            
        /// <summary>
        /// Url to check if the API is online
        /// </summary>
        public string? HeartbeatUrl { get; set; }
            
        /// <summary>
        /// How many requests should be made concurrently
        /// </summary>
        public int Concurrency { get; set; }
            
        /// <summary>
        /// What priority to give this Provider to use for processing models 
        /// </summary>
        public int Priority { get; set; }
            
        /// <summary>
        /// Whether the Provider is enabled
        /// </summary>
        public bool Enabled { get; set; }
        
        /// <summary>
        /// When the Provider went offline
        /// </summary>
        public DateTime? OfflineDate { get; set; }
            
        /// <summary>
        /// When the Provider was created
        /// </summary>
        public DateTime CreatedDate { get; set; }
            
        /// <summary>
        /// The models this API Provider should process 
        /// </summary>
        public List<ApiProviderModel> Models { get; set; } = [];

        [Reference]
        public ApiType ApiType { get; set; }
    }

    /// <summary>
    /// The models this API Provider can process 
    /// </summary>
    public class ApiProviderModel
    {
        /// <summary>
        /// Ollama Model Id
        /// </summary>
        public string Model { get; set; }
        
        /// <summary>
        /// What Model to use for this API Provider
        /// </summary>
        public string? ApiModel { get; set; }
    }

    public enum AiProvider
    {
        OpenAiProvider,
        GoogleAiProvider,
    }
    /// <summary>
    /// The behavior of the API Provider
    /// </summary>
    public class ApiType
    {
        [AutoIncrement]
        public int Id { get; set; }

        /// <summary>
        /// The AI Provider to process AI Requests
        /// </summary>
        public AiProvider Provider { get; set; }
        
        /// <summary>
        /// Name for this API Provider Type
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// The website for this provider
        /// </summary>
        public string Website { get; set; }
        
        /// <summary>
        /// The API Base Url
        /// </summary>
        public string ApiBaseUrl { get; set; }
        
        /// <summary>
        /// Url to check if the API is online
        /// </summary>
        public string? HeartbeatUrl { get; set; }
        
        /// <summary>
        /// Icon Path or URL
        /// </summary>
        public string? Icon { get; set; }

        /// <summary>
        /// Mapping of Ollama Models to API Models
        /// </summary>
        public Dictionary<string, string> ApiModels { get; set; } = new();
    }

    /// <summary>
    /// Different Models available for the API 
    /// </summary>
    public class AiModel
    {
        [AutoIncrement]
        public int Id { get; set; }
        [Index(Unique = true)]
        public string Name { get; set; }
        public List<string> Tags { get; set; } = [];
        public string? Latest { get; set; }
        public string? Website { get; set; }
        public string? Description { get; set; }
        public string? Icon { get; set; }
    }
    public class ChatSummary
    {
        /// <summary>
        /// Same as BackgroundJob.Id
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// User specified or System Generated BackgroundJob.RefId
        /// </summary>
        [Index(Unique = true)] public string RefId { get; set; }
        
        /// <summary>
        /// The model to use for the Task
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// The model used in the API
        /// </summary>
        public string ApiModel { get; set; }

        /// <summary>
        /// The specific provider used to complete the Task
        /// </summary>
        public string Provider { get; set; }

        /// <summary>
        /// Optional Tag to group related Tasks
        /// </summary>
        public string? Tag { get; set; }
        
        /// <summary>
        /// Number of tokens in the prompt.
        /// </summary>
        public int PromptTokens { get; set; }
        
        /// <summary>
        /// Number of tokens in the generated completion.
        /// </summary>
        public int CompletionTokens { get; set; }

        /// <summary>
        /// The duration reported by the worker to complete the task
        /// </summary>
        public int DurationMs { get; set; }

        /// <summary>
        /// The Month DB the Task was created in
        /// </summary>
        public DateTime CreatedDate { get; set; }
    }

    public override void Up()
    {
        Db.CreateTable<AiModel>();
        Db.CreateTable<ApiType>();
        Db.CreateTable<ApiProvider>();
        Db.CreateTable<ChatSummary>();

        var apiModels = File.ReadAllText("seed/ai-models.json").FromJson<List<AiModel>>();
        Db.InsertAll(apiModels);

        var apiTypes = File.ReadAllText("seed/api-types.json").FromJson<List<ApiType>>();
        Db.InsertAll(apiTypes);

        var now = DateTime.UtcNow;
        var apiProviders = File.ReadAllText("seed/api-providers.json").FromJson<List<ApiProvider>>();
        foreach (var apiProvider in apiProviders)
        {
            var apiKey = apiProvider.ApiKeyVar != null
                ? Environment.GetEnvironmentVariable(apiProvider.ApiKeyVar)
                : null;
            if (apiProvider.ApiKeyVar == null || apiKey != null)
            {
                if (apiKey != null)
                {
                    apiProvider.ApiKey = apiKey;
                    Console.WriteLine($"Found API Key for {apiProvider.ApiKeyVar}");
                }
                apiProvider.CreatedDate = now;
                Console.WriteLine($"Adding {apiProvider.Name} API Provider...");
                Db.Insert(apiProvider);
            }
        }
    }

    public override void Down()
    {
        Db.DropTable<ChatSummary>();
        Db.DropTable<ApiProvider>();
        Db.DropTable<ApiType>();
        Db.DropTable<AiModel>();
    }
}
