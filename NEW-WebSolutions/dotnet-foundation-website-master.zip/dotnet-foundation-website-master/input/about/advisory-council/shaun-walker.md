---
title: Shaun Walker (Chair)
image: shaun-walker.jpg
order: 1
twitter: sbwalker
company: Technical Director and Enterprise Guildmaster at Cognizant Softvision
location: United States
advisor: true
---

Software Architect. Ex-Project leader for DotNetNuke open source product and ecosystem.