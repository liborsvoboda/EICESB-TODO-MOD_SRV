---
Title: Erik Schierboom
Location: Gelderland, The Netherlands
Email: erik_schierboom@hotmail.com
Language:
  - English
  - Dutch
Topics:
  - .NET
  - C#
  - F#
Blog: https://www.erikschierboom.com/
Feed: https://www.erikschierboom.com/posts/index.xml
Twitter: https://twitter.com/ErikSchierboom
GitHub: https://github.com/erikschierboom
StackOverflow: https://stackoverflow.com/users/2071395/erik-schierboom
LinkedIn: https://www.linkedin.com/in/erikschierboom/
---
Having a passion for sharing knowledge, I've spoken at conferences, meetups and various companies. I've presented on a variety of topics, such as C#, F#, functional programming, Roslyn and Exercism. I'm always keen on learning new things and share that knowledge.
