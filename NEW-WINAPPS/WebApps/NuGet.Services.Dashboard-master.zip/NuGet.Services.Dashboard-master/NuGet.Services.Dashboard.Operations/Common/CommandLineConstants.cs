﻿namespace NuGet.Common
{
    internal static class CommandLineConstants
    {
        internal static string ReferencePage = "https://github.com/NuGet/NuGetOperations";
    }
}
