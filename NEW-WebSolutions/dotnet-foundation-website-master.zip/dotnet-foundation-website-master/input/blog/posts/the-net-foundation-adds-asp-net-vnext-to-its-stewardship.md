---
Title: The .NET Foundation Adds ASP.NET vNext to its Stewardship
Author: 
Published: 2014-05-12 17:08:00.0000000
---
<p>The .NET Foundation is pleased to announce the addition of <a href="http://www.asp.net/vnext">ASP.NET vNext</a> to our stewardship. For more information on this early version of ASP.NET vNext that is optimized for mobile-first and cloud-first development, see <a href="http://blogs.msdn.com/b/dotnet/archive/2014/05/12/the-next-generation-of-net-asp-net-vnext.aspx">The Next Generation of .NET &ndash; ASP.NET vNext</a> on the NET Framework Blog.</p>
