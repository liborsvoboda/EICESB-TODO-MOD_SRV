---
title: Irina Scurtu
image: irina-scurtu.jpg
twitter: irina_scurtu
location: Romania
company: Endava
---

