---
Title: Luis Beltran
Location: Zlín, Czech Republic
Email: luis@luisbeltran.mx
Language:
  - English
  - Spanish
Topics:
  - .NET
  - Android
  - ASP.NET Web API
  - Artificial Intelligence
  - Azure
  - C#
  - Entity Framework
  - iOS
  - Machine Learning
  - ML.NET
  - Mobile Development
  - Serverless
  - UWP
  - Xamarin
  - Xamarin.Forms
Blog: https://luisbeltran.mx/
Feed: https://www.luisbeltran.mx/feed/
Twitter: https://twitter.com/darkicebeam
GitHub: https://github.com/icebeam7
StackOverflow: https://stackoverflow.com/users/5065137/luis-beltran
LinkedIn: https://www.linkedin.com/in/luisantoniobeltran
Twitch: https://www.twitch.tv/luisbeltran7
Sessionize: https://sessionize.com/luis-beltran/
MeetUp: https://www.meetup.com/CelayaMobileDevelopers/
YouTube: https://www.youtube.com/darkicebeam
Instagram: https://instagram.com/icebeam7
Dev: https://dev.to/icebeam7/
Mentor: true
---
I enjoy sharing my knowledge with others, either at writing a blog post or streaming an online session. Of course, activities such as talking for a conference and answering peeps' questions in social networks are included as well.
