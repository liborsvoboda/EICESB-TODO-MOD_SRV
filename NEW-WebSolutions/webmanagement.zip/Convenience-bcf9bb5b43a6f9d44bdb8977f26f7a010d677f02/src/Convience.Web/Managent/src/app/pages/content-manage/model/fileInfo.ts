export class FileInfo {
    fileName: string;
    directory: string;
    size: number;
    createTime: Date;
    isDirectory: boolean;
}