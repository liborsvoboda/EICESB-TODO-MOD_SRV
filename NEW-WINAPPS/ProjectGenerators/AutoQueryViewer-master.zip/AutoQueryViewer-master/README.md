# [AutoQuery Viewer](https://github.com/ServiceStackApps/AutoQueryViewer) Backend
Back-end services used by [AutoQuery Viewer](https://github.com/ServiceStackApps/AutoQueryViewer)
