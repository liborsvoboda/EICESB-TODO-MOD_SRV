﻿---
type: deck
id: what-is-net
title: What is .NET?
link: https://github.com/dotnet-presentations/home/tree/master/.NET%20Intro
---

Level 100 Beginner 45min presentation on what .NET is and how to get started!