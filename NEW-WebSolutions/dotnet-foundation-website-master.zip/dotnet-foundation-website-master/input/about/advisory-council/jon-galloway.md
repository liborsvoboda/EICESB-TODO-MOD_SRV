---
title: Jon Galloway
image: jon-galloway.png
order: 2
twitter: jongalloway
location: United States
company: Program Manager at Microsoft
advisor: true
---

I'm **Jon Galloway**, former Executive Director.
