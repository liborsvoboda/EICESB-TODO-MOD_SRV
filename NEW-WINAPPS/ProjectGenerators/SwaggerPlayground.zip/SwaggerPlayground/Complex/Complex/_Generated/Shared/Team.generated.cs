namespace ComplexApp.Complex
{
public enum Team {
    Aog,
    Au,
    Afs,
    Cgs,
    Cpp,
    Egc,
    Fea,
    Hl,
    Sbr,
    Uosp,
    Vt,
    }
}





