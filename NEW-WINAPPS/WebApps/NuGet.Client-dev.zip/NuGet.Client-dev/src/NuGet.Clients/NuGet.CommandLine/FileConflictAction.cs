
namespace NuGet.CommandLine
{
    public enum FileConflictAction
    {
        None,
        Overwrite,
        Ignore
    }
}
