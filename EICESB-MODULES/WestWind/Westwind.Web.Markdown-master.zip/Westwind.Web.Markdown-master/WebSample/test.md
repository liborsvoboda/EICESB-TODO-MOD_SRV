﻿# Markdown File

This is a test page.

* Item 1 
* Item 2
* Item 3

> Items are closer than they appear

## Code Snippets
You can write fenced code snippets that contain syntax colored source code.

```csharp
int x = 1;
x++;
return x;
```



