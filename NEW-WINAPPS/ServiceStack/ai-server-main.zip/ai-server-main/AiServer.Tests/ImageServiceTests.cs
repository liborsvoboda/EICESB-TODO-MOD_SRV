using AiServer.ServiceInterface;
using AiServer.ServiceModel;
using NUnit.Framework;
using ServiceStack;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Formats.Png;

namespace AiServer.Tests;

[Explicit("Integration tests require a running service")]
public partial class ImageIntegrationTests
{
    [Test]
    public async Task Can_convert_image_to_png()
    {
        var client = CreateClient();

        Stream response = null;
        try
        {
            await using var imageStream = File.OpenRead("files/test_image.jpg");
            response = client.PostFilesWithRequest<Stream>(new ConvertImage
            {
                OutputFormat = "png"
            }, [
                new UploadFile("image.png", imageStream) { FieldName = "image"}
            ]);
        }
        catch (Exception e)
        {
            Assert.Fail(e.Message);
        }

        Assert.That(response, Is.Not.Null);
        Assert.That(response.Length, Is.GreaterThan(0));
        
        using var outputImage = await Image.LoadAsync(response);
        
        Assert.That(outputImage.Width, Is.GreaterThan(0));
        Assert.That(outputImage.Height, Is.GreaterThan(0));
        Assert.That(outputImage.Metadata.DecodedImageFormat, Is.EqualTo(PngFormat.Instance));
    }

    [Test]
    public async Task Can_convert_image_to_jpeg()
    {
        var client = CreateClient();

        Stream response = null;
        try
        {
            await using var imageStream = File.OpenRead("files/comfyui_upload_test.png");
            response = client.PostFilesWithRequest<Stream>(new ConvertImage
            {
                OutputFormat = "jpeg"
            }, [
                new UploadFile("image.jpg", imageStream) { FieldName = "image"}
            ]);
        }
        catch (Exception e)
        {
            Assert.Fail(e.Message);
        }

        Assert.That(response, Is.Not.Null);
        Assert.That(response.Length, Is.GreaterThan(0));
        
        using var outputImage = await Image.LoadAsync(response);
        
        Assert.That(outputImage.Width, Is.GreaterThan(0));
        Assert.That(outputImage.Height, Is.GreaterThan(0));
        Assert.That(outputImage.Metadata.DecodedImageFormat, Is.EqualTo(JpegFormat.Instance));
    }

    [Test]
    public async Task Cannot_convert_image_with_invalid_format()
    {
        var client = CreateClient();

        WebServiceException exception = null;
        try
        {
            await using var imageStream = File.OpenRead("files/comfyui_upload_test.png");
            var response = client.PostFilesWithRequest<Stream>(new ConvertImage
            {
                OutputFormat = "invalid"
            }, [
                new UploadFile("image.jpg", imageStream) { FieldName = "image"}
            ]);
        }
        catch (WebServiceException e)
        {
            exception = e;
        }

        Assert.That(exception, Is.Not.Null);
        Assert.That(exception.StatusCode, Is.EqualTo(400));
        Assert.That(exception.ErrorMessage, Does.Contain("Unsupported format"));
    }
    
    [Test]
    public async Task Cannot_crop_image_with_invalid_dimensions()
    {
        var client = CreateClient();

        WebServiceException exception = null;
        try
        {
            await using var imageStream = File.OpenRead("files/test_image.jpg");
            var response = client.PostFilesWithRequest<Stream>(new CropImage
            {
                X = -10,
                Y = -10,
                Width = 10000,
                Height = 10000
            }, [
                new UploadFile("image.jpg", imageStream) { FieldName = "image" }
            ]);
        }
        catch (WebServiceException e)
        {
            exception = e;
        }

        Assert.That(exception, Is.Not.Null);
        Assert.That(exception.StatusCode, Is.EqualTo((int)HttpStatusCode.BadRequest));
        Assert.That(exception.ErrorMessage, Does.Contain("Crop rectangle should be smaller"));
    }

    [Test]
    public async Task Can_crop_image()
    {
        var client = CreateClient();
        
        await using var imageStream = File.OpenRead("files/comfyui_upload_test.png");
        var response = client.PostFilesWithRequest<Stream>(new CropImage
        {
            X = 10,
            Y = 10,
            Width = 100,
            Height = 100
        }, [
            new UploadFile("image.png", imageStream) { FieldName = "image" }
        ]);
        
        Assert.That(response, Is.Not.Null);
        var stream = response;
        Assert.That(stream.Length, Is.GreaterThan(0));
        
        using var outputImage = await Image.LoadAsync(stream);
        
        Assert.That(outputImage.Width, Is.EqualTo(100));
        Assert.That(outputImage.Height, Is.EqualTo(100));
    }
    
    [Test]
    public async Task Can_apply_image_watermark()
    {
        var client = CreateClient();

        Stream response = null;
        try
        {
            await using var imageStream = File.OpenRead("files/test_image.jpg");
            await using var watermarkStream = File.OpenRead("files/watermark_image.png");
            response = client.PostFilesWithRequest<Stream>(new WatermarkImage
            {
                Position = WatermarkPosition.BottomRight,
                Opacity = 0.7f
            }, [
                new UploadFile("image.jpg", imageStream) { FieldName = "image" },
                new UploadFile("watermark.png", watermarkStream) { FieldName = "watermark" }
            ]);
        }
        catch (Exception e)
        {
            Assert.Fail(e.Message);
        }

        Assert.That(response, Is.Not.Null);
        Assert.That(response.Length, Is.GreaterThan(0));

        using var outputImage = await Image.LoadAsync(response);
        
        Assert.That(outputImage.Width, Is.GreaterThan(0));
        Assert.That(outputImage.Height, Is.GreaterThan(0));
        
        outputImage.Save("files/output_image.jpg");
    }

    [Test]
    public async Task Cannot_apply_image_watermark_without_watermark_file()
    {
        var client = CreateClient();

        WebServiceException exception = null;
        try
        {
            await using var imageStream = File.OpenRead("files/test_image.jpg");
            var response = client.PostFilesWithRequest<Stream>(new WatermarkImage
            {
                Position = WatermarkPosition.Center,
                Opacity = 0.5f
            }, [
                new UploadFile("image.jpg", imageStream) { FieldName = "image" }
            ]);
        }
        catch (WebServiceException e)
        {
            exception = e;
        }

        Assert.That(exception, Is.Not.Null);
        Assert.That(exception.StatusCode, Is.EqualTo((int)HttpStatusCode.BadRequest));
        Assert.That(exception.ErrorMessage, Does.Contain("No watermark image file provided"));
    }
}