﻿namespace  DatabaseInterpreter.Core
{
    public interface IDbProvider
    {
        string ProviderName { get; }
    }
}
