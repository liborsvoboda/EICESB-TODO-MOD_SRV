﻿namespace SqlAnalyser.Model
{
    public class PrintStatement : Statement
    {
        public TokenInfo Content { get; set; }
    }
}
