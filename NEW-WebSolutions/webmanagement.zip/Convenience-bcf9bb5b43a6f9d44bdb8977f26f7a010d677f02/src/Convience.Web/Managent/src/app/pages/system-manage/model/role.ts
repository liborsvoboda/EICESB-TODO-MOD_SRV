export class Role{
    id?:string;
    name?:string;
    remark?:string;
    menus?:string;
}