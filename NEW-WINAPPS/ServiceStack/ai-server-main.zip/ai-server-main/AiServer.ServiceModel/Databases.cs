using ServiceStack;

namespace AiServer.ServiceModel;

public class Databases
{
    public const string App = Workers.AppDb;
    public const string Jobs = Workers.JobsDb;
}
