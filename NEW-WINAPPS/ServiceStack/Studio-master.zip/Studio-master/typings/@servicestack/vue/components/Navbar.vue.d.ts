import { NavBase } from '../core';
export declare class Navbar extends NavBase {
    protected readonly opt: any;
}
export default Navbar;
