---
Title: Greg Shackles
Pronouns: he/him
Location: Los Angeles, CA
Email: greg@gregshackles.com
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - AWS
  - C#
  - F#
  - Xamarin
Blog: https://gregshackles.com/
Feed: https://gregshackles.com/rss/
Twitter: https://twitter.com/gshackles
GitHub: https://github.com/gshackles
StackOverflow: https://stackoverflow.com/users/170333/greg-shackles
LinkedIn: https://www.linkedin.com/in/gshackles/
MeetUp: https://www.meetup.com/members/8667764/
---
Greg Shackles is the VP of Technology at Olo. He is a Xamarin MVP, Microsoft MVP, host of the Gone Mobile podcast, an organizer for the LA.NET Developers Group, and the author of Mobile Development with C#.
