// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("d2b73aac-236b-4676-9522-c487b838c1de")]
[assembly: ComVisible(false)]
