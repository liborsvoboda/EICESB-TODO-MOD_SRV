---
Title: Geoffrey Huntley
Location: "[Brisbane|Sydney|Melbourne], Australia"
Email: ghuntley@ghuntley.com
Language:
  - English
Topics:
  - .NET
  - Android
  - ASP.NET
  - Architecture
  - C#
  - Containers
  - DevOps
  - Diversity & Inclusion
  - F#
  - iOS
  - macOS
  - Microservices
  - Mobile Development
  - NuGet
  - Open Source
  - Product Management
  - Security
  - UWP
  - Visual Studio
  - Visual Studio Code
  - Visual Studio for Mac
  - Windows Forms
  - WPF
  - Xamarin
  - Xamarin.Forms
Blog: https://ghuntley.com/
Twitter: https://twitter.com/geoffreyhuntley
GitHub: https://github.com/ghuntley
LinkedIn: https://linkedin.com/in/geoffreyhuntley
Twitch: https://twitch.tv/geoffreyhuntley
YouTube: https://www.youtube.com/c/geoffreyhuntley
Mentor: true
---

👋
