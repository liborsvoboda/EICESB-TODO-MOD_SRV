---
Title: Hector Minaya
Location: Maryland, USA
Language:
  - English
  - Spanish
Topics:
  - .NET
  - Android
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Architecture
  - Azure
  - C#
  - Containers
  - DevOps
  - Diversity & Inclusion
  - Entity Framework
  - JavaScript
  - Mobile Development
  - Open Source
  - Product Management
  - Security
  - Serverless
  - Visual Basic
  - Visual Studio
  - Visual Studio Code
  - Visual Studio for Mac
  - Web Development
  - Xamarin
  - Xamarin.Forms
Twitter: https://twitter.com/HectorMinaya
GitHub: https://github.com/hminaya
StackOverflow: https://stackoverflow.com/users/177394/hminaya
LinkedIn: https://www.linkedin.com/in/hectorminaya/
Sessionize: https://sessionize.com/HectorMinaya/
Dev: https://dev.to/hminaya
Mentor: true
---

