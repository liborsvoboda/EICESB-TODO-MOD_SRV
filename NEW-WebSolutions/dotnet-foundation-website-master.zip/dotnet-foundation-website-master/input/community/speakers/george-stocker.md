---
Title: George Stocker
Pronouns: he/him
Location: Washington, DC
Email: george@georgestocker.com
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - Architecture
  - C#
  - Containers
  - Microservices
  - ReSharper
Blog: https://georgestocker.com
Feed: https://georgestocker.com/feed/
Twitter: https://twitter.com/gortok
GitHub: https://github.com/gortok
StackOverflow: https://stackoverflow.com/users/16587/george-stocker
LinkedIn: https://www.linkedin.com/in/georgestocker
Sessionize: https://sessionize.com/george-stocker
Mentor: true
---

