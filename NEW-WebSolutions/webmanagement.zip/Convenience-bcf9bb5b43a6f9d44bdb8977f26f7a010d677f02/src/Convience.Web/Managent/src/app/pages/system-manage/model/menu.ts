export class Menu {
    id?: number;
    upId?: string;
    name?: string;
    identification?: number;
    permission?: string;
    type?: number;
    route?: string;
    sort?: number;
}