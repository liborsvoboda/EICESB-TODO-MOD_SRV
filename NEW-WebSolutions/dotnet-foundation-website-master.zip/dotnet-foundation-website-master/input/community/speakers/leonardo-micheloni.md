---
Title: Leonardo Gabriel Micheloni
Location: Madrid, Spain
Email: leomicheloni@hotmail.com
Language:
  - English
  - Spanish
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - Blazor
  - C#
  - Containers
  - DevOps
  - Entity Framework
  - JavaScript
  - Microservices
  - NuGet
  - Serverless
  - SignalR
  - Web Development
  - Xamarin
  - Xamarin.Forms
Blog: https://www.leomicheloni.com
Twitter: https://twitter.com/leomicheloni
GitHub: https://github.com/leomicheloni
LinkedIn: https://www.linkedin.com/in/leomicheloni/
YouTube: https://youtube.com/c/LeonardoMicheloni
---

