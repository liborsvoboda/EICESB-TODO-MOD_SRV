import Vue from 'vue';
import { VueClass } from './declarations';
export declare function collectDataFromConstructor(vm: Vue, Component: VueClass<Vue>): {};
