Title: Giancarlo Lelli
Location: Italy
Email: gcarlo.lelli@live.com
Language:
  - English
  - Italian
Topics:
  - .NET
  - ASP.NET
  - Architecture
  - Azure
  - Containers
  - DevOps
  - Microservices
  - Serverless
  - Visual Studio
Twitter: https://twitter.com/itsonlyGianca
GitHub: https://github.com/GiancarloLelli
LinkedIn: https://it.linkedin.com/in/giancarlolelli
Sessionize: https://sessionize.com/giancarlo-lelli/
Mentor: true
---
Eager to teach, eager to learn and passionate about technology, innovation and community driven projects
