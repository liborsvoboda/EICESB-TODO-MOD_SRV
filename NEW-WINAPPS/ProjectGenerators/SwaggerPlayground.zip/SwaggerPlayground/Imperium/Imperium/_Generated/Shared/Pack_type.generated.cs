namespace ImperiumApp.Imperium
{
public enum Pack_type {
    Nice,
    Naughty,
    Huge_bonus,
    Immortal,
    Stocking_filler,
    }
}
