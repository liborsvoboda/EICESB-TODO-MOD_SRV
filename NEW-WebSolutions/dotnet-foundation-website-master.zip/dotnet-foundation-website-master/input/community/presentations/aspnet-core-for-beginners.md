---
type: workshop
id: aspnet-core-for-beginners
title: ASP.NET Core For Beginners
repo: dotnet-presentations/aspnetcore-for-beginners
link: https://github.com/dotnet-presentations/aspnetcore-for-beginners
---

Are you completely new to .NET? No problem! Here’s a half day workshop for developers who have no experience with .NET Core or ASP.NET. We’ll start with the basics and build up to a movie database website with search.