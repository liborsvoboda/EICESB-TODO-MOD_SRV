﻿namespace Convience.EntityFrameWork.Infrastructure
{
    public enum DataBaseType
    {
        SqlServer,
        Sqlite,
        MySQL,
        PostgreSQL,
        Oracle
    }
}
