---
title: Jessica White
image: jessica-white.jpg
twitter: JessPWhite
location: United Kingdom
company: Experian Consumer Services
---

