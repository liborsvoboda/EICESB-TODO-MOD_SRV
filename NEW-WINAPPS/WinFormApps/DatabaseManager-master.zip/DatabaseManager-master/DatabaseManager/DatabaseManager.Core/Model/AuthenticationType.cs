﻿using System;

namespace DatabaseManager.Model
{
    public enum AuthenticationType
    {
        IntegratedSecurity,
        Password
    }
}
