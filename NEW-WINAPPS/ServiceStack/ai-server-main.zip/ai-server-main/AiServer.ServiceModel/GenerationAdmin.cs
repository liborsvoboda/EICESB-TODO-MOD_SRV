using AiServer.ServiceModel.Types;
using ServiceStack;
using ServiceStack.DataAnnotations;

namespace AiServer.ServiceModel;

public class QueryGenerationApiProviders : QueryDb<GenerationApiProvider>
{
    public int? Id { get; set; }
    public string? Name { get; set; }
}

[AutoPopulate(nameof(GenerationApiProvider.CreatedDate),  Eval = "utcNow")]
public class CreateGenerationApiProvider : ICreateDb<GenerationApiProvider>, IReturn<IdResponse>
{
    [Description("The name of the API Provider")]
    public string Name { get; set; }

    [Description("The API Key to use for this Provider")]
    public string? ApiKey { get; set; }

    [Description("Send the API Key in the Header instead of Authorization Bearer")]
    public string? ApiKeyHeader { get; set; }

    [Description("Base URL for the Generation Provider")]
    public string? ApiBaseUrl { get; set; }

    [Description("Url to check if the API is online")]
    [Input(Type = "hidden")]
    public string? HeartbeatUrl { get; set; }
    
    
    [Description("How many requests should be made concurrently")]
    [Input(Type = "hidden")]
    public int Concurrency { get; set; }

    
    [Description("What priority to give this Provider to use for processing models")]
    [Input(Type = "hidden")]
    public int Priority { get; set; }

    [Description("Whether the Provider is enabled")]
    public bool Enabled { get; set; }

    [Description("The date the Provider was last online")]
    [Input(Type = "hidden")]
    public DateTime? OfflineDate { get; set; }
    
    [Description("Models this API Provider should process")]
    [Input(Type = "hidden")]
    public List<string>? Models { get; set; }
    
    [Input(Type = "hidden")]
    public int? GenerationApiTypeId { get; set; }
    
    
}

public class QueryGenerationModelSettings : QueryDb<ProviderModelDefaults>
{
    public string? Id { get; set; }
}

public class UpdateGenerationApiProvider : IPatchDb<GenerationApiProvider>, IReturn<IdResponse>
{
    public int Id { get; set; }
    
    [Description("The API Key to use for this Provider")]
    public string? ApiKey { get; set; }
    
    [Description("Send the API Key in the Header instead of Authorization Bearer")]
    public string? ApiKeyHeader { get; set; }
    
    [Description("Override Base URL for the Generation Provider")]
    public string? ApiBaseUrl { get; set; }
    
    [Description("Url to check if the API is online")]
    public string? HeartbeatUrl { get; set; }
    
    [Description("How many requests should be made concurrently")]
    public int? Concurrency { get; set; }

    [Input(Type = "select", EvalAllowableEntries = "{ '-1':'Low', '0':'Normal', 1:'High', 2:'Highest' }")]
    [Description("What priority to give this Provider to use for processing models")]
    public int? Priority { get; set; }

    [Description("Whether the Provider is enabled")]
    public bool? Enabled { get; set; }
    
    [Input(Type = "hidden")]
    [Description("The models this API Provider should process")]
    public List<string>? Models { get; set; }
}

public class DeleteGenerationApiProvider : IDeleteDb<GenerationApiProvider>, IReturn<IdResponse>
{
    public int? Id { get; set; }
    public string? Name { get; set; }
}

