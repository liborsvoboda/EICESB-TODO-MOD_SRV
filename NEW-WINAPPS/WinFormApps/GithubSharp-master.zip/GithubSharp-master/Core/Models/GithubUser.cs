﻿namespace GithubSharp.Core.Models
{
    public class GithubUser
    {
        public string Name { get; set; }
        public string APIToken { get; set; }
    }
}
