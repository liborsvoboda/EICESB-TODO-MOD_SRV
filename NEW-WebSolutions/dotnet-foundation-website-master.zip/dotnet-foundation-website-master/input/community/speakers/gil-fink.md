---
Title: Gil Fink
Location: Rishon Le Zion, Israel
Email: gil.fink@gmail.com
Language:
  - English
  - Hebrew
Topics:
  - Architecture
  - JavaScript
  - Open Source
  - User Experience
  - Visual Studio Code
  - Web Development
Blog: https://medium.com/@gilfink
Feed: https://medium.com/feed/@gilfink
Twitter: https://twitter.com/gilfink
GitHub: https://github.com/gilf
StackOverflow: https://stackoverflow.com/users/1381389/gil-fink
LinkedIn: https://www.linkedin.com/in/gilfink/
Dev: https://dev.to/gilfink
Mentor: true
---
Gil Fink is a web development expert, Web Technologies GDE, Microsoft Development Technologies MVP and sparXys CEO. He is currently consulting for various enterprises and companies, where he helps to develop web based solutions. He is also co-author of several Microsoft Official Courses (MOCs) and training kits, co-author of "Pro Single Page Application Development" book (Apress), co-organizer of AngularUP and ReactNext conferences.

