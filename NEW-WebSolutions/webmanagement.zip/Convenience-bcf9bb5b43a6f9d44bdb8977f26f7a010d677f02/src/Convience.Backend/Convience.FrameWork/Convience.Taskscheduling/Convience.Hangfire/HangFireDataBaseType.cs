﻿namespace Convience.Hangfire
{
    public enum HangFireDataBaseType
    {
        SqlServer,
        PostgreSQL,
        MySQL,
        InMemory
    }
}
