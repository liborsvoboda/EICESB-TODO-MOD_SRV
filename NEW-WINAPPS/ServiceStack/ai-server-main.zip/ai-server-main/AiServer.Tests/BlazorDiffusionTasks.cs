using AiServer.ServiceModel;
using AiServer.ServiceModel.Types;
using NUnit.Framework;

namespace AiServer.Tests;

[Explicit]
public class BlazorDiffusionTasks
{
    
}