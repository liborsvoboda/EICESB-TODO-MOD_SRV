---
title: Julie Lerman
image: julie-lerman.jpg
twitter: julielerman
location: United States
company: The Data Farm
---

