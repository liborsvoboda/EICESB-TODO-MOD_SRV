---
Title: Branimir Giurov
Location: Sofia, Bulgaria
Email: branimir@gmail.com
Language:
  - English
  - Bulgarian
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - Architecture
  - C#
  - Containers
  - Entity Framework
  - Microservices
  - ML.NET
  - NuGet
  - Visual Studio
  - Windows Development
  - Windows Forms
LinkedIn: https://linkedin.com/in/branimirg
---
I've over 15 years of speaker experiance, 20+ in Dev/Architecture. 
Ex-MVP on C# for 11 years. Currently cracking .net core in containers with Orleans and Masstransit on top of RedHat OpenShift.
Strong interests in hybrid cloud apps, messaging and integration.
