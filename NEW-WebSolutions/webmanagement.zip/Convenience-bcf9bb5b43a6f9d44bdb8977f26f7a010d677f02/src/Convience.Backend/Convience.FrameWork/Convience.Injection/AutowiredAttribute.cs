﻿using System;

namespace Convience.Injection
{
    /// <summary>
    /// 装配标记
    /// </summary>
    public class AutowiredAttribute : Attribute { }
}
