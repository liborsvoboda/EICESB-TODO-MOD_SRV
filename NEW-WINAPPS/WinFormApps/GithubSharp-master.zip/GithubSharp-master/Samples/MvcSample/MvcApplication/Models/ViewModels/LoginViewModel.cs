
using System;

namespace GithubSharp.Samples.MvcSample.MvcApplication.Models.ViewModels
{
	public class LoginViewModel
	{
		
		public string Message {
			get;
			set;
		}
		
		public string ReturnURL {
			get;
			set;
		}
	}
}
