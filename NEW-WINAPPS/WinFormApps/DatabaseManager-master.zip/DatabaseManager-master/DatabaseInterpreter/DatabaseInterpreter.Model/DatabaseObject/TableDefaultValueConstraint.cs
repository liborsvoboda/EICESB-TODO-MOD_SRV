﻿namespace DatabaseInterpreter.Model
{
    public class TableDefaultValueConstraint: TableColumnChild
    {        
        
    }
}
