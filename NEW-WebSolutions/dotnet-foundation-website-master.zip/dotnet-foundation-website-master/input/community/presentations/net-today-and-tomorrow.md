﻿---
type: deck
id: net-today-and-tomorrow
title: .NET Today and Tomorrow
link: https://github.com/dotnet-presentations/home/tree/master/.NET%20Keynote
---

Overview of the .NET platform, open source ecosystem, features in the latest releases, and the future roadmap of .NET Core 3.0. Great for keynotes.