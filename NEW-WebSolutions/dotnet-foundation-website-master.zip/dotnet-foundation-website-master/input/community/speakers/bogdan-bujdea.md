---
Title: Bogdan Bujdea
Location: Iasi, Romania
Email: bogdan@thewindev.net
Language:
  - English
  - Romanian
Topics:
  - .NET
  - C#
  - Mobile Development
  - Serverless
  - UWP
  - Windows Development
  - WPF
  - Xamarin
  - Xamarin.Forms
Blog: https://thewindev.net
Feed: https://thewindev.net/rss.xml
Twitter: https://twitter.com/thewindev
GitHub: https://github.com/thewindev
StackOverflow: https://stackoverflow.com/users/1091894/thewindev
LinkedIn: https://www.linkedin.com/in/bogdanbujdea/
MeetUp: https://www.meetup.com/members/226057326/
YouTube: https://www.youtube.com/channel/UCM8KMIusoZeUiHwUG_fWlCA
Dev: https://dev.to/thewindev
---
Hi! I'm Bogdan Bujdea, .NET Developer at Maxcode and Microsoft MVP on Developer Technologies. The only thing I like more than programming is talking about it, so I'm trying to do this as often as I can as a speaker at conferences and on my blog. I'm currently co-organizing the dotnetdays (https://dotnetdays.ro) conference in Romania and the local .NET user group.
