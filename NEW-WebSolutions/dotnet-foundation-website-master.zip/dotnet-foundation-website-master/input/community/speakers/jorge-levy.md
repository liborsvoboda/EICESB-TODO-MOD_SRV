---
Title: Jorge Levy
Location: Roseville, California USA
Email: me@jorgelevy.com
Language:
  - Spanish
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - Blazor
  - C#
  - DevOps
  - Visual Studio
  - Web Development
Blog: http://www.jorgelevy.com/
Feed: http://www.jorgelevy.com/feed/
Twitter: https://twitter.com/KodiakMx
GitHub: https://github.com/jorgelevy
StackOverflow: https://stackoverflow.com/users/654508/kodiakmx
LinkedIn: https://www.linkedin.com/in/jorgeelevy/
Sessionize: https://sessionize.com/jorge-levy/
MeetUp: https://www.meetup.com/members/13370415/
YouTube: https://www.youtube.com/channel/UCVk4BJ7Klxd4K6KrO_tCNug
Dev: https://dev.to/jorgelevy
Mentor: true
---
Programador por convicción y pasión. Más de 15 años programando en tecnologías Microsoft, especializado en Asp .Net MVC y .Net Core.

Actualmente viviendo en EU trabajando como Developer Senior para una compañía consultora con gran indice proyectos para el Gobierno de California.

Early Adopter de productos tecnológicos. “Insider” de todo lo relacionado a Ms. Windows 10, Visual Studio, Visual Studio Code, Office, Xbox, Edge Chromium, etc, todo en versión insider.
