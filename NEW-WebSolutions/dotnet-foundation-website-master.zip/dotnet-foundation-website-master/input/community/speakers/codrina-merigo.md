Title: Codrina Merigo
Location: Milan, Italy
Email: codrinamerigo@outlook.com
Language:
  - English
  - Italian
  - Romanian
Topics:
  - .NET
  - Artificial Intelligence
  - Azure
  - Blazor
  - C#
  - DevOps
  - Diversity & Inclusion
  - Entity Framework
  - JavaScript
  - Mobile Development
  - Product Management
  - Visual Studio
  - Visual Studio Code
  - Xamarin
  - Xamarin.Forms
Twitter: https://twitter.com/_Codrina_
GitHub: https://github.com/codrinamerigo
Sessionize: https://sessionize.com/codrina-merigo
Instagram: https://www.instagram.com/codrina_ladybug/
Mentor: true
---
Determined but shy, maybe not the perfect speaker, but for sure one of the most passionate - and modest. 
Motivational or tech sessions, I think that a lot of people can learn from my experience.
