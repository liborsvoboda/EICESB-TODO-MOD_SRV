export class WorkflowInstanceValue {
    formControlDomId?: string;
    value?: string;
}