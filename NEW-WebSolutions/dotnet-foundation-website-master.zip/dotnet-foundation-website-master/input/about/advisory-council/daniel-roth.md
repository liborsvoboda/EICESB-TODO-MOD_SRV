---
title: Daniel Roth
image: daniel-roth.jpg
order: 2
twitter: danroth27
location: United States
company: Program Manager at Microsoft
advisor: true
---

ASP.NET team
