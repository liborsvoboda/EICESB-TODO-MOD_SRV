# West Wind Web Store ToDo

## Bugs

* Order Manager: Invalid Order Number blows up
* Fix permissions to log files
* Fix logging for 404 (Exception routing)

## Features

