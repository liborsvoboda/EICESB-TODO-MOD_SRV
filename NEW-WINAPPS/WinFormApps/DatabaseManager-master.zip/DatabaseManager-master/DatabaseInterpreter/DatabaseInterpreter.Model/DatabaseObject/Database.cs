﻿namespace DatabaseInterpreter.Model
{
    public class Database: DatabaseObject
    {
        
    }
}
