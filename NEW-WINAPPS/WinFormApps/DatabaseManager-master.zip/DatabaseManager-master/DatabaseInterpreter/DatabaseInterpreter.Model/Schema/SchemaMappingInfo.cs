﻿namespace DatabaseInterpreter.Model
{
    public class SchemaMappingInfo
    {
        public string SourceSchema { get; set; }
        public string TargetSchema { get; set; }
    }
}
