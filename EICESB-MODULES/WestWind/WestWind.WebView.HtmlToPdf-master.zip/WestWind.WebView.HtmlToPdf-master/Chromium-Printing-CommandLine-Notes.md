# Chromium Printing and PDF Command Line Switches

* --headless
* --print-to-pdf
* --generate-pdf-document-outline
* --no-pdf-header-footer
