﻿
namespace SqlCodeEditor
{
    public static class SyntaxModes
    {
        public const string TSql = "TSql";
        public const string MySql = "MySql";
        public const string PlSql = "PlSql";
        public const string PostgreSql = "PostgreSql";
        public const string SqliteSql = "SqliteSql";
    }
}