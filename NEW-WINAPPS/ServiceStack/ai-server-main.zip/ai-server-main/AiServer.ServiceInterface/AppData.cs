﻿using System.Data;
using AiServer.ServiceInterface.Comfy;
using AiServer.ServiceInterface.Generation;
using Microsoft.Extensions.Logging;
using ServiceStack;
using ServiceStack.Messaging;
using ServiceStack.OrmLite;
using AiServer.ServiceModel;
using AiServer.ServiceModel.Types;
using ServiceStack.IO;
using CollectionExtensions = System.Collections.Generic.CollectionExtensions;

namespace AiServer.ServiceInterface;

public class AppData(ILogger<AppData> log, AiProviderFactory aiFactory,GenerationApiProviderFactory aiGenerationFactory, IVirtualPathProvider vfs)
{
    public static AppData Instance { get; set; }

    // OpenAI/standard-specific properties
    public AiModel[] AiModels { get; set; } = [];
    public ApiProvider[] ApiProviders { get; set; } = [];
    
    public GenerationApiProvider[] GenerationApiProviders { get; set; } = [];

    public Dictionary<string, ProviderModelDefaults> GenerationModelSettings { get; set; } = [];

    // Shared properties
    private CancellationTokenSource? cts;
    public CancellationToken Token => cts?.Token ?? CancellationToken.None;
    public DateTime? StoppedAt { get; private set; }
    public bool IsStopped => StoppedAt != null;

    public ApiProvider AssertApiProvider(string name) => ApiProviders.FirstOrDefault(x => x.Name == name)
        ?? throw new NotSupportedException($"API Provider {name} not found");

    public GenerationApiProvider AssertGenerationProvider(string name) => GenerationApiProviders.FirstOrDefault(x => x.Name == name)
        ?? throw new NotSupportedException($"Generation Provider {name} not found");
    
    public GenerationApiProvider AssertComfyProvider(string name) => ComfyProviders.FirstOrDefault(x => x.Name == name)
        ?? throw new NotSupportedException($"Comfy Provider {name} not found");
    
    public GenerationApiProvider[] ComfyProviders  => GenerationApiProviders.Where(x => x.Type.Provider == AiServiceProvider.Comfy).ToArray();
    
    public void Reload(IDbConnection db)
    {
        AiModels = db.Select<AiModel>().ToArray();
        ApiProviders = db.LoadSelect<ApiProvider>().OrderByDescending(x => x.Priority).ThenBy(x => x.Id).ToArray();
        GenerationApiProviders = db.LoadSelect<GenerationApiProvider>().OrderByDescending(x => x.Priority).ThenBy(x => x.Id).ToArray();
        LoadModelDefaults();
        LogWorkerInfo(ApiProviders, "API");
    }

    private void LoadModelDefaults()
    {
        var modelSettings = vfs.GetFile("lib/data/ai-models.json")
            .ReadAllText()
            .FromJson<List<ProviderModelDefaults>>()
            .Where(x => x is { ApiModels.Keys.Count: > 0, ModelType: 
                ModelType.TextToImage or 
                ModelType.TextToSpeech or 
                ModelType.SpeechToText or 
                ModelType.ImageUpscale or 
                ModelType.TextToAudio or 
                ModelType.TextEncoder or 
                ModelType.ImageToImage or 
                ModelType.ImageWithMask or 
                ModelType.ImageToText
            })
            .ToList();
        GenerationModelSettings = modelSettings.ToDictionary(x => x.Id);
    }

    public string? GetGenerationProviderApiModel(GenerationApiProvider provider, string modelId)
    {
        if (!GenerationModelSettings.TryGetValue(modelId, out var modelSettings))
            throw HttpError.NotFound("Model does not exist: " + modelId.SafeVarName());
        return modelSettings.ApiModels.GetValueOrDefault(provider.Type!.Name);
    }
    
    public string? GetGenerationModelByApiModel(GenerationApiProvider provider, string apiModel)
    {
        ArgumentNullException.ThrowIfNull(apiModel);
        var providerType = provider?.Type?.Name ?? throw new ArgumentNullException(nameof(provider.Type));
        foreach (var modelSettings in GenerationModelSettings.Values)
        {
            foreach (var entry in modelSettings.ApiModels)
            {
                if (entry.Key == providerType && entry.Value == apiModel)
                    return modelSettings.Id;
            }
        }
        throw HttpError.NotFound($"Provider model {apiModel} for {provider.Name} does not match a supported model ({provider.Type?.Name})");
    }
    
    public string? GetDefaultGenerationProviderModel(GenerationApiProvider provider, AiTaskType taskType)
    {
        ArgumentNullException.ThrowIfNull(provider);
        var supportedTaskModels = GenerationModelSettings.Values
            .Where(x => x.ModelType == GetModelTypeByAiTaskType(taskType))
            .Where(x => x.ApiModels.ContainsKey(provider.Type!.Name) && 
                        provider.Models != null &&
                        provider.Models.Contains(x.ApiModels[provider.Type!.Name]));
        var defaultSupportedModel = supportedTaskModels.FirstOrDefault()?.Id;
        if(defaultSupportedModel == null)
            throw HttpError.NotFound($"No supported models found for {provider.Name} ({provider.Type?.Name})");
        return GenerationModelSettings[defaultSupportedModel!].ApiModels[provider.Type!.Name];
    }
    
    public List<string> GetSupportedModels(AiTaskType taskType)
    {
        return GenerationModelSettings
            .Where(x => x.Value.ModelType == GetModelTypeByAiTaskType(taskType))
            .Select(x => x.Key)
            .ToList();
    }
    
    public bool ProviderHasModelForTask(GenerationApiProvider provider, AiTaskType taskType)
    {
        ArgumentNullException.ThrowIfNull(provider);
        return GenerationModelSettings.Values
            .Any(x => x.ModelType == GetModelTypeByAiTaskType(taskType) &&
                      x.ApiModels.ContainsKey(provider.Type!.Name) &&
                      provider.Models != null &&
                      provider.Models.Contains(x.ApiModels[provider.Type!.Name]));
    }
    
    public bool ModelSupportsTask(string modelId, AiTaskType taskType)
    {
        return GenerationModelSettings.TryGetValue(modelId, out var modelSettings) &&
               modelSettings.ModelType == GetModelTypeByAiTaskType(taskType);
    }
    
    private ModelType GetModelTypeByAiTaskType(AiTaskType taskType)
    {
        return taskType switch
        {
            AiTaskType.TextToImage => ModelType.TextToImage,
            AiTaskType.TextToSpeech => ModelType.TextToSpeech,
            AiTaskType.SpeechToText => ModelType.SpeechToText,
            AiTaskType.ImageToImage => ModelType.ImageToImage,
            AiTaskType.ImageUpscale => ModelType.ImageUpscale,
            AiTaskType.ImageWithMask => ModelType.ImageWithMask,
            AiTaskType.ImageToText => ModelType.ImageToText,
            _ => throw new NotSupportedException($"Unsupported task type: {taskType}")
        };
    }

    public ProviderModelDefaults GetGenerationModelSettingsByApiModel(GenerationApiProvider provider, string apiModel)
    {
        ArgumentNullException.ThrowIfNull(apiModel);
        var providerType = provider?.Type?.Name ?? throw new ArgumentNullException(nameof(provider.Type));
        foreach (var modelSettings in GenerationModelSettings.Values)
        {
            foreach (var entry in modelSettings.ApiModels)
            {
                if (entry.Key == providerType && entry.Value == apiModel)
                    return modelSettings;
            }
        }
        throw HttpError.NotFound($"{apiModel} is not a supported model for {provider.Name} ({provider.Type?.Name})");
    }

    public void ResetApiProviders(IDbConnection db)
    {
        ApiProviders = db.LoadSelect<ApiProvider>().OrderByDescending(x => x.Priority).ThenBy(x => x.Id).ToArray();
    }
    
    public void ResetGenerationProviders(IDbConnection db)
    {
        GenerationApiProviders = db.LoadSelect<GenerationApiProvider>().OrderByDescending(x => x.Priority).ThenBy(x => x.Id).ToArray();
    }

    private void LogWorkerInfo(ApiProvider[] apiProviders, string workerType)
    {
        foreach (var worker in apiProviders.Where(x => x.Enabled))
        {
            log.LogInformation(
                """

                [{Type}] [{Name}] is {Enabled}, currently {Online} at concurrency {Concurrency}, accepting models:
                
                    {Models}
                    
                """,
                workerType,
                worker.Name,
                worker.Enabled ? "Enabled" : "Disabled",
                worker.OfflineDate != null ? "Offline" : "Online",
                worker.Concurrency, 
                string.Join("\n    ", worker.Models.Select(x => x.Model)));
        }
    }
    
    public IOpenAiProvider GetOpenAiProvider(ApiProvider apiProvider) => 
        aiFactory.GetOpenAiProvider(apiProvider.ApiType.Provider);
    
    public IAiProvider GetGenerationProvider(GenerationApiProvider apiProvider) => 
        aiGenerationFactory.GetProvider(apiProvider.Type.Provider);
    
    /// <summary>
    /// For ollama models with 'latest' tag, returns:
    ///     - model:tag if tag exists
    ///     - model:${latest} when tag is 'latest' or unspecified
    /// For models without tags, returns ${model} when exists 
    /// </summary>
    public string? GetQualifiedModel(string model)
    {
        if (model.IndexOf(':') == -1)
        {
            var aiModel = AiModels.FirstOrDefault(x => x.Name == model);
            if (aiModel == null)
                return null;
            return aiModel.Name + (aiModel.Latest != null ? ":" + aiModel.Latest : "");
        }
        else
        {
            var modelGroup = model.LeftPart(':');
            var modelTag = model.RightPart(':');
            var aiModel = AiModels.FirstOrDefault(x => x.Name == modelGroup);
            if (aiModel == null)
                return null;
            if (modelTag == "latest")
                return aiModel.Name + (aiModel.Latest != null ? ":" + aiModel.Latest : "");
            if (!aiModel.Tags.Contains(modelTag))
                return null;
            return aiModel.Name + ":" + modelTag;
        }
    }
}
