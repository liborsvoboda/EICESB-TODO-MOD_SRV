﻿namespace SqlAnalyser.Model
{
    public class BreakStatement : Statement
    {
        
    }
}
