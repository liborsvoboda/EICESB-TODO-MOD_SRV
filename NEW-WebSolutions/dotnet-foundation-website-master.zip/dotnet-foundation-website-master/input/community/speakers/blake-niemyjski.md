---
Title: Blake Niemyjski
Location: Suamico, Wisconsin USA
Email: bniemyjski@gmail.com
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - C#
  - Containers
  - IoT
  - JavaScript
  - Microservices
  - Open Source
  - SignalR
  - Visual Studio
  - Visual Studio Code
Blog: https://blakeniemyjski.com
Feed: https://blakeniemyjski.com/index.xml
Twitter: https://twitter.com/blaken
GitHub: https://github.com/niemyjski
StackOverflow: https://stackoverflow.com/users/199701
LinkedIn: https://linkedin.com/in/niemyjski
Twitch: https://www.twitch.tv/niemyjski
YouTube: https://youtube.com/bniemyjski
Dev: https://dev.to/niemyjski
Mentee: true
---
I've done public speaking in the past about subjects I'm super passionate about (https://blakeniemyjski.com/categories/public-speaking/). I'd like to take it to the next level :).
