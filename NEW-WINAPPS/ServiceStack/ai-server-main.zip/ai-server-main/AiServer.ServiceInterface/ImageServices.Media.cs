using AiServer.ServiceModel;
using ServiceStack;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats;
using SixLabors.ImageSharp.Processing;

namespace AiServer.ServiceInterface;

public partial class ImageServices
{
    public async Task<object> Post(ConvertImage request)
    {
        if (Request?.Files == null || Request.Files.Length == 0)
        {
            throw new ArgumentException("No image file provided");
        }

        var inputFile = Request.Files[0];
        using var inputImage = await Image.LoadAsync(inputFile.InputStream);

        var outputFormat = GetImageFormat(request.OutputFormat);
        var outputStream = new MemoryStream();
        await inputImage.SaveAsync(outputStream, outputFormat);
        outputStream.Position = 0;
        
        return new HttpResult(outputStream, outputFormat.DefaultMimeType);
    }
    
    public async Task<object> Any(CropImage request)
    {
        if (Request?.Files == null || Request.Files.Length == 0)
        {
            throw new ArgumentException("No image file provided");
        }

        var inputFile = Request.Files[0];
        using var inputImage = await Image.LoadAsync(inputFile.InputStream);

        inputImage.Mutate(x => x.Crop(new Rectangle(request.X, request.Y, request.Width, request.Height)));

        var outputStream = new MemoryStream();
        await inputImage.SaveAsync(outputStream, inputImage.Metadata.DecodedImageFormat ?? ImageFormats.Png);
        outputStream.Position = 0;
        
        return new HttpResult(outputStream, inputImage.Metadata.DecodedImageFormat?.DefaultMimeType ?? "image/png");
    }


    private IImageFormat GetImageFormat(string format)
    {
        return format.ToLower() switch
        {
            "png" => ImageFormats.Png,
            "jpg" or "jpeg" => ImageFormats.Jpeg,
            "gif" => ImageFormats.Gif,
            "bmp" => ImageFormats.Bmp,
            _ => throw new ArgumentException($"Unsupported format: {format}")
        };
    }

    public async Task<object> Any(WatermarkImage request)
    {
        if (Request?.Files == null || Request.Files.Length == 0)
        {
            throw new ArgumentException("No image file provided");
        }

        var inputFile = Request.Files[0];
        using var inputImage = await Image.LoadAsync(inputFile.InputStream);

        if (Request.Files.Length < 2)
        {
            throw new ArgumentException("No watermark image file provided");
        }
        var watermarkFile = Request.Files[1];
        using var watermarkImage = await Image.LoadAsync(watermarkFile.InputStream);
        ApplyImageWatermark(inputImage, watermarkImage, request.Position, request.Opacity);

        var outputStream = new MemoryStream();
        await inputImage.SaveAsync(outputStream, inputImage.Metadata.DecodedImageFormat);
        outputStream.Position = 0;

        return new HttpResult(outputStream, inputFile.ContentType);
    }

    private void ApplyImageWatermark(Image sourceImage, Image watermarkImage, WatermarkPosition position, float opacity)
    {
        var (x, y) = CalculateWatermarkPosition(sourceImage.Width, sourceImage.Height, 
            watermarkImage.Width, watermarkImage.Height, position);
        
        sourceImage.Mutate(ctx => ctx
            .DrawImage(watermarkImage, new Point(x, y), opacity));
    }
    
    private (int x, int y) CalculateWatermarkPosition(int sourceWidth, int sourceHeight, 
        int watermarkWidth, int watermarkHeight, WatermarkPosition position)
    {
        return position switch
        {
            WatermarkPosition.TopLeft => (10, 10),
            WatermarkPosition.TopRight => (sourceWidth - watermarkWidth - 10, 10),
            WatermarkPosition.BottomLeft => (10, sourceHeight - watermarkHeight - 10),
            WatermarkPosition.BottomRight => (sourceWidth - watermarkWidth - 10, sourceHeight - watermarkHeight - 10),
            WatermarkPosition.Center => ((sourceWidth - watermarkWidth) / 2, (sourceHeight - watermarkHeight) / 2),
            _ => throw new ArgumentException("Invalid watermark position")
        };
    }
}