namespace ImperiumApp.Imperium
{
public enum Team {
    Aog,
    Au,
    Afs,
    Cgs,
    Cpp,
    Egc,
    Fea,
    Hl,
    Sbr,
    Uosp,
    Vt,
    }
}





