import { NavBootstrapBase } from '../core';
export declare class NavButtonGroup extends NavBootstrapBase {
    block?: boolean;
    vertical?: boolean;
    protected readonly opt: any;
    protected readonly cls: any;
}
export default NavButtonGroup;
