using System;

namespace CoreTests
{
	public class TestSettings
	{
		public static string Username {
			get { return "erikzaadi";} //change to your user
		}
		
		public static string Password {
			get { return "No, I won't put my password here"; } //change to your password
		}
	}
}

