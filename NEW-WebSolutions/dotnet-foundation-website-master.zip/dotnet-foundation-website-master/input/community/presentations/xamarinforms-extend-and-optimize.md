﻿---
type: deck
id: xamarinforms---extend-and-optimize
title: Xamarin.Forms - Extend and Optimize
link: https://github.com/dotnet-presentations/mobile/tree/master/Xamarin.Forms%20-%20Extend%20and%20Optimize
---

This deck focuses on the latest developments in Xamarin.Forms that will help developers share more code and build beautiful native iOS and Android apps in less time.