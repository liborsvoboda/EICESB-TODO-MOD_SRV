﻿namespace DatabaseInterpreter.Model
{
    public enum SortType
    {
        Ascending = 0,
        Descending = 1
    }
}
