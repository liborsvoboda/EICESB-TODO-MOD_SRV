# CodeProject Markdown Parser for Markdown Monster

This repository is an add-in for Markdown Monster that produces HTML compatible with CodeProject's article submission wizard.

You can install the add-in via Markdown Monster's Add-In Manager.

To read more about this project see [this CodeProject article](https://www.codeproject.com/Articles/1202882/Authoring-CodeProject-Articles-in-Markdown)

