---
Title: Alyssa Nicoll
Location: KC, MO
Email: Alyssa.Nicoll@progress.com
Language:
  - English
Topics:
  - Diversity & Inclusion
  - JavaScript
Blog: https://www.telerik.com/blogs/author/alyssa-nicoll
Twitter: https://twitter.com/AlyssaNicoll
GitHub: https://github.com/alyssamichelle
LinkedIn: https://www.linkedin.com/in/alyssa-nicoll/
Twitch: https://www.twitch.tv/codeitlive
YouTube: https://www.youtube.com/AngularAirPodcast
Mentor: true
---
Alyssa is an Angular Developer Advocate for KUI and a Google Developer Expert for Angular. Her two degrees (Web Design & Development and Psychology) feed her speaking career. She has spoken at over 30 conferences Internationally. She is a weekly panelist on Adventures in Angular and Angular Air, which have a combined following of over 16,000 listeners. She enjoys gaming, scuba diving, and has a little one that fondly goes by "Mr. Milks".
