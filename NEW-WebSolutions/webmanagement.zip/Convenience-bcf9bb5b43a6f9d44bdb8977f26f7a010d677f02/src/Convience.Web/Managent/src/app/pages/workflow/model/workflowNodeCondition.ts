export class WorkflowNodeCondition {

    sourceId?: string;
    targetId?: string;

    formControlId?: number;
    compareMode?: string;
    compareValue?: string;
}