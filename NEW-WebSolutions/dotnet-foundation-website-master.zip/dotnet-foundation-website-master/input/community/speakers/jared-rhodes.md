Title: Jared Rhodes
Location: Atlanta, Georgia USA
Email: jrhodes@qimata.com
Language:
  - English
Topics:
  - .NET
  - Architecture
  - Artificial Intelligence
  - Azure
  - C#
  - Data
  - IoT
  - Machine Learning
  - Mobile Development
  - SignalR
  - Xamarin
  - Xamarin.Forms
Blog: https://jaredrhodes.com
Feed: https://jaredrhodes.com/feed/
Twitter: https://twitter.com/QiMata
GitHub: https://github.com/QiMata
LinkedIn: https://www.linkedin.com/in/qimata/
Sessionize: https://sessionize.com/jared-rhodes
MeetUp: https://www.meetup.com/members/68996442/
YouTube: https://www.youtube.com/channel/UCEPgqfNgoyVc18jhiROKuEw
Mentor: true
---
As a Microsoft MVP for Azure and Pluralsight Author, I focus on IoT, Mobile, and Cloud; trying to find the subsection of those and make them work together. Lately, I have working with AI and Edge computing as the they evolve together. I enjoy public speaking, walks on the beach, and no linker errors.
