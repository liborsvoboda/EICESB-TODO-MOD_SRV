﻿namespace DatabaseInterpreter.Model
{
    public class DatabaseServerInfo
    {
        public string Server { get; set; }
        public string Port { get; set; }
        public string ServerVersion { get; set; }
    }
}
