﻿using ComplexApp.Complex;
using System;
using System.Collections.Generic;
using System.Text;

namespace Complex.Complex
{
    public class ComplexModule : ComplexModuleBase
    {
        public ComplexModule(IComplexService complexService) : base(complexService)
        {
        }
    }
}
