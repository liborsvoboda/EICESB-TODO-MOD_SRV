﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("OleViewDotNet")]
[assembly: AssemblyDescription("COM/OLE Viewer in .NET")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(".")]
[assembly: AssemblyProduct("OleViewDotNet")]
[assembly: AssemblyCopyright("Copyright © James Forshaw 2014-2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("0861C14D-ED53-41A8-8063-C26C6D28B09D")]

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: AssemblyInformationalVersion("1.7")]
