export class WorkFlow{

    id?:number;
    workFlowGroupId?:number;
    name?:string;
    describe?:string;

    createdTime?:string;
    createdUser?:string;
    updatedTime?:string;
    updatedUser?:string;

    isPublish?:boolean;
}