namespace ComplexApp.Complex
{
public enum Pack_type {
    Nice,
    Naughty,
    Huge_bonus,
    Immortal,
    Stocking_killer,
    }
}
