﻿namespace SqlAnalyser.Model
{
    public class IterateStatement : Statement
    {
        public TokenInfo Content { get; set; }
    }
}
