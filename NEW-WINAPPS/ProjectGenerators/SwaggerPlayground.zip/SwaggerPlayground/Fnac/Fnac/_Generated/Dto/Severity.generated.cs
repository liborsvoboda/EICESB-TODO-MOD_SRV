
using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentValidation;

namespace FnacApp.Fnac
{


public enum Severity {

    WARNING,
    ERROR,
    FATAL,
    }

}


