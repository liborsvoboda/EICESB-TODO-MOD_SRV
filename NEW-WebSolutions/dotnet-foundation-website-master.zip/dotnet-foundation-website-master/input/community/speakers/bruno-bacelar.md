---
Title: Bruno Bacelar
Pronouns: he/him
Location: Bahia, Brazil
Email: bruno.bacelar@live.com
Language:
  - Portuguese
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Blazor
  - C#
  - JetBrains Rider
  - Open Source
GitHub: https://github.com/knuxbbs
LinkedIn: https://www.linkedin.com/in/brunobacelar/
Mentor: true
---
I started my career as a developer using .NET, and haven't stopped since.

I am available to talk about ASP.NET, open-source tools and .NET on Linux.
