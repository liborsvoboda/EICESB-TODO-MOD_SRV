---
type: workshop
id: aws-cdk-workshop
title: AWS CDK .NET WORKSHOP
link: https://cdkworkshop.com/40-dotnet.html
---

AWS CDK allows developers to define their cloud infrastructure in code instead of writing large JSON or YAML files. .NET developers can build their cloud infrastructure in C# or F# taking advantages of .NET compilers and tools to validate their infrastructure.