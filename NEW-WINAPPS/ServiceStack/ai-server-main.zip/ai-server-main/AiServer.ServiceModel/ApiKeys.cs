﻿using ServiceStack;

namespace AiServer.ServiceModel;

// public class QueryApiKeys : QueryDb<ApiKey> {}
// public class ApiKey
// {
//     /// <summary>
//     /// The API Key
//     /// </summary>
//     public string Id { get; set; }
//
//     public string UserId { get; set; }
//
//     /// <summary>
//     /// The Name of the API Key or Worker using it
//     /// </summary>
//     public string UserName { get; set; }
//     
//     public string MaskedKey { get; set; }
//     
//     public DateTime CreatedDate { get; set; }
//     
//     public DateTime? ExpiryDate { get; set; }
//     
//     public DateTime? CancelledDate { get; set; }
//     
//     public string? Notes { get; set; }
// }