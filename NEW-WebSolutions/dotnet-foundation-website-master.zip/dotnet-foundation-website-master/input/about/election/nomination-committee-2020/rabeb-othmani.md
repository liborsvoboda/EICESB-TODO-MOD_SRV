---
title: Rabeb Othmani
image: rabeb-othmani.jpg
twitter: Rabeb_Othmani
location: United Kingdom
company: Zebra Technologies
---

