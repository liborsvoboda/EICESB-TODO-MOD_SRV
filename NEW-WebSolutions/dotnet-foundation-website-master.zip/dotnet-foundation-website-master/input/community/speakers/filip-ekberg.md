Title: Filip Ekberg
Location: Partille, Sweden
Email: filip@ekberg.dev
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - C#
  - Mobile Development
  - Xamarin
Blog: https://www.filipekberg.se/
Feed: https://feeds.feedburner.com/fekberg
Twitter: https://twitter.com/fekberg
GitHub: https://github.com/fekberg/
StackOverflow: https://stackoverflow.com/users/39106/filip-ekberg
LinkedIn: https://www.linkedin.com/in/filipekberg/
YouTube: https://www.youtube.com/FilipEkberg
Mentor: true
---
I am the author of C# Smorgasbord and a handful of Pluralsight courses, speaker at events and user groups around the globe, Microsoft and Xamarin MVP. 

I love teaching fellow developers how to master C# by understanding important concepts such asynchronous programming, MSIL and much more.
