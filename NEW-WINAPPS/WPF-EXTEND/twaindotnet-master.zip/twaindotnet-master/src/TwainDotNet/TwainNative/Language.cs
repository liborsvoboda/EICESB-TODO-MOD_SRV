﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TwainDotNet.TwainNative
{
    public enum Language : short
    {
        USA = 13
    }
}
