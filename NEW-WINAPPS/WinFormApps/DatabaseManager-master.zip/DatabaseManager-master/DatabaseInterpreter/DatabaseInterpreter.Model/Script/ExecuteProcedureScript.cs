﻿namespace DatabaseInterpreter.Model
{
    public class ExecuteProcedureScript : Script      
    {
        public ExecuteProcedureScript(string script) : base(script) { }       
    }
}
