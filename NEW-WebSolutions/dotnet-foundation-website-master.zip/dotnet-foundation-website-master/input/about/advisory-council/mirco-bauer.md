---
title: Mirco 'meebey' Bauer
image: 
order: 2
twitter: meebey
location: Hong Kong
company: CTO of cryptocurrency exchange Gatecoin Ltd.
advisor: true
---
