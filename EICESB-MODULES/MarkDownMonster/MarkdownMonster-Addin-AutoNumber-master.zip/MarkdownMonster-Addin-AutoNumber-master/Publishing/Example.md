The following shows an example figure. (See Figure 1.)

<figure><img src='icon_60.png'><figcaption>Figure 1. The first figure</figcaption></figure>


Another image is below. (See Figure 2.)

<figure><img src='icon_60.png'><figcaption>Figure 2. Another figure</figcaption></figure>

The method iterates 10 times. (See Listing 1.)

**Listing 1.** Some method1

```
for (var i = 0; i < 10; i++)
{
	...
}
```

The method iterates 10 times. (See Listing 2.)

**Listing 2.** Some method1

```
for (var i = 0; i < 10; i++)
{
	...
}
```
A table. (See Table 1.)

**Table 1.** A Table

| Tables        | Are           | Cool  |
| ------------- |:-------------:| -----:|
| col 3 is      | right-aligned | $1600 |
| col 2 is      | centered      |   $12 |
| zebra stripes | are neat      |    $1 |








