﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NuGet.Services.Dashboard.Common
{
    public class DatabaseIndex
    {
        public string ObjectName;
        public string IndexName;
        public double Fragmentation;
    }
}
