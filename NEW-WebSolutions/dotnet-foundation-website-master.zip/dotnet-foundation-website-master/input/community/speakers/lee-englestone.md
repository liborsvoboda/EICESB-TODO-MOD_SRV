---
Title: Lee Englestone
Location: Manchester, England
Email: lee.englestone@gmail.com
Language:
  - English
Topics:
  - .NET
  - Mixed Reality
  - Visual Studio
  - Xamarin
Blog: http://www.manchesterdeveloper.com/blog/
Feed: http://www.manchesterdeveloper.com/rss/
Twitter: https://twitter.com/LeeEnglestone
GitHub: https://github.com/LeeEnglestone
StackOverflow: https://stackoverflow.com/users/156446/lee-englestone
LinkedIn: https://linkedin.com/in/leeenglestone
Twitch: https://twitch.tv/leeenglestone
Sessionize: https://sessionize.com/lee-englestone/
MeetUp: https://www.meetup.com/members/60428502/
YouTube: https://www.youtube.com/user/LeeEnglestone
---
I am constantly working on innovative side projects, building things and looking for ways to educate the .NET community in cool technologies.
I am the creator of VisualStudioTips.co.uk, HackathonTips.com, ExpressionDesign4.com and XamarinArkit.com among other things.
I love sharing my knowledge with others.

-- Lee
