x get https://localhost:5005/modules/admin-ui/lib/metadata.mjs
x get https://localhost:5005/modules/admin-ui/components/BackgroundJobs.mjs
x get https://localhost:5005/modules/admin-ui/components/ApiKeys.mjs
x get https://localhost:5005/modules/admin-ui/components/ManageUserApiKeys.mjs
x get https://localhost:5005/js/components/CopyIcon.mjs
x get https://localhost:5005/js/components/ApiKeyDialog.mjs
#x get https://localhost:5005/js/core.mjs
