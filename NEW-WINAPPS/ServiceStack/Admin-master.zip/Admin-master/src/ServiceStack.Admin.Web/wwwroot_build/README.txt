Fill out publish\config.json with your IIS app settings to enable the gulp task 03-deploy-app

For more information on using gulp-msdeploy, see: https://www.npmjs.org/package/gulp-msdeploy

Also see ServiceStack docs on msdeploy with Gulp: http://docs.servicestack.net/simple-deployments-to-aws#deploy-using-gulp
