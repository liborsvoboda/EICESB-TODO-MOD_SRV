---
Title: Kenny Robinson
Location: Montgomery, Alabama USA
Email: info@thealmostengineer.com
Language:
  - English
Topics:
  - ASP.NET MVC
  - C#
  - Visual Studio Code
  - Web Development
Blog: https://thealmostengineer.com
Twitter: https://twitter.com/almostengr
GitHub: https://github.com/almostengr
LinkedIn: https://linkedin.com/in/krobinsontech
YouTube: https://www.youtube.com/channel/UC4HCouBLtXD1j1U_17aBqig
Instagram: https://instagram.com/almostengr
Mentor: true
Mentee: true
---
Kenny Robinson has been working Kenny Robinson is an Programmer and Information Technology (IT) Consultant. He starting learning about programming in the early-2000s when in high school. From there, he has continued to seek out new opportunities and continuing to improving his craft by learning new programming languages and showing others how technology can be fun.
Kenny enjoys building web applications and websites as they require knowledge in a variety of areas and offer different experiences. He writes about some of his projects and experiences on his blog The Almost Engineer (https://thealmostengineer.com) and does coding sessions on his YouTube channel (https://www.youtube.com/channel/UC4HCouBLtXD1j1U_17aBqig). 
