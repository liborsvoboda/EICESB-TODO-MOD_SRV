---
title: Claire Novotny
image: claire-novotny.jpg
order: 1
twitter: clairernovotny
---

I'm **Claire Novotny**, Executive Director of the .NET Foundation. I oversee the day-to-day operations, coordinate with the board, sponsors, advisory council, and help set the direction for the future.
