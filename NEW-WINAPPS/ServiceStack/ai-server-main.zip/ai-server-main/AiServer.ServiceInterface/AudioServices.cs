using AiServer.ServiceModel;
using ServiceStack;
using ServiceStack.Jobs;

namespace AiServer.ServiceInterface;

public class AudioServices(IBackgroundJobs jobs) : Service
{
    public async Task<object> Any(ConvertAudio request)
    {
        if (Request?.Files == null || Request.Files.Length == 0)
        {
            throw new ArgumentException("No audio file provided");
        }

        var outputformat = Enum.Parse<MediaTransformOutputFormat>(request.OutputFormat.ToString());
        if(!IsAudioFormat(outputformat))
            throw new ArgumentException("Invalid output format");
        
        var transformRequest = new CreateTransform
        {
            Request = new MediaTransformArgs
            {
                OutputFormat = outputformat,
                TaskType = MediaTransformTaskType.AudioConvert
            },
            ReplyTo = request.ReplyTo,
            RefId = request.RefId
        };

        var transformService = base.ResolveService<MediaTransformProviderServices>();
        return await request.ProcessTransform(transformRequest, jobs, transformService);
    }

    private bool IsAudioFormat(MediaTransformOutputFormat outputformat)
    {
        switch (outputformat)
        {
            case MediaTransformOutputFormat.MP3:
            case MediaTransformOutputFormat.WAV:
            case MediaTransformOutputFormat.FLAC:
                return true;
            case MediaTransformOutputFormat.MP4:
            case MediaTransformOutputFormat.AVI:
            case MediaTransformOutputFormat.MKV:
            case MediaTransformOutputFormat.MOV:
            case MediaTransformOutputFormat.WebM:
            case MediaTransformOutputFormat.GIF:
                return false;
            default:
                throw new ArgumentOutOfRangeException(nameof(outputformat), outputformat, null);
        }
    }
}