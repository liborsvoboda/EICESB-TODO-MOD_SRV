﻿function el_ChangeAvatar()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeAvatar";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_avatar/ChangeAvatar.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeDateAndTime()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeDateAndTime";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_date_and_time/ChangeDateAndTime.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeEmail()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeEmail";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_email/ChangeEmail.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeGroup()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeGroup";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_group/ChangeGroup.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeLanguage()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeLanguage";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_language/ChangeLanguage.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangePassword()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangePassword";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_password/ChangePassword.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeProfile()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeProfile";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_profile/ChangeProfile.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeTemplateAndStyle()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeTemplateAndStyle";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_template_and_style/ChangeTemplateAndStyle.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}

function el_ChangeView()
{
	var IframeTag = document.createElement("iframe");
	IframeTag.id = "div_ChangeView";
	IframeTag.setAttribute("onload", "el_IframeAutoHeight(this)");
    IframeTag.setAttribute("scrolling", "no");
	IframeTag.setAttribute("src", ElanatVariant.AdminDirectoryPath + "/profile/action/change_view/ChangeView.aspx");
	IframeTag.className = "el_hidden";
	document.body.appendChild(IframeTag);
	el_OpenBox(IframeTag.id);
}