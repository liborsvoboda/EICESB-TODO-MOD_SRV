---
Title: Davide Zordan
Location: London, United Kingdom
Email: mail@davide.dev
Language:
  - English
  - Italian
Topics:
  - HoloLens
  - Mixed Reality
Blog: https://davide.dev
Twitter: https://twitter.com/davidezordan
GitHub: https://github.com/davidezordan
LinkedIn: https://www.linkedin.com/in/davidezordan
Sessionize: https://sessionize.com/davide-zordan
Mentor: true
Mentee: true
---
Davide is a software engineer living in London specialising in client/mobile development and Mixed Reality. He likes sharing his experiences with the community writing on his blog https://davide.dev and participating in Open-Source projects.
