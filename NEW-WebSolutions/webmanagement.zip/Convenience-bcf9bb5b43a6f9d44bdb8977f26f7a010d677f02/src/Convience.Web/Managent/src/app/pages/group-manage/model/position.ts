export class Position {
    id?: number;
    name?: string;
    sort?: number;
}