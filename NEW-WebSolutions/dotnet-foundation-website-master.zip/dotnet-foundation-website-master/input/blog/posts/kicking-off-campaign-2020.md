---
Title: Kicking off the 2020 .NET Foundation Director Campaigns
Author: Claire Novotny
Published: 2020-07-07
---

The Nomination Committee has reviewed all of the candidates who submitted a nomination and came up up with the following slate. A huge thank you goes out to all who was nominated!

Here are the [candidates](/about/election/candidates) for the 2020 .NET Foundation Directors:

- [Ben Adams](/about/election/campaign-2019/ben-adams)*
- [Bill Wagner](/about/election/campaign-2020/bill-wagner)
- [Dennie Declercq](/about/election/campaign-2020/dennie-declercq)
- [Dhananjay Kumar](/about/election/campaign-2020/dhananjay-kumar)
- [Huei Feng](/about/election/campaign-2020/huei-feng)
- [Jamie Howarth](/about/election/campaign-2020/jamie-howarth)
- [Javier Lozano](/about/election/campaign-2020/javier-lozano)
- [Jay Harris](/about/election/campaign-2020/jay-harris)
- [Jeff Strauss](/about/election/campaign-2020/jeff-strauss)
- [Jeffrey Chilberto](/about/election/campaign-2020/jeffrey-chilberto)
- [Jerome Hardaway](/about/election/campaign-2020/jerome-hardaway)
- [Joseph Guadagno](/about/election/campaign-2020/joseph-guadagno)
- [Layla Porter](/about/election/campaign-2020/layla-porter)
- [Mitchel Sellers](/about/election/campaign-2020/mitchel-sellers)
- [Rainer Stropek](/about/election/campaign-2020/rainer-stropek)
- [Rodney Littles, II](/about/election/campaign-2020/rodney-littles-ii)
- [Rodrigo Diaz Concha](/about/election/campaign-2020/rodrigo-diaz-concha)
- [Shawn Wildermuth](/about/election/campaign-2020/shawn-wildermuth)

_*current director seeking re-election_ 

Today kicks off the campaign period. There are six open seats on the board that need to be chosen. Next week we'll highlight videos from the candidates so keep checking back!

Voting begins on July 21 and concludes on August 3rd. The voting will be on OpaVote and members will receive a private link to vote before voting begins.

