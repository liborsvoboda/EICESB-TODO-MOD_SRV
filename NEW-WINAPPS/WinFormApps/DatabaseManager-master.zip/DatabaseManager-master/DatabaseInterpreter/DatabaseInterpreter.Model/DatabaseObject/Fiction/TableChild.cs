﻿namespace DatabaseInterpreter.Model
{
    public class TableChild : DatabaseObject
    {
        public string TableName { get; set; }
        public string Comment { get; set; }
    }
}
