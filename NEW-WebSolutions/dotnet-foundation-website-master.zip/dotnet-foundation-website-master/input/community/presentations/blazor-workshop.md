---
type: workshop
id: blazor-workshop
title: Blazor Workshop
repo: dotnet-presentations/blazor-workshop
link: https://github.com/dotnet-presentations/blazor-workshop/
---

Blazor is a single-page app framework for building client-side web apps using .NET and WebAssembly. In this workshop we will build a complete Blazor app and learn about the various Blazor framework features along the way.