using AiServer.ServiceModel.Types;
using ServiceStack.DataAnnotations;
using ServiceStack.Model;
using ServiceStack.OrmLite;

namespace AiServer.Migrations;

public class Migration1002 : MigrationBase
{
    public enum ComfySampler
    {
        euler,
        euler_ancestral,
        huen,
        huenpp2,
        dpm_2,
        dpm_2_ancestral,
        lms,
        dpm_fast,
        dpm_adaptive,
        dpmpp_2s_ancestral,
        dpmpp_sde,
        dpmpp_sde_gpu,
        dpmpp_2m,
        dpmpp_2m_sde,
        dpmpp_2m_sde_gpu,
        dpmpp_3m_sde,
        dpmpp_3m_sde_gpu,
        ddpm,
        lcm,
        ddim,
        uni_pc,
        uni_pc_bh2
    }
    
    public class ApiTypeBase
    {
        [AutoIncrement] public int Id { get; set; }

        /// <summary>
        /// Default API Base URL
        /// </summary>
        public string? ApiBaseUrl { get; set; }

        /// <summary>
        /// Default API Key Header to use
        /// </summary>
        public string? ApiKeyHeader { get; set; }

        /// <summary>
        /// Name for this API Provider Type
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The website for this provider
        /// </summary>
        public string Website { get; set; }

        /// <summary>
        /// Icon Path or URL
        /// </summary>
        public string? Icon { get; set; }

        /// <summary>
        /// Mapping of common models to API Models
        /// </summary>
        public Dictionary<string, string> ApiModels { get; set; } = new();
    }

    public class AiProviderBase
    {
        [AutoIncrement] public int Id { get; set; }

        /// <summary>
        /// The unique name for this Provider
        /// </summary>
        [Index(Unique = true)]
        public string Name { get; set; }

        /// <summary>
        /// The Environment Variable for the API Key to use for this Provider
        /// </summary>
        public string? ApiKeyVar { get; set; }

        /// <summary>
        /// The API Key to use for this Provider
        /// </summary>
        public string? ApiKey { get; set; }

        /// <summary>
        /// Send the API Key in the Header instead of Authorization Bearer
        /// </summary>
        public string? ApiKeyHeader { get; set; }

        /// <summary>
        /// Override Base URL for the Provider
        /// </summary>
        public string? ApiBaseUrl { get; set; }

        /// <summary>
        /// Url to check if the API is online
        /// </summary>
        public string? HeartbeatUrl { get; set; }

        /// <summary>
        /// How many requests should be made concurrently
        /// </summary>
        public int Concurrency { get; set; }

        /// <summary>
        /// What priority to give this Provider to use for processing models 
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// Whether the Provider is enabled
        /// </summary>
        public bool Enabled { get; set; }

        /// <summary>
        /// When the Provider went offline
        /// </summary>
        public DateTime? OfflineDate { get; set; }

        /// <summary>
        /// When the Provider was created
        /// </summary>
        public DateTime CreatedDate { get; set; }

        public List<string>? Models { get; set; }
    
        public Dictionary<string, ProviderModelDefaults>? ModelSettings { get; set; }
    }

    public enum AiProvider
    {
        Replicate,
        Comfy,
        OpenAi
    }
    
    class GenerationApiProvider : AiProviderBase
    {
        /// <summary>
        /// The behavior for this Provider
        /// </summary>
        [References(typeof(GenerationApiType))]
        public int GenerationApiTypeId { get; set; }
    
        [Reference]
        [Input(Type = "hidden")]
        public GenerationApiType? Type { get; set; }
        
        [Ignore]
        public AiProvider ProviderType { get; set; }
    
        [Ignore]
        public string? ApiUrlVar { get; set; }
        
        /// <summary>
        /// This maps common name models to the implementation specific model names
        /// </summary>
        [Ignore]
        public Dictionary<string,string> ApiModels { get; set; }

    }

    public class GenerationApiType : ApiTypeBase
    {
        /// <summary>
        /// The AI Provider to process AI Requests
        /// </summary>
        public AiProvider Provider { get; set; }
    }

    public override void Up()
    {
        Db.CreateTable<GenerationApiProvider>();
        Db.CreateTable<GenerationApiType>();
        
        var apiTypes = File.ReadAllText("seed/generation-types.json").FromJson<List<GenerationApiType>>();
        Db.InsertAll(apiTypes);
        apiTypes = Db.Select<GenerationApiType>().ToList();
        
        var now = DateTime.UtcNow;
        var apiProviders = File.ReadAllText("seed/generation-providers.json").FromJson<List<GenerationApiProvider>>();
        
        InsertModelsFromEnv(apiProviders, apiTypes, now);
        
        var customGenerationProviders = File.ReadAllText("seed/custom-generation-providers.json").FromJson<List<GenerationApiProvider>>();
        foreach (var provider in customGenerationProviders)
        {
            // Grab unique values
            provider.Models = provider.ApiModels.Values
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .ToList();
            provider.CreatedDate = now;
            provider.GenerationApiTypeId = apiTypes.First(x => x.Provider == provider.ProviderType).Id;
            if(provider.ApiKeyVar != null)
                provider.ApiKey ??= Environment.GetEnvironmentVariable(provider.ApiKeyVar);
            Db.Insert(provider);
        }
        
    }

    private void InsertModelsFromEnv(List<GenerationApiProvider> apiProviders, List<GenerationApiType> apiTypes, DateTime now)
    {
        foreach (var apiProvider in apiProviders)
        {
            var apiKey = apiProvider.ApiKeyVar != null
                ? Environment.GetEnvironmentVariable(apiProvider.ApiKeyVar)
                : null;
            Console.WriteLine($"apiProvider: {apiProvider.ToJson()}");
            Console.WriteLine($"apiTypes: {apiTypes.ToJson()}");
            var apiType = apiTypes.First(x => x.Id == apiProvider.GenerationApiTypeId);
            apiProvider.ProviderType = apiType.Provider;
            if (apiProvider.ApiKeyVar == null || apiKey != null)
            {
                if (apiKey != null)
                {
                    apiProvider.ApiKey = apiKey;
                    Console.WriteLine($"Found API Key for {apiProvider.ApiKeyVar}");
                }
                apiProvider.CreatedDate = now;
                apiProvider.ApiBaseUrl ??= apiType.ApiBaseUrl;
                apiProvider.ApiKeyHeader ??= apiType.ApiKeyHeader;
                // Take api models from supported type for environment configured providers
                apiProvider.ApiModels = apiType.ApiModels;
                // Support all by default
                apiProvider.Models = apiProvider.ApiModels.Values.ToList();
                Console.WriteLine($"Adding {apiProvider.Name} API Provider...");
                Db.Insert(apiProvider);
            }
            if(apiProvider.ApiUrlVar != null)
            {
                var apiUrl = Environment.GetEnvironmentVariable(apiProvider.ApiUrlVar);
                if (apiUrl != null)
                {
                    apiProvider.ApiBaseUrl = apiUrl;
                    Console.WriteLine($"Found API URL for {apiProvider.ApiUrlVar}");
                    Db.Update(apiProvider);
                }
            }
        }
    }

    public override void Down()
    {
        Db.DropTable<GenerationApiProvider>();
        Db.DropTable<GenerationApiType>();
    }
}