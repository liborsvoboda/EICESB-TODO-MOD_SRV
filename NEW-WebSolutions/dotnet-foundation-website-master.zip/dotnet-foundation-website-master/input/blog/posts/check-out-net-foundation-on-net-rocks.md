---
Title: Check out .NET Foundation on .NET Rocks!
Author: Jon Galloway
Published: 2019-01-09 00:00:42.1863497
---
<p>The .NET Foundation is changing! Carl and Richard talk to Jon Galloway and Beth Massi about the changes in the .NET Foundation and what it means to the average .NET developer. The first announcement is that the .NET Foundation is moving to an open membership model - if you have made a contribution to .NET in any way, be it code, documentation or other, you can apply for membership and expect to be accepted. Next up, the expansion of the .NET Foundation board to seven directors and open elections for those board seats - any .NET Foundation member can be a director! Nominations are happening in January 2019, so get on board today!</p>

<p><a href="https://dotnetrocks.com/?show=1611">Give it a listen!</a></p>
