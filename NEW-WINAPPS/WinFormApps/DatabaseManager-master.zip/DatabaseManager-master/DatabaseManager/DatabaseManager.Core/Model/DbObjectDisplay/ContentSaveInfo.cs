﻿namespace DatabaseManager.Model
{
    public class ContentSaveInfo
    {
        public string FilePath { get; set; }
    }
}
