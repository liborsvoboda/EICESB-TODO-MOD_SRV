File explorer with two windows, you can copy or cut files between them directly.
