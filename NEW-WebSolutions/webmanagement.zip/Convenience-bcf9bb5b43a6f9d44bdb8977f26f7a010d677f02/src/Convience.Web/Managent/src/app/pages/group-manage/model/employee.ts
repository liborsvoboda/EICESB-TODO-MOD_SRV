export class Employee {
    id?: number;
    name: string;
    phoneNumber: string;
    avatar: string;
    sex: number;
    positionIds: string;
    departmentId: string;
}