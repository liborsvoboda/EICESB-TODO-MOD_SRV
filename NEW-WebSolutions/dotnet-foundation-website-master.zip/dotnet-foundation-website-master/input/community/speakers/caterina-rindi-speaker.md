---
Title: Caterina Rindi
Location: California, USA
Language:
  - English
  - Italian
  - Spanish
Topics:
  - Open Source
Twitter: https://twitter.com/CaterinaRindi
GitHub: https://github.com/c-rindi
LinkedIn: https://linkedin.com/in/crindi
YouTube: https://www.youtube.com/channel/UChM94Pc0iwB-0rdiAjnQe_A
Mentor: true
---
Many years of speaker experience, with a background in education.

Topics include Open-Source, Blockchain & Cryptocurrencies, Sharing Economy, Peer-to-Peer Economies, and more.
