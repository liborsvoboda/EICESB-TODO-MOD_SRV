using AiServer.ServiceInterface.AppDb;
using AiServer.ServiceInterface.Generation;
using AiServer.ServiceInterface.Jobs;
using AiServer.ServiceModel;
using AiServer.ServiceModel.Types;
using Microsoft.Extensions.Logging;
using ServiceStack;
using ServiceStack.Jobs;

namespace AiServer.ServiceInterface.MediaTransform;

public class CreateMediaTransformCommand(ILogger<CreateMediaTransformCommand> log,
    AppData appData,
    AppConfig appConfig,
    IBackgroundJobs jobs,
    GenerationApiProviderFactory providerFactory,
    IHttpClientFactory httpFactory) : AsyncCommandWithResult<CreateTransform,TransformResult>
{
    protected override async Task<TransformResult> RunAsync(CreateTransform request, CancellationToken token)
    {
        if (request.Request == null)
            throw new ArgumentNullException(nameof(request.Request));
        
        var job = Request.GetBackgroundJob();
        var apiProviderInstance = appData.AssertComfyProvider(job.Worker!.Replace("-ffmpeg",""));
        var transformProvider = providerFactory.GetProvider(apiProviderInstance.Type.Provider) as IMediaTransformProvider;
        
        log.LogInformation("Starting generation request {RefId} with {Provider}", request.RefId, apiProviderInstance.Name);
        
        try
        {
            await HandleFileUploadsAsync(job, request.Request, token);

            var keyId = job.Args?.TryGetValue("KeyId", out var oKeyId) == true ? oKeyId : "0";
            log.LogInformation("Running {TaskType} generation request {RefId} with {Provider}",
                request.Request.TaskType, request.RefId, apiProviderInstance.Name);
            var (response, durationMs) = await transformProvider.RunAsync(apiProviderInstance, request.Request, token);
            log.LogInformation("Finished {TaskType} generation request {RefId} with {Provider} in {DurationMs}ms",
                request.Request.TaskType, request.RefId, apiProviderInstance.Name, durationMs);
            if (response.Outputs != null && response.Outputs.Count > 0)
                await DownloadOutputsAsync(transformProvider, apiProviderInstance, response.Outputs, keyId);

            ResponseStatus? error = null;
            var outputs = new List<TransformFileOutput>();
            foreach (var output in response.Outputs ?? [])
            {
                if (!output.Url.StartsWith("/artifacts/"))
                {
                    log.LogWarning("{Url} could not be downloaded", output.Url);
                    continue;
                }

                outputs.Add(output);
                log.LogInformation("Returning artifact: {Path}", output.Url);
            }

            if (job.ReplyTo == null)
                return response;
            log.LogInformation("ReplyTo registered for {RefId}, sending response to {ReplyTo}", job.RefId, job.ReplyTo);
            jobs.EnqueueCommand<NotifyGenerationResponseCommand>(new MediaTransformCallback
            {
                State = request.State,
                RefId = job.RefId,
                Outputs = outputs,
                ResponseStatus = error,
            }, new()
            {
                ParentId = job.Id,
                ReplyTo = job.ReplyTo,
                Worker = job.Worker
            });
            return response;
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            log.LogError(e, "Error processing generation request {RefId} with {Provider}", request.RefId,
                apiProviderInstance.Name);
            if (!await transformProvider.IsOnlineAsync(apiProviderInstance, token))
            {
                log.LogWarning("{Provider} is offline, changing status to Offline", apiProviderInstance.Name);
                jobs.RunCommand<ChangeGenerationProviderStatusCommand>(new ChangeGenerationProviderStatus()
                {
                    Name = apiProviderInstance.Name,
                    OfflineDate = DateTime.UtcNow,
                });
            }

            throw;
        }
        finally
        {
            new IDisposable?[] {
                request.Request.ImageInput,
                request.Request.VideoInput,
                request.Request.AudioInput,
                request.Request.WatermarkInput,
            }.Dispose();
        }

    }
    
    private List<string> supportedFiles = new()
    {
        "image",
        "video",
        "watermark",
        "audio"
    };
    
    async Task DownloadOutputsAsync(IMediaTransformProvider aiProvider, 
        GenerationApiProvider apiProvider,
        IEnumerable<TransformFileOutput> outputs, string keyId)
    {
        var now = DateTime.UtcNow;
        var downloadTasks = outputs.Select(x => DownloadOutputAsync(aiProvider, apiProvider, x, now, keyId));
        await Task.WhenAll(downloadTasks);
    }
    
    async Task DownloadOutputAsync(IMediaTransformProvider aiProvider,
        GenerationApiProvider apiProvider,
        TransformFileOutput output, DateTime now, string keyId)
    {
        using var client = httpFactory.CreateClient();
        try
        {
            var response = await aiProvider.DownloadOutputAsync(apiProvider, output);
            response.EnsureSuccessStatusCode();
            
            // Grab file extension from response
            var ext = response.Content.Headers.ContentType?.MediaType switch
            {
                "image/jpeg" => "jpg",
                "image/png" => "png",
                "image/gif" => "gif",
                "image/webp" => "webp",
                //mp3
                "audio/mpeg" => "mp3",
                "audio/x-wav" => "wav",
                "audio/flac" => "flac",
                // Video
                "video/mp4" => "mp4",
                "video/webm" => "webm",
                "video/ogg" => "ogg",
                _ => "webm"
            };

            var imageBytes = await response.Content.ReadAsByteArrayAsync();
            var sha256 = imageBytes.ComputeSha256();
            output.FileName = $"{sha256}.{ext}";
            var relativePath = $"{now:yyyy}/{now:MM}/{now:dd}/{keyId}/{output.FileName}";
            var path = appConfig.ArtifactsPath.CombineWith(relativePath);
            Path.GetDirectoryName(path).AssertDir();
            await File.WriteAllBytesAsync(path, imageBytes);
            output.Url = $"/artifacts/{relativePath}";
        }
        catch (Exception e)
        {
            log.LogError(e, "Error downloading {ImageUrl}: {Message}", output.Url, e.Message);
        }
    }
    
    private async Task HandleFileUploadsAsync(BackgroundJob job, MediaTransformArgs argInstance, CancellationToken token)
    {
        if (job.Args?.TryGetValue("Files", out var files) != true)
            return;

        var fileUploads = files.FromJson<Dictionary<string, string>>();
        if (fileUploads == null)
            return;

        foreach (var file in fileUploads)
        {
            if (!supportedFiles.Contains(file.Key))
                continue;
            // Copy file from file system to memory stream
            var ms = new MemoryStream();
            using var fs = File.OpenRead(file.Value);
            await fs.CopyToAsync(ms, token);
            ms.Position = 0;
            fs.Close();
            switch (file.Key)
            {
                case "image":
                    argInstance.ImageInput = ms;
                    argInstance.ImageFileName = Path.GetFileName(file.Value);
                    break;
                case "video":
                    argInstance.VideoInput = ms;
                    argInstance.VideoFileName = Path.GetFileName(file.Value);
                    break;
                case "watermark":
                    argInstance.WatermarkInput = ms;
                    argInstance.WatermarkFileName = Path.GetFileName(file.Value);
                    break;
                case "audio":
                    argInstance.AudioInput = ms;
                    argInstance.AudioFileName = Path.GetFileName(file.Value);
                    break;
            }
        }
    }
}