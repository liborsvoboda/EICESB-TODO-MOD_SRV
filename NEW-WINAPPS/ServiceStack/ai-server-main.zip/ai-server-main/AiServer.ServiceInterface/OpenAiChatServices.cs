﻿using Microsoft.Extensions.Logging;
using ServiceStack;
using ServiceStack.Data;
using ServiceStack.Jobs;
using ServiceStack.Messaging;
using ServiceStack.OrmLite;
using AiServer.ServiceInterface.Jobs;
using AiServer.ServiceModel;

namespace AiServer.ServiceInterface;

public class OpenAiChatServices(
    ILogger<OpenAiChatServices> log,
    IDbConnectionFactory dbFactory, 
    IAutoQueryDb autoQuery,
    AppData appData,
    IBackgroundJobs jobs) : Service
{
    public object Any(ActiveAiModels request)
    {
        var activeModels = appData.ApiProviders
            .SelectMany(x => x.Models.Select(m => appData.GetQualifiedModel(m.Model)))
            .Where(x => x != null)
            .Distinct()
            .OrderBy(x => x);
        
        return new StringsResponse
        {
            Results = activeModels.ToList() 
        };
    }

    public object Any(GetWorkerStats request)
    {
        return new GetWorkerStatsResponse
        {
            Results = jobs.GetWorkerStats(),
            QueueCounts = jobs.GetWorkerQueueCounts(),
        };
    }

    public object Any(CancelWorker request)
    {
        jobs.CancelWorker(request.Worker);
        return new EmptyResponse();
    }

    public object GetModelImage(string model)
    {
        var qualifiedModel = appData.GetQualifiedModel(model);
        if (qualifiedModel != null)
        {
            var modelGroup = qualifiedModel.LeftPart(':');
            var aiModel = appData.AiModels.FirstOrDefault(x => x.Name == modelGroup);
            if (aiModel?.Icon != null)
            {
                var file = VirtualFileSources.GetFile(aiModel.Icon);
                if (file != null)
                {
                    return new HttpResult(file, MimeTypes.GetMimeType(file.Extension));
                }
            }
        }
        
        return new HttpResult(
            """
            <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 48 48">
                <path fill="none" stroke="currentColor" stroke-linejoin="round" d="M18.38 27.94v-14.4l11.19-6.46c6.2-3.58 17.3 5.25 12.64 13.33"/><path fill="none" stroke="currentColor" stroke-linejoin="round" d="m18.38 20.94l12.47-7.2l11.19 6.46c6.2 3.58 4.1 17.61-5.23 17.61"/>
                <path fill="none" stroke="currentColor" stroke-linejoin="round" d="m24.44 17.44l12.47 7.2v12.93c0 7.16-13.2 12.36-17.86 4.28"/><path fill="none" stroke="currentColor" stroke-linejoin="round" d="M30.5 21.2v14.14L19.31 41.8c-6.2 3.58-17.3-5.25-12.64-13.33"/>
                <path fill="none" stroke="currentColor" stroke-linejoin="round" d="m30.5 27.94l-12.47 7.2l-11.19-6.46c-6.21-3.59-4.11-17.61 5.22-17.61"/><path fill="none" stroke="currentColor" stroke-linejoin="round" d="m24.44 31.44l-12.47-7.2V11.31c0-7.16 13.2-12.36 17.86-4.28"/>
            </svg>
            """, 
            MimeTypes.ImageSvg);
    }

    public object Any(GetModelImage request)
    {
        return GetModelImage(request.Model);
    }
    
    public object Any(CreateOpenAiChat request)
    {
        if (request.Request == null)
            throw new ArgumentNullException(nameof(request.Request));
        
        var qualifiedModel = appData.GetQualifiedModel(request.Request.Model);
        if (qualifiedModel == null)
            throw HttpError.NotFound($"Model {request.Request.Model} not found");

        var queueCounts = jobs.GetWorkerQueueCounts();
        var providerQueueCount = int.MaxValue;
        ApiProvider? useProvider = null;
        var candidates = appData.ApiProviders
            .Where(x => x.Enabled && x.Models.Any(m => m.Model == qualifiedModel)).ToList();
        foreach (var candidate in candidates)
        {
            if (candidate.OfflineDate != null)
                continue;
            var pendingJobs = queueCounts.GetValueOrDefault(candidate.Name, 0);
            if (useProvider == null)
            {
                useProvider = candidate;
                providerQueueCount = pendingJobs;
                continue;
            }
            if (pendingJobs < providerQueueCount || (pendingJobs == providerQueueCount && candidate.Priority > useProvider.Priority))
            {
                useProvider = candidate;
                providerQueueCount = pendingJobs;
            }
        }

        useProvider ??= candidates.FirstOrDefault(x => x.Name == qualifiedModel); // Allow selecting offline models
        if (useProvider == null)
            throw new NotSupportedException("No active API Providers support this model");

        var jobRef = jobs.EnqueueCommand<CreateOpenAiChatCommand>(request, new()
        {
            RefId = request.RefId,
            ReplyTo = request.ReplyTo,
            Tag = request.Tag,
            Args = request.Provider == null ? null : new() {
                [nameof(request.Provider)] = request.Provider
            },
            Worker = useProvider.Name,
        });
        
        return new CreateOpenAiChatResponse
        {
            Id = jobRef.Id,
            RefId = jobRef.RefId,
        };
    }
    
    public async Task<object?> Any(WaitForOpenAiChat request)
    {
        if (request.Id == null && request.RefId == null)
            throw new ArgumentNullException(nameof(request.Id));

        JobSummary? summary = null; 

        var startedAt = DateTime.UtcNow;
        while (DateTime.UtcNow - startedAt < TimeSpan.FromSeconds(120))
        {
            summary ??= GetJobSummary(request.Id, request.RefId);
            if (summary != null)
            {
                var response = GetOpenAiChat(summary);
                if (response?.Result?.Response != null)
                    return response;
            }
            await Task.Delay(500);
        }

        if (summary != null)
        {
            var response = GetOpenAiChat(summary);
            if (response?.ResponseStatus != null)
                return new GetOpenAiChatResponse { ResponseStatus = response.ResponseStatus };

            using var monthDb = jobs.OpenMonthDb(summary.CreatedDate);
            var failedTask = monthDb.SingleById<CompletedJob>(summary.Id);
            if (failedTask != null)
            {
                return new GetOpenAiChatResponse {
                    ResponseStatus = failedTask.Error
                };
            }
        }
        
        return HttpError.NotFound("Job not found");
    }
    
    public JobSummary? GetJobSummary(int? id, string? refId)
    {
        using var db = jobs.OpenDb();
        var q = db.From<JobSummary>();
        if (refId != null)
            q.Where(x => x.RefId == refId);
        else if (id != null)
            q.Where(x => x.Id == id);
        else
            throw new ArgumentNullException(nameof(JobSummary.Id));
        
        var summary = db.Single(q);
        return summary;
    }
    
    public GetOpenAiChatResponse? GetOpenAiChat(JobSummary summary)
    {
        using var db = jobs.OpenDb();

        var activeTask = db.SingleById<BackgroundJob>(summary.Id);
        if (activeTask != null)
            return new GetOpenAiChatResponse { Result = activeTask };

        using var monthDb = jobs.OpenMonthDb(summary.CreatedDate);
        var completedTask = monthDb.SingleById<CompletedJob>(summary.Id);
        if (completedTask != null)
            return new GetOpenAiChatResponse { Result = completedTask };

        var failedTask = monthDb.SingleById<FailedJob>(summary.Id);
        if (failedTask != null)
        {
            return new GetOpenAiChatResponse
            {
                Result = failedTask,
                ResponseStatus = failedTask.Error
            };
        }
        return null;
    }
    
    public object? Any(GetOpenAiChat request)
    {
        var summary = GetJobSummary(request.Id, request.RefId);
        if (summary == null)
            return HttpError.NotFound("JobSummary not found");

        var response = GetOpenAiChat(summary);
        if (response != null)
            return response;
        return HttpError.NotFound("Job not found");
    }
    
    public object Any(GetActiveProviders request) => new GetActiveProvidersResponse
    {
        Results = appData.ApiProviders
    };

    public async Task<object> Any(ChatApiProvider request)
    {
        var provider = appData.AssertApiProvider(request.Provider);

        var openAiRequest = request.Request;
        if (openAiRequest == null)
        {
            if (string.IsNullOrEmpty(request.Prompt))
                throw new ArgumentNullException(nameof(request.Prompt));
            
            openAiRequest = new OpenAiChat
            {
                Model = request.Model,
                Messages = [
                    new() { Role = "user", Content = request.Prompt },
                ],
                MaxTokens = 512,
                Stream = false,
            };
        }
        
        var chatProvider = appData.GetOpenAiProvider(provider);
        var response = await chatProvider.ChatAsync(provider, openAiRequest);
        return response.Response;
    }

    public object Any(CreateApiKey request)
    {
        var apiKeysFeature = AssertPlugin<ApiKeysFeature>();
        var apiKey = request.ConvertTo<ApiKeysFeature.ApiKey>();
        apiKeysFeature.InsertAll(Db, [apiKey]);
        return apiKey.ConvertTo<CreateApiKeyResponse>();
    }
    
    public object Any(AdminAddModel request)
    {
        var aiModel = Db.Single<AiModel>(x => x.Name == request.Model.Name);
        if (aiModel == null)
        {
            Db.Insert(request.Model);
        }

        if (request.ApiTypes != null)
        {
            var typeNames = request.ApiTypes.Keys.ToList();
            var apiTypes = Db.Select<ApiType>(x => typeNames.Contains(x.Name));
            foreach (var apiType in apiTypes)
            {
                var apiTypeModel = request.ApiTypes[apiType.Name];
                apiType.ApiModels[apiTypeModel.Name] = apiTypeModel.Value;
                Db.UpdateOnlyFields(apiType, x => x.ApiModels, 
                    x => x.Id == apiType.Id);
            }
        }

        if (request.ApiProviders != null)
        {
            var providerNames = request.ApiProviders.Keys.ToList();
            var apiProviders = Db.Select<ApiProvider>(x => providerNames.Contains(x.Name));
            foreach (var apiProvider in apiProviders)
            {
                // if (await Db.Exists<ApiProviderModel>(x => x.ApiProviderId == apiProvider.Id && x.Model == request.Model.Name))
                //     continue;
                //
                // var apiProviderModel = request.ApiProviders[apiProvider.Name];
                // apiProviderModel.ApiProviderId = apiProvider.Id;
                // Db.Insert(apiProviderModel);
            }
        }

        return new EmptyResponse();
    }

    public object Any(CreateApiProvider request)
    {
        if (request.SelectedModels.IsEmpty() && request.Models.IsEmpty())
            throw new ArgumentNullException(nameof(CreateApiProvider.SelectedModels), "No Models selected");
                
        if (request.SelectedModels != null)
        {
            request.Models ??= [];
            foreach (var selectedModel in request.SelectedModels)
            {
                var qualifiedModel = appData.GetQualifiedModel(selectedModel);
                if (qualifiedModel == null)
                    continue;
                request.Models.Add(new()
                {
                    Model = qualifiedModel,
                    ApiModel = selectedModel
                });
            }
        }
        
        var response = autoQuery.Create(request, base.Request, Db);
        appData.ResetApiProviders(Db); 
        return response;
    }

    public object Any(UpdateApiProvider request)
    {
        var ignore = new[] { nameof(request.Id), nameof(request.SelectedModels) };
        // Only call AutoQuery Update if there's something to update
        IdResponse? response = null;
        if (request.SelectedModels is { Count: > 0 })
        {
            request.Models ??= [];
            foreach (var selectedModel in request.SelectedModels)
            {
                var qualifiedModel = appData.GetQualifiedModel(selectedModel);
                if (qualifiedModel == null)
                    continue;
                request.Models.Add(new()
                {
                    Model = qualifiedModel,
                    ApiModel = selectedModel
                });
            }
        }
        if (request.ToObjectDictionary().HasNonDefaultValues(ignoreKeys:ignore) || Request!.QueryString[Keywords.Reset] != null)
        {
            response = (IdResponse) autoQuery.Patch(request, base.Request, Db);
            appData.ResetApiProviders(Db);
        }
        
        response ??= request.ConvertTo<IdResponse>();
        return response;
    }

    // public object Any(DeleteApiProvider request)
    // {
    //     var response = autoQuery.Delete(request, base.Request, Db);
    //     appData.ResetApiProviders(Db); 
    //     return response;
    // }
}
