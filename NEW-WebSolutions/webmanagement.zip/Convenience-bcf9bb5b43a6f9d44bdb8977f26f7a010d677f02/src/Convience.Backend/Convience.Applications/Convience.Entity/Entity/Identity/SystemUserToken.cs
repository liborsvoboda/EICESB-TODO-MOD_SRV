﻿using Microsoft.AspNetCore.Identity;

namespace Convience.Entity.Entity.Identity
{
    public class SystemUserToken : IdentityUserToken<int>
    {
    }
}
