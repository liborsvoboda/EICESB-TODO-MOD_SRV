﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TwainDotNet.TwainNative
{
    public enum Duplex : short
    {
        None = 0,
        OnePass = 1,
        TwoPass = 2
    }
}
