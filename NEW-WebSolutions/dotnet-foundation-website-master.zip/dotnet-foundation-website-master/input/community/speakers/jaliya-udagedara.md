---
Title: Jaliya Udagedara
Location: Auckland, New Zealand
Email: jaliya.udagedara@hotmail.com
Language:
  - English
  - Sinhalese
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Architecture
  - Azure
  - C#
  - Containers
  - Entity Framework
  - Microservices
  - SignalR
  - Web Development
Blog: http://www.jaliyaudagedara.blogspot.com/
Feed: https://jaliyaudagedara.blogspot.com/feeds/posts/default
Twitter: https://twitter.com/JaliyaUdagedara
GitHub: https://github.com/jaliyaudagedara
StackOverflow: https://stackoverflow.com/users/4865541/jaliya-udagedara
LinkedIn: https://www.linkedin.com/in/jaliyaudagedara/
Sessionize: https://sessionize.com/jaliya-udagedara
Mentor: true
---
Jaliya is originally from Sri Lanka and currently based in Auckland, New Zealand. He is working as a Technical Lead for a US-based software company and he is a Microsoft MVP since 2014.  He has found his most significant interest in the world of .NET/.NET Core/ASP.NET/ASP.NET Core and Azure. And of course, uses C# as the proficient and primary programming language.
