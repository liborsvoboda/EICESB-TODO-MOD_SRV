export class DicType {
    id?: number;
    code?: string;
    name?: string;
    sort?: number;    
}