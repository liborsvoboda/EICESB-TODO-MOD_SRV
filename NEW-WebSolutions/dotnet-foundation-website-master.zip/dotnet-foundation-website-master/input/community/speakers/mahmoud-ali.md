---
Title: Mahmoud Ali
Location: São Paulo, Brazil
Language:
  - Portuguese
  - English
Topics:
  - .NET
  - Android
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Architecture
  - C#
  - DevOps
  - Entity Framework
  - iOS
  - JavaScript
  - Mobile Development
  - Open Source
  - Visual Studio
  - Visual Studio Code
  - Visual Studio for Mac
  - Web Development
  - Xamarin
  - Xamarin.Forms
Blog: http://high5devs.com/author/akamud/
Twitter: https://twitter.com/akamud
GitHub: https://github.com/akamud
LinkedIn: https://www.linkedin.com/in/akamud/
MeetUp: https://www.meetup.com/pt-BR/High5Devs
YouTube: https://www.youtube.com/channel/UCPW7Ta5nqm-Rs1DuFaGc0uw
Mentor: true
---
Developer @ Lambda3, Microsoft MVP, speaker, open source enthusiast, gamer, and beer hunter
