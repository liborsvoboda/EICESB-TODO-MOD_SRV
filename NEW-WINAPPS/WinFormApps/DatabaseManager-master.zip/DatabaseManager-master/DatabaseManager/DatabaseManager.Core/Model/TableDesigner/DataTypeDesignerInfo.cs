﻿using System;
using System.Collections.Generic;
using System.Text;
using DatabaseInterpreter.Model;

namespace DatabaseManager.Model
{
    public class DataTypeDesignerInfo : DataTypeSpecification
    {
        
    }
}
