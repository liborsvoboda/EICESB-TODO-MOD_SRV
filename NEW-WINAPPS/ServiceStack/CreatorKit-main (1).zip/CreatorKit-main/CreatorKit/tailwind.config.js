module.exports = {
  content: ["./wwwroot/**/*.{html,js,mjs,md,cshtml,razor}","./Pages/**/*.{cshtml,razor}","../CreatorKit.ServiceModel/**/*.cs"],
  darkMode: 'class',
  plugins: [],
}
