﻿One of Markdown Monsters main features is its extensibility. There are many Markdown Editors out there but MM provides the ability to extend the existing functionality by allowing you to plug into the main applications via Addins.

This section describes how to create add-ins and documents a couple of the built in add-ins.

<%=  ChildTopicsList(oHelp,"") %>