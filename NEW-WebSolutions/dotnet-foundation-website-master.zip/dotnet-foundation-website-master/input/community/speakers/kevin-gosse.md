---
Title: Kevin gosse
Location: Paris, France
Email: kevin.gosse@outlook.com
Language:
  - English
  - French
Topics:
  - .NET
  - C#
Blog: https://medium.com/@kevingosse
Feed: https://medium.com/feed/@kevingosse
Twitter: https://twitter.com/kookiz/
GitHub: https://github.com/kevingosse
StackOverflow: https://stackoverflow.com/users/869621/kevin-gosse
LinkedIn: https://www.linkedin.com/in/kevingosse/
Mentor: true
---

