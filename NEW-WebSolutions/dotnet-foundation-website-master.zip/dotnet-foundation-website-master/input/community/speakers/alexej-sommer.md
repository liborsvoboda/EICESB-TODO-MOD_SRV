---
Title: Alexej Sommer
Location: Minsk, Belarus
Email: asommer@yandex.ru
Language:
  - Russian
  - English
  - German
Topics:
  - .NET
  - ASP.NET
  - Architecture
  - C#
  - Containers
  - IoT
  - Security
  - Serverless
  - Web Development
  - Xamarin
Blog: https://habr.com/ru/users/asommer/posts/
GitHub: https://github.com/programmersommer
StackOverflow: https://stackoverflow.com/users/4699676/alexej-sommer
LinkedIn: https://www.linkedin.com/in/alexejsommer
Instagram: https://www.instagram.com/alexejsommer/
---
Professional .NET developer (UWP/WPF/Xamarin/ASP.NET Core) with MCP/MCSD certificates. MVP 2016-2019 (Windows Development)
