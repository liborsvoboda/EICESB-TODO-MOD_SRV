﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NuGet.Services.Dashboard.Common")]
[assembly: AssemblyDescription("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("aeae461d-c225-4567-99f3-9e62e898d8ab")]
