﻿namespace SqlAnalyser.Model
{
    public class ViewScript : CommonScript
    {
    }
}
