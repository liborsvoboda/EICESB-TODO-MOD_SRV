namespace PetStoreApp.PetStore
{
public enum PetStatus {

    Available,
    Pending,
    Sold,
    }
}





