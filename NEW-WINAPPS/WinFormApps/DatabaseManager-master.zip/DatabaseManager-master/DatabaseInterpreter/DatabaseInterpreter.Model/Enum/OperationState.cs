﻿namespace DatabaseInterpreter.Model
{
    public enum OperationState
    {
        Begin,
        End
    }
}
