Title: Dmitry Lyalin
Location: New Yorker WFH near Redmond, WA
Email: dmitry.lyalin@lyalin.com
Language:
  - English
Topics:
  - .NET
  - C#
  - Mobile Development
  - Product Management
  - UWP
  - Visual Studio
  - Windows Development
  - WPF
  - Xamarin
  - Xamarin.Forms
Twitter: https://twitter.com/lyalindotcom
GitHub: https://github.com/lyalindotcom
---
Senior Program Manager for Visual Studio focused on XAML tooling and Hot Reload.
