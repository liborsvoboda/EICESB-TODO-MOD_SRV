﻿namespace Westwind.WebView.HtmlToPdf
{
    internal enum PdfPrintOutputModes
    {
        File,
        Stream
    }
}