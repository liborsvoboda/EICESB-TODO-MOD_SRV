﻿namespace DatabaseConverter.Core.Model.Functions
{
    public struct DateAdd
    {
        public string Unit { get; set; }
        public string Date { get; set; }
        public string IntervalNumber { get; set; }
    }
}
