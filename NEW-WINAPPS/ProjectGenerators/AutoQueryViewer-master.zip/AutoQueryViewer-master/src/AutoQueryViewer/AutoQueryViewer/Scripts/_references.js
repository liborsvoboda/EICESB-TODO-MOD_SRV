﻿//Add JS/CSS references here to enable intellisense from external packages.
/// <reference path="~/bower_components/jquery/dist/jquery.js" />
/// <reference path="~/bower_components/bootstrap/dist/js/bootstrap.js" />
/// <reference path="~/bower_components/angular/angular.js" />
/// <reference path="~/bower_components/angular-route/angular-route.js" />
/// <reference path="~/node_modules/karma-jasmine/lib/jasmine.js" />
/// <reference path="~/node_modules/gulp/index.js"/>
/// <reference path="~/bower_components/bootstrap/dist/css/bootstrap.css"/>
/// <reference path="~/node_modules/grunt/lib/util/task.js"/>