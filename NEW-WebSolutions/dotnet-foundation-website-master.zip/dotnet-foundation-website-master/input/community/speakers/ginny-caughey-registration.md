---
Title: Ginny Caughey
Location: Wilmington NC USA
Email: ginny.caughey@wasteworks.com
Language:
  - English
Topics:
  - .NET
  - C#
  - UWP
  - Windows Development
  - Windows Forms
  - WPF
Twitter: https://twitter.com/gcaughey
GitHub: https://github.com/gcaughey
Mentor: true
---
For several decades I've been a speaker at big tech conferences such as Build, and TechEd, tiny meetings like my local .NET user group, and many in-between sized conferences in the US, Europe, UK, and Australia.  I've even participated in several on-line events as a speaker, so I'm very familiar with stage fright and imposter syndrome in all its forms. ;-) But I still enjoy sharing what I've learned with others.
