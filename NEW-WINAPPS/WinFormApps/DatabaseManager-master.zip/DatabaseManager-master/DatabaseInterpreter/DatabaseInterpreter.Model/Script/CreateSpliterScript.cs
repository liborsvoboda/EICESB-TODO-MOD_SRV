﻿namespace DatabaseInterpreter.Model
{
    public class SpliterScript:Script
    {
        public SpliterScript(string script) : base(script) { }        
    }
}
