﻿/** @jsx React.DOM */
React.render(
    <AutoQueryServices />, document.getElementById('demo')
);