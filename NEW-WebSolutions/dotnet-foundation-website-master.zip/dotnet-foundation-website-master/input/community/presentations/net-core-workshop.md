﻿---
type: workshop
id: net-core-workshop
title: .NET Core Workshop
repo: dotnet-presentations/dotnetcore-workshop
link: https://github.com/dotnet-presentations/dotnetcore-workshop
---

Are you ready to get started with .NET Core? This one day workshop covers the basics, then digs into web development with ASP.NET Core, .NET Standard, porting from .NET Framework, and containers.