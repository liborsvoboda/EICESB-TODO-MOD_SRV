﻿namespace  DatabaseInterpreter.Core
{
    public class SqliteProvider:IDbProvider
    {
        public string ProviderName => "Microsoft.Data.Sqlite";           
    }
}
