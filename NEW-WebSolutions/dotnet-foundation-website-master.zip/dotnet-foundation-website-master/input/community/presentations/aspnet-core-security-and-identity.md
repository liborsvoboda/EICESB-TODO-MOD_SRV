﻿---
type: deck
id: aspnet-core-security-and-identity
title: ASP.NET Core - Security and Identity
link: https://github.com/dotnet-presentations/home/tree/master/Security/ASP.NET%20Core%202.0
---

Overview of Security and Identity in ASP.NET Core 2.0, including Authorization Policies, Cookie Auth, and TOTP. Demos included.