﻿namespace DatabaseConverter.Core.Model.Functions
{
    public struct DateDiff
    {
        public string Unit { get; set; }
        public string Date1 { get; set; }
        public string Date2 { get; set; }
    }
}
