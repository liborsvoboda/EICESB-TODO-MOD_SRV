---
Title: Welcoming NEO to the .NET Foundation
Author: Jon Galloway
Published: 2019-09-24 19:14:44.4350337
---
<p><img alt="NEO smart economy" src="https://neo-cdn.azureedge.net/images/neo-logo/NEO-smart-economy-logo.svg" style="float: right; width: 300px; height: 129px;" />Today, I'm excited to welcome <a href="https://neo.org/">NEO</a> as the very first blockchain platform to join our community.&nbsp; NEO is a pioneer in adopting the .NET platform, and we support them in building an innovative decentralized platform and developer community. NEO is joining the .NET Foundation at an exciting time of growth for the .NET Foundation, as well, and we're very happy to have them on-board!</p>

<p>The NEO team has a great writeup their platform and the community they've built for .NET developers <a href="https://neo.org/blog/details/4179">here</a>.</p>

<p>Welcome!</p>
