﻿namespace Convience.Model.Models
{
    public record PageQueryModel
    {
        public int Page { get; set; }

        public int Size { get; set; }
    }

}
