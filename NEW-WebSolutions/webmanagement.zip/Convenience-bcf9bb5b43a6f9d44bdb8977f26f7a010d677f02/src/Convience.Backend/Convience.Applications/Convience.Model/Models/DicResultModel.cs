﻿namespace Convience.Model.Models
{
    public class DicResultModel
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
