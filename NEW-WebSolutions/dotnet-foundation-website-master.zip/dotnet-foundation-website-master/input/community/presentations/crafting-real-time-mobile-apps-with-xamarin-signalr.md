﻿---
type: deck
id: crafting-real-time-mobile-apps-with-xamarin-signalr
title: Crafting Real-time Mobile Apps with Xamarin & SignalR
link: https://github.com/dotnet-presentations/xamarin/tree/master/SignalR-%20Real-time%20Communication%20for%20Xamarin
---

Stop polling and enable bi-directional communication between your server and mobile apps, in real-time. Better yet share all your real-time communication business logic between iOS and Android Xamarin apps with .NET Standard and SignalR.