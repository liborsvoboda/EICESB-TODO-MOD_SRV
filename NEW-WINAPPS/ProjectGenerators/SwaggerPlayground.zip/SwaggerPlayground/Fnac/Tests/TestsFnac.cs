﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fnac.Tests
{
    public class TestsFnac
    {
    }
}
