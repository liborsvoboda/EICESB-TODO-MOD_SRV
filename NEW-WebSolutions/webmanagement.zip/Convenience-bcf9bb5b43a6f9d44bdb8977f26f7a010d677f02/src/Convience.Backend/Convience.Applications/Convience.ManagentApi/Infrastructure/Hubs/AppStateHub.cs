﻿using Microsoft.AspNetCore.SignalR;

namespace Convience.ManagentApi.Infrastructure.Hubs
{
    public class AppStateHub : Hub<IAppStateCient>
    {
    }
}
