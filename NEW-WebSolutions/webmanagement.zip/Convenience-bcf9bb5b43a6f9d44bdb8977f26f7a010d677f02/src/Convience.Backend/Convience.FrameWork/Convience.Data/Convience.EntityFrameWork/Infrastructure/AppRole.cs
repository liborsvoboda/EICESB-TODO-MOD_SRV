﻿using Microsoft.AspNetCore.Identity;

namespace Convience.EntityFrameWork.Infrastructure
{
    public class AppRole : IdentityRole
    {
    }
}
