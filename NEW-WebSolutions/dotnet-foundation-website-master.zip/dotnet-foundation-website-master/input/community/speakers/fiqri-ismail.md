---
Title: Fiqri Ismail
Location: Colombo, Sri Lanka
Email: fiqri@peachit.lk
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - ASP.NET Web API
  - Azure
  - Blazor
  - C#
  - Microsoft 365
  - Microsoft Graph
Blog: https://www.askfiqri.com
Twitter: https://twitter.com/fiqriismail
GitHub: https://github.com/fiqriismail
LinkedIn: https://linkedin.com/in/fiqriismail
Sessionize: https://sessionize.com/fiqriismail
MeetUp: https://www.meetup.com/members/69637472/
YouTube: https://www.youtube.com/askfiqri
Instagram: https://www.instagram.com/fiqriismail/
Mentor: true
---
Experienced Architect and Author of the book ".NET Standard 2.0 Cook Book". 
Also demonstrated history of working in the information technology and services industry. Skilled in ASP.NET, ASP.NET MVC, ASP.NET Core, Entity Framework, C#, Azure, PHP and Delphi. 
Also Microsoft MVP in Visual Studio and Related Technologies for 11 consecutive years to date. As well as a Community Leader, Speaker at Sri Lanka Developer Forum and a Blogger.
