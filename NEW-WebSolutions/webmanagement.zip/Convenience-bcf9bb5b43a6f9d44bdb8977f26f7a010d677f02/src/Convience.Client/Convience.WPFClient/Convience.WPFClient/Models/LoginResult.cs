﻿namespace Convience.WPFClient.Models
{
    public class LoginResult
    {
        public string Name { get; set; }

        public string Avatar { get; set; }

        public string Token { get; set; }

        public string Identification { get; set; }

        public string Routes { get; set; }
    }
}
