﻿---
image: /img/dot_bot.png
permalink: about/election/example
---

# .NET Foundation Campaign: [Your Name Here]

## Why I'm Running
Hi, I'm Example McExampleface, and I want to make a difference in the .NET Open Source community.

I think we really need to focus on the student community. If elected, I'm going to work hard to
get students involved.

## My .NET Open Source Contributions
I have lead the nExample project for the past few years.

## Links
* [My blog](https://dotnetfoundation.org/blog)

## Contact Information
* Twitter: [&#64;dotnetfdn](https://twitter.com/dotnetfdn)
* GitHub: [&#64;dotnet](https://github.com/dotnet)
