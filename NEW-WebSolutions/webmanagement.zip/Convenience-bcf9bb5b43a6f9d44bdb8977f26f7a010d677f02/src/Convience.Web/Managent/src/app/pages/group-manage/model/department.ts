export class Department {
    id?: number;
    upId?: string;
    name?: string;
    email?: string;
    telephone?: string;
    leaderId?: number;
    leaderName?: string;
    sort?: number;
}