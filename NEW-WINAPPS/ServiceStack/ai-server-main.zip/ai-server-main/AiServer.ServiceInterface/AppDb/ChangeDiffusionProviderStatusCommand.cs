using System.Data;
using AiServer.ServiceModel;
using AiServer.ServiceModel.Types;
using ServiceStack;
using ServiceStack.OrmLite;

namespace AiServer.ServiceInterface.AppDb;

public class ChangeGenerationProviderStatus
{
    public string Name { get; set; }
    public DateTime? OfflineDate { get; set; }
}

[Tag(Tags.Database)]
[Worker(Workers.AppDb)]
public class ChangeGenerationProviderStatusCommand(AppData appData, IDbConnection db) 
    : SyncCommand<ChangeGenerationProviderStatus>
{
    protected override void Run(ChangeGenerationProviderStatus request)
    {
        db.UpdateOnly(() => new GenerationApiProvider
        {
            OfflineDate = request.OfflineDate,
        }, where: x => x.Name == request.Name);

        var apiProvider = appData.GenerationApiProviders.FirstOrDefault(x => x.Name == request.Name);
        if (apiProvider != null)
            apiProvider.OfflineDate = request.OfflineDate;
    }
}
