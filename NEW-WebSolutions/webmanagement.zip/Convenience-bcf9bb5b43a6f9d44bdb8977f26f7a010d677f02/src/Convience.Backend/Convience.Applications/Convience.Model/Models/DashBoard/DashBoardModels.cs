﻿namespace Convience.Model.Models.DashBoard
{
    public class DashBoardResultModel
    {
        public long UserCount { get; set; }

        public long RoleCount { get; set; }

        public long DepartmentCount { get; set; }

        public long PositionCount { get; set; }
    }
}
