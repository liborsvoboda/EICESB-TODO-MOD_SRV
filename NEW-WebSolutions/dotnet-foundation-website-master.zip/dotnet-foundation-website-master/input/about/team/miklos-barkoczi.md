---
title: Miklos Barkoczi
image: miklos-barkoczi.png
order: 2
twitter: 
---

I'm **Miklos Barkoczi**, the Treasurer of the .NET Foundation. I'm the man with the check book. Be nice to me. What's twitter?
