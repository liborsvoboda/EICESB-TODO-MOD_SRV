# Showcase

This project contains only .Designer.cs files created by TerminalGuiDesigner.

The purpose of the project is to ensure backwards compatibility issues are detected quickly as well as providing more structure for manual testing