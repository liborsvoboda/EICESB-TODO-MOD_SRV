﻿using System.Linq;
using System.Text;

namespace Westwind.WeblogPostService.Model
{
    public enum PostStatuses
    {
        Published,
        Draft,
        Pending,
        Future,
    }
}
