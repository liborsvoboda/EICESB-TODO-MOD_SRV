---
Title: Kalpesh Satasiya
Location: Ahmedabad, India
Email: satasiya.kalpesh2006@gmail.com
Language:
  - English
  - Hindi
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - C#
  - JavaScript
Blog: https://www.tech-coder.com/
Twitter: https://twitter.com/satasiyakalpesh
GitHub: https://github.com/kalpeshsatasiya
StackOverflow: https://stackoverflow.com/users/3122889/kalpesh-satasiya
LinkedIn: https://www.linkedin.com/in/kalpesh-satasiya-72123b17/
YouTube: https://www.youtube.com/channel/UC0psuorhF7O547RZCmddh5w
Mentor: true
Mentee: true
---
Kalpesh Satasiya is an MVP (Microsoft Valuable Professional) , computer geek, developer, mentor, and life-long learner. He has 10+ years of experience in Microsoft.NET technologies.

He had completed B.Sc(Physics) and Masters of Computer Application from Veer Narmada South Gujarat University.

He started his career working with Microsoft.NET framework 2.0 and then He moved to ASP.NET and still exploring ASP.NET 4.6, ASP.NET Core 1.0/2.0/2.2/3.x and ASP.NET Core MVC. Right now.

