﻿namespace Convience.Model.Models.ContentManage
{

    public class ColumnViewModel
    {
        public int Id { get; set; }

        public string UpId { get; set; }

        public string Name { get; set; }

        public int Sort { get; set; }
    }


    public class ColumnResultModel : ColumnViewModel
    {
    }
}
