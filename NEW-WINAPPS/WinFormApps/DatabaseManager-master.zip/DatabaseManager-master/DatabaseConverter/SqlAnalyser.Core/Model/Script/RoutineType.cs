﻿namespace SqlAnalyser.Model
{
    public enum RoutineType
    {
        UNKNOWN = 0,
        FUNCTION = 1,
        PROCEDURE = 2,
        TRIGGER = 3
    }
}
