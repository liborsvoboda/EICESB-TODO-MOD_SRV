---
Title: Abdullah Hamed
Location: Seattle, Washington USA
Email: abhamed@microsoft.com
Language:
  - English
  - Arabic
Topics:
  - Game Development
Twitter: https://twitter.com/indiesaudi
Mentor: true
---
An Arabic game development advocate. I love helping game developers make their vision come true. I love teaching beginners how to make games using .NET and C#. I have over 10 years of experience in the game industry.
