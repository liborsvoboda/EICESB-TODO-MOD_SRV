﻿namespace SqlAnalyser.Model
{
    public abstract class Statement
    {
    }

    public abstract class StatementItem
    {
    }
}
