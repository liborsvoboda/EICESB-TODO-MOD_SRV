﻿namespace SqlAnalyser.Model
{
    public class LeaveStatement : Statement
    {
        public TokenInfo Content { get; set; }
    }
}
