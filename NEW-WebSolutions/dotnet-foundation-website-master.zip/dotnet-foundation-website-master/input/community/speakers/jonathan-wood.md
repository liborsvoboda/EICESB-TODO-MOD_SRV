---
Title: Jonathan Wood
Pronouns: he/him
Location: Raleigh, North Carolina USA
Email: jwood@hey.com
Language:
  - English
Topics:
  - Artificial Intelligence
  - Machine Learning
  - ML.NET
Blog: https://jonwood.co/
Twitter: https://twitter.com/JWood
GitHub: https://github.com/jwood803
StackOverflow: https://stackoverflow.com/users/186013/jon
LinkedIn: https://www.linkedin.com/in/jonathangwood
YouTube: https://www.youtube.com/c/JonWood
---
An early adopter of ML.NET and other Microsoft AI technologies, Jonathan loves to teach what he's learned through is blog and YouTube channel.
