---
Title: Jiri Cincura
Location: Brno, Czechia, Europe
Email: jiri@cincura.net
Language:
  - English
  - Czech
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Architecture
  - Azure
  - C#
  - DevOps
  - Entity Framework
  - Microservices
  - NuGet
  - Open Source
  - Razor
  - Serverless
  - Visual Studio
  - Web Development
  - Windows Development
  - Windows Forms
Blog: https://www.tabsoverspaces.com
Feed: https://www.tabsoverspaces.com/feed.xml
Twitter: https://twitter.com/cincura_net/
GitHub: https://github.com/cincuranet/
Mentor: true
---
[https://www.tabsoverspaces.com/about](https://www.tabsoverspaces.com/about)
