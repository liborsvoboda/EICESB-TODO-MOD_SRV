using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using AiServer.ServiceModel;
using ServiceStack;
using ServiceStack.DataAnnotations;
using ServiceStack.Jobs;

namespace AiServer.ServiceInterface;

public class VideoServices(
    IBackgroundJobs jobs) : Service
{
    public async Task<object> Any(ScaleVideo request)
    {
        // Convert request
        var transformRequest = new CreateTransform()
        {
            Request = new MediaTransformArgs
            {
                ScaleWidth = request.Width,
                ScaleHeight = request.Height,
                TaskType = MediaTransformTaskType.VideoScale
            },
            ReplyTo = request.ReplyTo,
            RefId = request.RefId
        };
        var transformService = base.ResolveService<MediaTransformProviderServices>();
        return await request.ProcessTransform(transformRequest, jobs, transformService);
    }
    
    public async Task<object> Any(WatermarkVideo request)
    {
        string watermarkPosition;
        switch (request.Position)
        {
            case WatermarkPosition.TopLeft:
                watermarkPosition = "10:10";
                break;
            case WatermarkPosition.TopRight:
                watermarkPosition = "main_w-overlay_w-10:10";
                break;
            case WatermarkPosition.BottomLeft:
                watermarkPosition = "10:main_h-overlay_h-10";
                break;
            case WatermarkPosition.BottomRight:
                watermarkPosition = "main_w-overlay_w-10:main_h-overlay_h-10";
                break;
            case WatermarkPosition.Center:
                watermarkPosition = "(main_w-overlay_w)/2:(main_h-overlay_h)/2";
                break;
            case null:
            default:
                watermarkPosition = "main_w-overlay_w-10:main_h-overlay_h-10"; // Default to BottomRight
                break;
        }

        // Convert request
        var transformRequest = new CreateTransform()
        {
            Request = new MediaTransformArgs
            {
                WatermarkPosition = watermarkPosition,
                TaskType = MediaTransformTaskType.WatermarkVideo
            },
            ReplyTo = request.ReplyTo,
            RefId = request.RefId
        };

        var transformService = base.ResolveService<MediaTransformProviderServices>();
        return await request.ProcessTransform(transformRequest, jobs, transformService);
    }
    
    private bool IsVideoFormat(MediaTransformOutputFormat outputFormat)
    {
        switch (outputFormat)
        {
            case MediaTransformOutputFormat.MP4:
            case MediaTransformOutputFormat.AVI:
            case MediaTransformOutputFormat.MKV:
            case MediaTransformOutputFormat.MOV:
            case MediaTransformOutputFormat.WebM:
                return true;
            case MediaTransformOutputFormat.GIF:
            case MediaTransformOutputFormat.MP3:
            case MediaTransformOutputFormat.WAV:
            case MediaTransformOutputFormat.FLAC:
                return false;
            default:
                throw new ArgumentOutOfRangeException(nameof(outputFormat), outputFormat, null);
        }
    }
    
    public async Task<object> Any(ConvertVideo request)
    {
        if (Request?.Files == null || Request.Files.Length == 0)
        {
            throw new ArgumentException("No video file provided");
        }

        var mediaOutputFormat = Enum.Parse<MediaTransformOutputFormat>(request.OutputFormat.ToString());
        if(!IsVideoFormat(mediaOutputFormat))
            throw new ArgumentException("Invalid output format");
        
        var transformService = base.ResolveService<MediaTransformProviderServices>();

        var transformRequest = new CreateTransform
        {
            Request = new MediaTransformArgs
            {
                OutputFormat = mediaOutputFormat,
                TaskType = MediaTransformTaskType.VideoConvert
            },
            ReplyTo = request.ReplyTo,
            RefId = request.RefId
        };

        return await request.ProcessTransform(transformRequest, jobs, transformService);
    }
    
    public async Task<object> Any(CropVideo request)
    {
        // Convert request
        var transformRequest = new CreateTransform
        {
            Request = new MediaTransformArgs
            {
                CropX = request.X,
                CropY = request.Y,
                CropWidth = request.Width,
                CropHeight = request.Height,
                TaskType = MediaTransformTaskType.VideoCrop
            },
            ReplyTo = request.ReplyTo,
            RefId = request.RefId
        };

        var transformService = base.ResolveService<MediaTransformProviderServices>();
        return await request.ProcessTransform(transformRequest, jobs, transformService);
    }
    
    public async Task<object> Any(TrimVideo request)
    {
        if (Request?.Files == null || Request.Files.Length == 0)
        {
            throw new ArgumentException("No video file provided");
        }
        
        // Validate request.StartTime is in format "mm:ss"
        if (!Regex.IsMatch(request.StartTime, @"^\d{2}:\d{2}$"))
        {
            throw new ArgumentException("Invalid start time format");
        }
        
        // Validate request.EndTime is in format "mm:ss"
        if (request.EndTime != null && !Regex.IsMatch(request.EndTime, @"^\d{2}:\d{2}$"))
        {
            throw new ArgumentException("Invalid end time format");
        }

        // Convert request
        var transformRequest = new CreateTransform
        {
            Request = new MediaTransformArgs
            {
                CutStart = ParseTime(request.StartTime),
                CutEnd = ParseTime(request.EndTime),
                TaskType = MediaTransformTaskType.VideoCut
            },
            ReplyTo = request.ReplyTo,
            RefId = request.RefId
        };

        var transformService = base.ResolveService<MediaTransformProviderServices>();
        return await request.ProcessTransform(transformRequest, jobs, transformService);
    }
    
    private float ParseTime(string? time)
    {
        if(time == null || time.StartsWith("-"))
            return -1;
        var parts = time.Split(':');
        return int.Parse(parts[0]) * 60 + int.Parse(parts[1]);
    }
}

public static class TransformServiceExtensions
{
    public static async Task<object> ProcessTransform(this QueueTransformBase request, CreateTransform transformRequest,
        IBackgroundJobs jobs,
        MediaTransformProviderServices transformService)
    {
        CreateTransformResponse? transformResponse = null;
        try
        {
            var response = await transformService.Any(transformRequest);
            transformResponse = response as CreateTransformResponse;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
        
        if(transformResponse == null)
            throw new Exception("Failed to start transform");
        
        var job = jobs.GetJob(transformResponse.Id);
        // For synchronous requests, wait for the job to be created
        while (job == null)
        {
            await Task.Delay(1000);
            job = jobs.GetJob(transformResponse.Id);
        }
        
        // We know at this point, we definitely have a job
        JobResult queuedJob = job;
        
        var completedResponse = new TransformResponse
        {
            RefId = transformResponse.RefId,
            JobId = transformResponse.Id,
            Status = queuedJob.Job?.Status,
            JobState = queuedJob.Job?.State ?? queuedJob.Summary.State
        };

        // Handle failed jobs
        if (job.Failed != null)
        {
            completedResponse.ResponseStatus = job.Failed.Error;
        }
        
        // If not a synchronous request, return immediately with job details
        if (request.Sync != true)
        {
            return completedResponse;
        }
        
        // Wait for the job to complete max 1 minute
        var timeout = DateTime.UtcNow.AddMinutes(1);
        while (queuedJob?.Job?.State is not (BackgroundJobState.Completed or BackgroundJobState.Cancelled
               or BackgroundJobState.Failed) && DateTime.UtcNow < timeout)
        {
            await Task.Delay(1000);
            queuedJob = jobs.GetJob(transformResponse.Id);
        }
        
        // Process successful job results
        var outputs = new List<ArtifactOutput>();
        var jobReqRes = queuedJob.Job!.ExtractRequestResponse<CreateTransform, TransformResult>();
        var jobReq = jobReqRes.Item1;
        var jobRes = jobReqRes.Item2;
        if (jobRes != null)
        {
            // Map job outputs to ArtifactOutputs
            foreach (var output in jobRes.Outputs ?? [])
            {
                outputs.Add(new ArtifactOutput
                {
                    FileName = output.FileName,
                    Url = output.Url,
                    Provider = jobReq?.Provider,
                });
            }
            completedResponse.Outputs = outputs;
        }
        
        // Update the job state
        completedResponse.JobState = queuedJob.Job?.State ?? queuedJob.Summary.State;
        completedResponse.Status = queuedJob.Job?.Status;

        return completedResponse;
    }
}