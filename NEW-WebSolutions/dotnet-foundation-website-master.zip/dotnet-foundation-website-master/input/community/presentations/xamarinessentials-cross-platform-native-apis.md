﻿---
type: deck
id: xamarinessentials-cross-platform-native-apis
title: Xamarin.Essentials - Cross-platform Native APIs
link: https://github.com/dotnet-presentations/mobile/tree/master/Xamarin.Essentials
---

Xamarin.Essentials, a powerful cross-platform library that provides a clean and lightweight API to access common features on mobile platforms, in your cross-platform C# apps without writing abstractions or platform-specific code.