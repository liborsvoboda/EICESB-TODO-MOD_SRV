---
Title: Kundan Karma
Email: kundan.karma@microsoft.com
Language:
  - English
Topics:
  - ML.NET
LinkedIn: https://www.linkedin.com/in/kundan-karma-31143121/
---
14+ years of Software development / designing experience.

•	Bachelor of Engineering (B.E.) in Information Technology 
•	Post Graduate Diploma in Machine Learning and Artificial Intelligence from “International Institute of Information Technology Bangalore (IIIT-B)” 

Technology expertise:
C#.NET, Azure IoT, Azure (LogicApps, Azure Functions, Cosmos-DB, Azure SQL, WebAPI, StorageAccounts, ServiceBus,Event-Hub etc.), Dynamics-365 CRM (Customer Service, Field Service, Connected Field Service [IoT] etc,),D365 CRM portals, BizTalk, ML.NET, Python, Azure DevOps (CI/CD), Powershell, ARM template deployment
Programming Languages:
ML.NET, C#.NET, Python, Python for Machine Learning (sklearn, pandas, keras, numpy, pgmpy, nltk etc. ), SQL, PL/SQL, VB.NET, JavaScript, C,C++ 
Databases: SQL Server, Azure SQL, Oracle, Azure CosmosDB, MySQL etc.

ML.NET work published : https://dotnet.microsoft.com/apps/machinelearning-ai/ml-dotnet/customers/microsoft-real-estate-and-security 


Three times speaker in Microsoft Ready

