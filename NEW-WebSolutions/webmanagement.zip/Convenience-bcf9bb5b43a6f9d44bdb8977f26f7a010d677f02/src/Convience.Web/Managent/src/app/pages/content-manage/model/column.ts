export class Column {
    id?: number;
    upId?: string;
    name?: string;
    sort?: number;
}