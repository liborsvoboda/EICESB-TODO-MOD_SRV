// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("3f7df594-3ac4-4ed6-93c3-1dcfee7600c6")]
[assembly: ComVisible(false)]
