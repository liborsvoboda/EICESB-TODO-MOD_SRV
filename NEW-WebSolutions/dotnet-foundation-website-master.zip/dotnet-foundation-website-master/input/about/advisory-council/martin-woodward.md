---
title: Martin Woodward
image: martin-woodward.jpg
twitter: martinwoodward
location: United Kingdom
order: 2
company: GitHub
advisor: true
---

Former Executive Director. Director of DevRel for GitHub.
