﻿You can import Markdown from HTML from the clipboard or export Markdown as HTML to the clipboard

![](../images/PasteHtmlAsMarkdow.png)

### Importing HTML as Markdown
You can capture HTML on the clipboard as:

* Plain HTML text
* Rich HTML text

To import Markdown stored on the clipboard:

* Select your Markdown document
* Move the cursor to where you want to import the HTML
* Note this can be an empty document to fill the entire doc
* Use the Edit Menu options
* Use *Paste HTML as Markdown* option  or **ctrl-shift-v**

### Exporting HTML from Markdown
You can also take a selection of your Markdown document (or the entire document) and export it as HTML to the clipboard.

To do this:

* Select some text in your document or the entire document
* Goto to the Edit | Copy Markdown as HTML menu choice

Move to another application and paste the HTML.

Note that this option exports only the HTML text, not related images.
