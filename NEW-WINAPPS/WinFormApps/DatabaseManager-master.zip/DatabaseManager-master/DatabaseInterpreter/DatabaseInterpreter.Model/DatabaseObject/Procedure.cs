﻿namespace DatabaseInterpreter.Model
{
    public class Procedure : ScriptDbObject
    {       
    }
}
