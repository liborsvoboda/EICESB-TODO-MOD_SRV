﻿namespace SqlAnalyser.Model
{
    public class TruncateStatement : Statement
    {
        public TableName TableName { get; set; }       
    }
}
