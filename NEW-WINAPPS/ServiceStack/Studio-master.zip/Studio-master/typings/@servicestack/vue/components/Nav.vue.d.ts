import { NavBase } from '../core';
export declare class Nav extends NavBase {
    protected readonly opt: any;
}
export default Nav;
