﻿namespace DatabaseConverter.Model
{
    public class VariableMapping
    {
        public string DbType { get; set; }
        public string Variable { get; set; }      
    }
}
