---
title: Lea Wegner
image: campaign-2019/7fdddbc7-57d2-4ece-9f64-edaae7c0521b.jpg
---

# .NET Foundation Campaign: Lea Wegner

## Why I'm Running
Hey, i'm Lea Wegner and i'm a dual computer science student from germany. 
The dual study system gives me the oppurtunity to work in the software industry since my beginning in 2017. To be honest i did not worked with .NET at this point, but i'm interested in learning new things and can bring you my unimpaired opinions, the view of a student and a newcomer, and the knowledge about how it is to work in germany as a young woman in the software industry.

## Contact Information
* Email: lea_wegner@gmx.de
