﻿namespace DatabaseInterpreter.Model
{
    public class View : ScriptDbObject
    {  
          
    }
}
