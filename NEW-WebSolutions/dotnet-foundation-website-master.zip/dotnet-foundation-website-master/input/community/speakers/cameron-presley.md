---
Title: Cameron Presley
Pronouns: he/him
Location: Charlotte, North Carolina USA
Email: Cameron@TheSoftwareMentor.com
Language:
  - English
Topics:
  - .NET
  - Architecture
  - C#
  - F#
  - Human Skills
  - JavaScript
  - Windows Forms
Blog: https://blog.thesoftwarementor.com
Twitter: https://twitter.com/pcameronpresley
GitHub: https://github.com/cameronpresley
LinkedIn: https://linkedin.com/in/pcameronpresley
Sessionize: https://sessionize.com/cameronpresley
Mentor: true
---
I have over five years experience speaking at conferences and user groups. You can see some of the feedback I've received for my presentations at http://blog.thesoftwarementor.com/feedback/
