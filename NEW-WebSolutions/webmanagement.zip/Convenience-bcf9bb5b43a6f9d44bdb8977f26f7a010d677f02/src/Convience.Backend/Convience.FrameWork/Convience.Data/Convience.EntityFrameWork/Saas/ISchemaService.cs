﻿namespace Convience.EntityFrameWork.Saas
{
    public interface ISchemaService
    {
        string Schema { get; }
    }
}
