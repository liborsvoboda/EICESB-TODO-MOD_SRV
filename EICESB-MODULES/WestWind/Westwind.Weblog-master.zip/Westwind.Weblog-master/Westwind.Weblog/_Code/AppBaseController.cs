﻿
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Westwind.AspNetCore;
using Westwind.Web;
using Westwind.Weblog.Business.Models;

namespace Westwind.Weblog
{
    public class AppBaseController : BaseController
    {        
    }
}

