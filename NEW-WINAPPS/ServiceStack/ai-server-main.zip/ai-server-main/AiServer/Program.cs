using AiServer.ServiceInterface;

var builder = WebApplication.CreateBuilder(args);
var services = builder.Services;

services.AddServiceStack(typeof(MyServices).Assembly);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseStaticFiles();
app.MapGet("/admin/{**path}", (IWebHostEnvironment env) => 
    Results.File(env.WebRootPath.CombineWith("/admin/index.html"), "text/html"));

app.UseServiceStack(new AppHost(), options => {
    options.MapEndpoints();
});

app.Run();
