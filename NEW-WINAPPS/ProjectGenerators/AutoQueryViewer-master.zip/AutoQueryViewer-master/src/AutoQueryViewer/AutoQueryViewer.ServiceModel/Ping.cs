﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ServiceStack;

namespace AutoQueryViewer.ServiceModel
{
    [Route("/ping")]
    public class Ping {}
}