Title: Kevin Smith
Location: York, England
Email: kev_bite@msn.com
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - C#
  - Containers
  - Serverless
Blog: https://kevsoft.net/
Feed: https://kevsoft.net/feed.xml
Twitter: https://twitter.com/kev_bite
GitHub: https://github.com/kevbite
StackOverflow: https://stackoverflow.com/users/4079967/kevin-smith
LinkedIn: https://www.linkedin.com/in/kevbite/
Sessionize: https://sessionize.com/kevin-smith
MeetUp: https://www.meetup.com/members/102380092/
Mentor: true
---

