namespace PetStoreApp.PetStore
{
public enum OrderStatus {

    Placed,
    Approved,
    Delivered,
    }
}
