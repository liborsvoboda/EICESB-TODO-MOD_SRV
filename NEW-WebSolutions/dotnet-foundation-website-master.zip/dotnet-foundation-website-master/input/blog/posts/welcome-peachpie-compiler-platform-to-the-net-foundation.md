---
Title: Welcome Peachpie Compiler Platform to the .NET Foundation
Author: 
Published: 2017-07-25 17:46:00.0000000
---
<p>UPDATE: See the Peachpie team's <a href="http://www.peachpie.io/2017/07/net-foundation-announcement.html">post on joining the .NET Foundation here</a>.</p>

<p><p>Today, it’s my privilege to welcome Peachpie Compiler to the .NET Foundation.</p><p>Peachpie is an open source PHP Compiler to .NET. This innovative compiler allows you to run existing PHP applications with the performance, speed, security and interoperability of .NET.</p><p><img src="assets/posts/peachpie-possibilities.png" alt="peachpie possibilities"></p><p><a href="http://www.peachpie.io/">The Peachpie site</a> includes a lot of exciting examples, including a demonstration running WordPress on .NET with really impressive performance results. We’re excited to have them join the .NET Foundation, and look forward to supporting them!</p></p>
