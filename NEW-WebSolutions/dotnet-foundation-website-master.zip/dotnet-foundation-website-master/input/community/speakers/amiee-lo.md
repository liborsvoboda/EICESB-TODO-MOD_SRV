---
Title: Amiee Lo
Location: Seattle, Washington USA
Email: amlo@microsoft.com
Language:
  - English
Topics:
  - .NET
  - Microservices
  - Product Management
Twitter: https://twitter.com/amiee_lo
GitHub: https://github.com/amarie401
LinkedIn: https://www.linkedin.com/in/amiee-lo
Mentor: true
Mentee: true
---
Amiee is a Program Manager at Microsoft on the .NET team. She is one of the lead PMs for an open-source project - Tye, with a focus on improving and simplifying the inner-loop developer experience when building, testing, and deploying microservices and distributed applications. 
