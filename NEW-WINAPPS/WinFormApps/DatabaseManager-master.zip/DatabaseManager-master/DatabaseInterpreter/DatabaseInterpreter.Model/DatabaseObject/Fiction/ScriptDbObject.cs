﻿namespace DatabaseInterpreter.Model
{
    public class ScriptDbObject : DatabaseObject
    {
        public string Definition { get; set; }
    }
}
