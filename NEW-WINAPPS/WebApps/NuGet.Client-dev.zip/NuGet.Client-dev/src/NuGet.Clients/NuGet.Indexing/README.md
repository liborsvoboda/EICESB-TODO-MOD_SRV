NuGet's indexing library for the Visual Studio client search functionality.
