using AiServer.ServiceModel;
using ServiceStack;
using ServiceStack.Jobs;
using ServiceStack.OrmLite;
using ServiceStack.Web;

namespace AiServer.ServiceInterface;

public class GenerationServices(IBackgroundJobs jobs) : Service
{
    public async Task<object> Any(GetJobStatus request)
    {
        JobResult? job = null;
        if (request.JobId != null)
        {
            job = jobs.GetJob((long)request.JobId);
        }

        if (!string.IsNullOrEmpty(request.RefId))
        {
            job = jobs.GetJobByRefId(request.RefId);
        }
        
        if(job == null || job.Summary.RefId == null)
            throw HttpError.NotFound("Job not found");
        
        // We know at this point, we definitely have a job
        JobResult queuedJob = job;
        
        var completedResponse = new GenerationResponse
        {
            RefId = queuedJob.Job?.RefId ?? queuedJob.Summary.RefId,
            JobId = queuedJob.Job?.Id ?? queuedJob.Summary.Id,
            Status = queuedJob.Job?.Status,
            JobState = queuedJob.Job?.State ?? queuedJob.Summary.State
        };
        
        // Handle failed jobs
        if (queuedJob.Failed != null)
        {
            completedResponse.ResponseStatus = queuedJob.Failed.Error;
        }
        
        if((queuedJob.Job?.State ?? queuedJob.Summary.State) != BackgroundJobState.Completed)
            return completedResponse;
        
        // Process successful job results
        var outputs = new List<ArtifactOutput>();
        var textOutputs = new List<TextOutput>();
        var jobReqRes = queuedJob.Job!.ExtractRequestResponse<CreateGeneration, GenerationResult>();
        var jobReq = jobReqRes.Item1;
        var jobRes = jobReqRes.Item2;
        if (jobRes != null)
        {
            // Map job outputs to ArtifactOutputs
            foreach (var output in jobRes.Outputs ?? [])
            {
                outputs.Add(new ArtifactOutput
                {
                    FileName = output.FileName,
                    Url = output.Url,
                    Provider = jobReq?.Provider,
                });
            }
            completedResponse.Outputs = outputs;

            foreach (var textOutput in jobRes.TextOutputs ?? [])
            {
                textOutputs.Add(new TextOutput
                {
                    Text = textOutput.Text
                });
            }
            completedResponse.TextOutputs = textOutputs;
        }

        return completedResponse;
    }
}

public static class GenerationServiceExtensions
{
    public static async Task<object> ProcessGeneration(this QueueGenerationBase request, CreateGeneration diffRequest, IBackgroundJobs jobs,
        GenerationProviderServices genProviderServices)
    {
        CreateGenerationResponse? diffResponse = null;
        try
        {
            var response = await genProviderServices.Any(diffRequest);
            diffResponse = response as CreateGenerationResponse;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
        
        if(diffResponse == null)
            throw new Exception("Failed to start generation");
        
        var job = jobs.GetJob(diffResponse.Id);
        // For synchronous requests, wait for the job to be created
        while (job == null)
        {
            await Task.Delay(1000);
            job = jobs.GetJob(diffResponse.Id);
        }
        
        // We know at this point, we definitely have a job
        JobResult queuedJob = job;
        
        var completedResponse = new GenerationResponse
        {
            RefId = diffResponse.RefId,
            JobId = diffResponse.Id,
            Status = queuedJob.Job?.Status,
            JobState = queuedJob.Job?.State ?? queuedJob.Summary.State
        };

        // Handle failed jobs
        if (job.Failed != null)
        {
            completedResponse.ResponseStatus = job.Failed.Error;
        }
        
        // If not a synchronous request, return immediately with job details
        if (request.Sync != true)
        {
            return completedResponse;
        }
        
        // Wait for the job to complete max 1 minute
        var timeout = DateTime.UtcNow.AddMinutes(1);
        while (queuedJob?.Job?.State is not (BackgroundJobState.Completed or BackgroundJobState.Cancelled
               or BackgroundJobState.Failed) && DateTime.UtcNow < timeout)
        {
            await Task.Delay(1000);
            queuedJob = jobs.GetJob(diffResponse.Id);
        }
        
        // Process successful job results
        var outputs = new List<ArtifactOutput>();
        var textOutputs = new List<TextOutput>();
        var jobReqRes = queuedJob.Job!.ExtractRequestResponse<CreateGeneration, GenerationResult>();
        var jobReq = jobReqRes.Item1;
        var jobRes = jobReqRes.Item2;
        if (jobRes != null)
        {
            // Map job outputs to ArtifactOutputs
            foreach (var output in jobRes.Outputs ?? [])
            {
                outputs.Add(new ArtifactOutput
                {
                    FileName = output.FileName,
                    Url = output.Url,
                    Provider = jobReq?.Provider,
                });
            }
            completedResponse.Outputs = outputs;

            foreach (var textOutput in jobRes.TextOutputs ?? [])
            {
                textOutputs.Add(new TextOutput
                {
                    Text = textOutput.Text
                });
            }
            completedResponse.TextOutputs = textOutputs;
        }
        
        // Update the job state
        completedResponse.JobState = queuedJob.Job?.State ?? queuedJob.Summary.State;
        completedResponse.Status = queuedJob.Job?.Status;

        return completedResponse;
    }
}