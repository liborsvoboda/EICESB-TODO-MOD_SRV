---
title: Benjamin Day
image: ben-day.jpg
twitter: benday
location: United States
company: Benjamin Day Consulting
---

