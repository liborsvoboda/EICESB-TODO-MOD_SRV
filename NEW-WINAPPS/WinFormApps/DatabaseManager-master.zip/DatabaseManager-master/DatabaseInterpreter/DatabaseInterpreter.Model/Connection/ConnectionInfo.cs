﻿using DatabaseInterpreter.Model;

namespace DatabaseInterpreter.Model
{
    public class ConnectionInfo : DatabaseAccountInfo
    {
        public string Database { get; set; }
    }
}
