﻿namespace Convience.Filestorage.Filesystem
{
    public class FileSystemStoreOption
    {
        public string RootPath { get; set; }
    }
}
