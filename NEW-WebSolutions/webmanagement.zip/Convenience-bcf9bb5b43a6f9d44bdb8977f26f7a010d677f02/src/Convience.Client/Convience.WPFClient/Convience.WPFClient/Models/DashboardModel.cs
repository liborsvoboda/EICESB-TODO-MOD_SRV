﻿namespace Convience.WPFClient.Models
{
    public class DashboardModel
    {
        public long UserCount { get; set; }

        public long RoleCount { get; set; }

        public long DepartmentCount { get; set; }

        public long PositionCount { get; set; }
    }
}
