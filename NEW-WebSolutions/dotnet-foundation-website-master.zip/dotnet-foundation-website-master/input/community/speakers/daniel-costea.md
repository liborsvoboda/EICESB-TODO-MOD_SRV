---
Title: Daniel Costea
Location: Cluj-Napoca, Romania
Email: daniel_costea@ymail.com
Language:
  - English
Topics:
  - .NET
  - ASP.NET Web API
  - C#
  - Machine Learning
  - ML.NET
Blog: http://apexcode.ro/
Twitter: https://twitter.com/dfcostea
GitHub: https://github.com/dcostea
LinkedIn: https://www.linkedin.com/in/danielcostea/
Twitch: https://www.twitch.tv/daniel_costea_apex
Sessionize: https://sessionize.com/daniel-costea/
MeetUp: https://www.meetup.com/members/186678833/
Mentor: true
---
Microsoft MVP on Developer Technologies.
Trainer. Developer. Speaker.
1200+ hrs of training on .NET web technologies for more than 700 students, delivered in the last 5 years.
Speaker on .NET technologies at 30+ IT conferences in Europe, and the USA, in the last 3 years.
A consequent fan of C# from the year 2001.
