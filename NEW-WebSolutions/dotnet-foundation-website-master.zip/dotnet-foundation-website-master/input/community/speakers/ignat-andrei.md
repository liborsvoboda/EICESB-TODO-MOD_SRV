Title: Ignat Andrei
Location: Bucharest, Romania
Email: ignatandrei@yahoo.com
Language:
  - English 
  - Romanian
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - C#
  - Containers
  - Data
  - DevOps
  - Entity Framework
  - Microservices
  - NuGet
  - Open Source
  - SignalR
  - Visual Studio
  - Visual Studio Code
  - Web Development
  - Windows Development
  - Windows Forms
Blog: http://msprogrammer.serviciipeweb.ro/
Feed: http://msprogrammer.serviciipeweb.ro/feed/
Twitter: https://twitter.com/ignatandrei
GitHub: https://github.com/ignatandrei/
LinkedIn: https://linkedin.com/in/ignatandrei
Sessionize: https://sessionize.com/ignatandrei
MeetUp: https://www.meetup.com/Bucharest-A-D-C-E-S-Meetup/
YouTube: https://www.youtube.com/playlist?list=PL4aSKgR4yk4OnmJW6PlBuDOXdYk6zTGps
Mentor: true
---
My name is Andrei Ignat and I have 21 years programming experience. I have started from VB3 , passed via plain old ASP ,former C# Microsoft Most Valuable Professional, actual https://forums.asp.net moderator .Before that I was a teacher.

For questions book 5 minutes from my time:
https://calendly.com/ignatandrei/5min
I am also a consultant, author, speaker ,www.adces.ro community leader and www.asp.net moderator.
