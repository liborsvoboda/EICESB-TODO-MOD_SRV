﻿using ServiceStack;
using ServiceStack.DataAnnotations;

namespace AiServer.ServiceModel;

[Tag(Tag.Info)]
[ValidateApiKey]
[Description("API Providers")]
public class QueryApiProviders : QueryDb<ApiProvider>
{
    public string? Name { get; set; }
}

[Tag(Tag.Admin)]
[ValidateAuthSecret]
[Description("Add an API Provider to process AI Requests")]
[AutoPopulate(nameof(ApiProvider.CreatedDate),  Eval = "utcNow")]
public class CreateApiProvider : ICreateDb<ApiProvider>, IReturn<IdResponse>
{
    [ValidateGreaterThan(0)]
    [Input(Type = "hidden")]
    [Description("The Type of this API Provider")]
    public int ApiTypeId { get; set; }
    
    [Description("The Base URL for the API Provider")]
    public string? ApiBaseUrl { get; set; }

    [ValidateNotEmpty]
    [Description("The unique name for this API Provider")]
    public string Name { get; set; }
    
    [Input(Type = "hidden")]
    [Description("The API Key to use for this Provider")]
    public string? ApiKeyVar { get; set; }

    [Description("The API Key to use for this Provider")]
    public string? ApiKey { get; set; }

    [Input(Type = "hidden")]
    [Description("Send the API Key in the Header instead of Authorization Bearer")]
    public string? ApiKeyHeader { get; set; }
    
    [Input(Type = "hidden")]
    [Description("The URL to check if the API Provider is still online")]
    public string? HeartbeatUrl { get; set; }
    
    [Input(Type = "hidden")]
    [Description("Override API Paths for different AI Requests")]
    public Dictionary<TaskType, string>? TaskPaths { get; set; }
    
    [Input(Type = "hidden")]
    [Description("How many requests should be made concurrently")]
    public int Concurrency { get; set; }
    
    [Input(Type = "select", EvalAllowableEntries = "{ '-1':'Low', '0':'Normal', 1:'High', 2:'Highest' }")]
    [Description("What priority to give this Provider to use for processing models")]
    public int Priority { get; set; }
    
    [Description("Whether the Provider is enabled")]
    public bool Enabled { get; set; }

    [Input(Type = "hidden")]
    [Description("The models this API Provider should process")]
    public List<ApiProviderModel>? Models { get; set; }
    
    [Input(Type = "hidden")]
    [Description("The selected models this API Provider should process")]
    public List<string>? SelectedModels { get; set; }
}

[Tag(Tag.Admin)]
[ValidateAuthSecret]
public class UpdateApiProvider : IPatchDb<ApiProvider>, IReturn<IdResponse>
{
    public int Id { get; set; }
    
    [Input(Type = "hidden")]
    [Description("The Type of this API Provider")]
    public int? ApiTypeId { get; set; }
    
    [Description("The Base URL for the API Provider")]
    [Input(Type = "text", Placeholder = "e.g. http://localhost:11434")]
    public string? ApiBaseUrl { get; set; }

    [Description("The unique name for this API Provider")]
    public string? Name { get; set; }
    
    [Description("The API Key to use for this Provider")]
    public string? ApiKeyVar { get; set; }

    [Description("The API Key to use for this Provider")]
    public string? ApiKey { get; set; }

    [Description("Send the API Key in the Header instead of Authorization Bearer")]
    public string? ApiKeyHeader { get; set; }
    
    [Description("The URL to check if the API Provider is still online")]
    public string? HeartbeatUrl { get; set; }
    
    [Input(Type = "hidden")]
    [Description("Override API Paths for different AI Requests")]
    public Dictionary<TaskType, string>? TaskPaths { get; set; }
    
    [Description("How many requests should be made concurrently")]
    public int? Concurrency { get; set; }
    
    [Input(Type = "select", EvalAllowableEntries = "{ '-1':'Low', '0':'Normal', 1:'High', 2:'Highest' }")]
    [Description("What priority to give this Provider to use for processing models")]
    public int? Priority { get; set; }
    
    [Description("Whether the Provider is enabled")]
    public bool? Enabled { get; set; }

    [Input(Type = "hidden")]
    [Description("The models this API Provider should process")]
    public List<ApiProviderModel>? Models { get; set; }
    
    [Input(Type = "hidden")]
    [Description("The selected models this API Provider should process")]
    public List<string>? SelectedModels { get; set; }
}

[Tag(Tag.Admin)]
[ValidateApiKey]
[Description("Delete API Provider")]
public class DeleteApiProvider : IDeleteDb<ApiProvider>, IReturnVoid
{
    public int Id { get; set; }
}

[Tag(Tag.Info)]
[ValidateApiKey]
[Description("Active Worker Models available in AI Server")]
public class ActiveAiModels : IGet, IReturn<StringsResponse> {}

[Tag(Tag.Info)]
[ValidateApiKey]
[Description("Different Models available in AI Server")]
public class QueryApiModels : QueryDb<AiModel> {}

[Tag(Tag.Admin)]
[ValidateAuthSecret]
[Description("Different Models available for the API")]
public class CreateApiModel : ICreateDb<AiModel>, IReturn<IdResponse>
{
    public string Name { get; set; }
    public string? Website { get; set; }
    [Input(Type = "tag")]
    public List<string> Tags { get; set; } = [];
    public string? Latest { get; set; }
    [Input(Type = "textarea"), FieldCss(Field = "col-span-12")]
    public string? Description { get; set; }
    public string? Icon { get; set; }
}

[Tag(Tag.Admin)]
[ValidateAuthSecret]
public class UpdateApiModel : IPatchDb<AiModel>, IReturn<IdResponse>
{
    public string Name { get; set; }
    public string? Website { get; set; }
    [Input(Type = "tag")]
    public List<string> Tags { get; set; } = [];
    public string? Latest { get; set; }
    [Input(Type = "textarea"), FieldCss(Field = "col-span-12")]
    public string? Description { get; set; }
    public string? Icon { get; set; }
}

[Tag(Tag.Info)]
[ValidateApiKey]
[Description("The Type and behavior of different API Providers")]
public class QueryApiTypes : QueryDb<ApiType> {}

public class AdminData : IGet, IReturn<AdminDataResponse> {}

public class PageStats
{
    public string Label { get; set; }
    public int Total { get; set; }
}

public class AdminDataResponse
{
    public List<PageStats> PageStats { get; set; }
}