﻿namespace ImperiumApp.Imperium
{
    public class ImperiumModule : ImperiumModuleBase
    {
        public ImperiumModule(IImperiumService imperiumService) : base(imperiumService)
        {
        }
    }
}
