---
Title: Javier Suarez
Location: Sevilla, Spain
Email: javiersuarezruiz@hotmail.com
Language:
  - English
  - Spanish
Topics:
  - .NET
  - Android
  - iOS
  - Mobile Development
  - Windows Development
  - Xamarin
  - Xamarin.Forms
Blog: https://javiersuarezruiz.wordpress.com
Feed: feed:https://javiersuarezruiz.wordpress.com/feed/
Twitter: https://twitter.com/jsuarezruiz
GitHub: https://github.com/jsuarezruiz
LinkedIn: https://www.linkedin.com/in/jsuarezruiz/
YouTube: https://www.youtube.com/user/javiersuarezruiz
---
Hi! I'm Javier, and I write code for tech project around the world. I’m currently a software engineer at Microsoft working on Xamarin.Forms, and have worked with the likes of WPF, UWP, Xamarin, Azure, and others over the years.

When I’m not actively writing code, you’ll probably find me making content for my blog . 

In the end, I'm just a guy who loves what he does, and who enjoys sharing and helping others grow, share good times, and learn together.
