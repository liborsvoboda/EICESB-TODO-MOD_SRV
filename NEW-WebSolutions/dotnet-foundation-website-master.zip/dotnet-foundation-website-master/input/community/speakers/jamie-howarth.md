---
Title: Jamie Howarth
Location: Bath, UK
Email: hello@jamiehowarth.me
Language:
  - English
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - Blazor
  - C#
  - Diversity & Inclusion
  - NuGet
  - Open Source
Blog: https://jamiehowarth.me
Twitter: https://twitter.com/jamiehowarth0
GitHub: https://github.com/jamiehowarth0
StackOverflow: https://stackoverflow.com/users/418297/jamie-howarth
LinkedIn: https://www.linkedin.com/in/jamiehowarth0/
MeetUp: https://www.meetup.com/members/11432187/
YouTube: https://www.youtube.com/channel/UCX6yoi4POq0KAHFXKC2Jjdg
Instagram: https://instagram.com/jamiehowarth0
Mentor: true
---

