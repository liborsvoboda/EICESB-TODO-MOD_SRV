cd "$PSScriptRoot"  

copy-item .\scripts .\github -Force -Recurse
copy-item .\scripts .\msdn  -Force -Recurse
copy-item .\scripts .\darkhan -Force -Recurse
copy-item .\scripts .\darkhan_noframes -Force -Recurse
copy-item .\scripts .\msword -Force -Recurse