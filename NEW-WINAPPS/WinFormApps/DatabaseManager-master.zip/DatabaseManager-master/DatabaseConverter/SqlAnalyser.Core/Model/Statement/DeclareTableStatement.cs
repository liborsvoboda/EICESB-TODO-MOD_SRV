﻿namespace SqlAnalyser.Model
{
    public class DeclareTableStatement : Statement
    {
        public TableInfo TableInfo { get; set; }
    }   
}
