---
Title: "Channel 9 Interview: .NET Open Source Initiative"
Author: 
Published: 2015-05-04 16:03:00.0000000
---
<p>At BUILD some of the .NET Foundation team members were interviewed on Channel 9.</p>

<p>Check out the interview here: <a href="http://channel9.msdn.com/Events/Build/2015/C9-15">.NET Open Source Initiative</a></p>

<p><iframe width="640" height="360" frameborder="0" allowfullscreen="allowfullscreen" src="//channel9.msdn.com/Events/Build/2015/C9-15/player"></iframe></p>

<p><a href="http://twitter.com/jayschmelzer" target="_blank">Jay Schmelzer</a>, <a href="https://github.com/terrajobst" target="_blank">Immo Landwerth</a>, <a href="https://github.com/martinwoodward" target="_blank">Martin Woodward</a>&nbsp;and I chatted about what the .NET Foundation is, why we need it, and what it can do for the .NET ecosystem. Jay is the President of the .NET Foundation, Immo is on the Advisory Council and project lead for CoreFx and Martin is the Executive Director of the .NET Foundation. I&rsquo;m officially the Secretary but I rather call myself Technical Evangelist :-).</p>

<p><a href="/about/board-of-directors">Meet the rest of the people behind the .NET Foundation</a>&nbsp;and <a href="http://forums.dotnetfoundation.org">join the conversations in our forums</a>.</p>

<p>Enjoy,</p>

<p>-<a href="https://twitter.com/BethMassi">Beth Massi</a>, Technical Evangelist .NET Foundation</p>
