﻿namespace DatabaseConverter.Core.Model.Functions
{
    public struct DateExtract
    {
        public string Unit { get; set; }
        public string Date { get; set; } 
    }
}
