﻿namespace DatabaseInterpreter.Geometry
{
    public struct PostgresGeometryCustomInfo
    {
        public bool IsGeography { get; set; }
    }
}
