﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TwainDotNet.TwainNative
{
    class TwainConstants
    {
        public const short ProtocolMajor = 1;
        public const short ProtocolMinor = 9;
    }
}
