﻿using System.Collections.Generic;

namespace DatabaseInterpreter.Model
{
    public class CreateTableOption
    {
        public List<string> Items { get; set; }
    }
}
