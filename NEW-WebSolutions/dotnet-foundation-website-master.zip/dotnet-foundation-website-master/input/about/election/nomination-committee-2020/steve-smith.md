---
title: Steve (Ardalis) Smith
image: steve-smith.jpg
twitter: ardalis
location: United States
company: Ardalis Services
---

