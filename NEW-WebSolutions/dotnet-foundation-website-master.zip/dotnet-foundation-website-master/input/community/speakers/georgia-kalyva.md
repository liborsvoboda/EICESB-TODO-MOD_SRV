Title: Georgia Kalyva
Location: Athens, Greece
Email: georgia.kalyva@outlook.com
Language:
  - English
  - Greek
Topics:
  - .NET
  - ASP.NET Web API
  - Artificial Intelligence
  - Azure
  - C#
  - Machine Learning
Blog: https://codestories.gr/
Feed: https://codestories.gr/index.php/feed
Twitter: https://twitter.com/georgiakalyva
GitHub: https://github.com/georgiakalyva/
StackOverflow: https://stackoverflow.com/users/5575847/georgia-kalyva
LinkedIn: https://www.linkedin.com/in/georgiakalyva/
Sessionize: https://sessionize.com/georgiakalyva
MeetUp: https://www.meetup.com/members/200368776/
YouTube: https://www.youtube.com/channel/UCRqeLEhnEjYiRwhjwOmVXDg
Mentor: true
---
Georgia Kalyva has graduated from the University of Piraeus, is a Microsoft AI MVP with years of experience in software engineering and is currently working for ITT as Web Applications Developer. She is passionate about AI and Azure and has represented Greece in global competitions in Technology and Entrepreneurship. She is a member of the Microsoft Lean Ambassadors team and has taken over the role of mentor in several Microsoft competitions and trainings. 
