This project bases on [ICSharpCode.TextEditorEx](https://github.com/StefH/ICSharpCode.TextEditorEx) and [ICSharpCode.TextEditor](https://github.com/netsparker/ICSharpCode.TextEditor
), and make some changes to adjust for sql syntax highlighting.
