import { Vue } from 'vue-property-decorator';
export declare class ErrorSummary extends Vue {
    responseStatus: object;
    except: string;
    readonly errorSummary: any;
}
export default ErrorSummary;
