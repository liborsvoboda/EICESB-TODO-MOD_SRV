﻿namespace Convience.MongoDB
{
    public class MongoOption
    {
        public string MongoHost { get; set; }

        public string DefaultDataBase { get; set; }
    }


}
