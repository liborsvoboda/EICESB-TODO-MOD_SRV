﻿using System;
using System.Collections.Generic;
using System.Text;
using DatabaseInterpreter.Model;

namespace DatabaseManager.Model
{
    public class TableDesignerInfo : Table
    {
        public string OldName { get; set; }
    }
}
