Title: Juliano Custódio
Location: São Paulo, Brazil
Email: juliano.custodio@hotmail.com.br
Language:
  - Portuguese
Topics:
  - .NET
  - Azure
  - C#
  - DevOps
  - Mobile Development
  - Visual Studio
  - Xamarin
  - Xamarin.Forms
Blog: https://julianocustodio.com
Feed: https://julianocustodio.com/feed/
Twitter: https://twitter.com/juucustodio
GitHub: https://github.com/juucustodio
Instagram: https://instagram.com/juucustodio
Mentor: true
---
Microsoft MVP
