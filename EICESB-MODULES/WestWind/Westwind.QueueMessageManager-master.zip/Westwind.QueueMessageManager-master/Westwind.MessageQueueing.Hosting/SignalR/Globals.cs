
using Westwind.MessageQueueing;

namespace Westwind.MessageQueueing.Hosting
{
    public static class Globals
    {
        public static QueueControllerMultiple Controller;        
    }
}
