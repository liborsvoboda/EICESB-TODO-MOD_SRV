export class Article {
    id?: number;
    title?: string;
    subTitle?: string;
    columnId?: number;
    columnName?: string;
    source?: string;
    sort?: number;
    tags?: string;
    content?: string;
}