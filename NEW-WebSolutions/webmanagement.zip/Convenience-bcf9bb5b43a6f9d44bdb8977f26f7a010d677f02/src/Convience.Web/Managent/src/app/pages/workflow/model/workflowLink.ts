export class WorkflowLink {

    sourceId?: string;

    targetId?: string;

    connection?: string;
}