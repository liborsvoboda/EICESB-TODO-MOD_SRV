---
title: Brendan Forster
order: 2
image: brendan-forster.jpg
twitter: shiftkey
company: Staff Software Engineer at GitHub
location: Canada
advisor: true
---

Frequent .NET open source contributor.
