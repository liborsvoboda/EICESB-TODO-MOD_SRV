[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.InteropServices.Guid("c6eb693e-64d1-4271-be68-0b78d186003e")]
[assembly: System.Reflection.AssemblyVersion("6.0.0.0")]
