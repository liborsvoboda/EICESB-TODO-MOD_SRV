NuGet Command Line Interface.
