Title: Jung Hyun, Nam
Location: Seoul, Republic of Korea
Email: rkttu@rkttu.com
Language:
  - Korean
Topics:
  - .NET
  - ASP.NET
  - Azure
  - C#
  - Containers
  - DevOps
  - Microservices
  - NuGet
  - Open Source
  - Windows Forms
Blog: https://medium.com/@rkttu
Feed: https://medium.com/feed/@rkttu
Twitter: https://www.twitter.com/rkttu
GitHub: https://www.github.com/rkttu
StackOverflow: https://stackoverflow.com/users/3880976/jeong-hyun-nam
LinkedIn: https://www.linkedin.com/in/jeonghyun-nam/
MeetUp: https://www.meetup.com/ko-KR/members/222556985/
Dev: https://dev.to/rkttu
Mentor: true
---

### Jung Hyun, Nam - Technical Writer & Software Developer

```text
 █████   █████          ████  ████                   █████    █████                                  ███
░░███   ░░███          ░░███ ░░███                  ░░███    ░░███                                  ░███
 ░███    ░███   ██████  ░███  ░███   ██████         ███████   ░███████    ██████  ████████   ██████ ░███
 ░███████████  ███░░███ ░███  ░███  ███░░███       ░░░███░    ░███░░███  ███░░███░░███░░███ ███░░███░███
 ░███░░░░░███ ░███████  ░███  ░███ ░███ ░███         ░███     ░███ ░███ ░███████  ░███ ░░░ ░███████ ░███
 ░███    ░███ ░███░░░   ░███  ░███ ░███ ░███         ░███ ███ ░███ ░███ ░███░░░   ░███     ░███░░░  ░░░ 
 █████   █████░░██████  █████ █████░░██████   ██     ░░█████  ████ █████░░██████  █████    ░░██████  ███
░░░░░   ░░░░░  ░░░░░░  ░░░░░ ░░░░░  ░░░░░░   ██       ░░░░░  ░░░░ ░░░░░  ░░░░░░  ░░░░░      ░░░░░░  ░░░ 
```

👋 Nice to see you!

#### Summary

- I'm living in Seoul, S. Korea
- I'm interested in C#, .NET, Windows Container, Microsoft Azure
- I’m currently working on [DEVSISTERS](https://github.com/devsisters)
- I’m currently learning technical writing and communication.
- How to reach me: rkttu at rkttu dot com

#### My Profile

- [Microsoft MVP since 2009](https://mvp.microsoft.com/en-us/PublicProfile/4024633)
- [LinkedIn](https://www.linkedin.com/in/jeonghyun-nam/)

#### My Footsteps on the Web

- [Beyond Windows, English Edition](https://medium.com/rkttu)
- [Beyond Windows, Korean Edition](https://medium.com/beyond-the-windows-korean-edition)
- [DEVSISTERS Tech Blog, Korean](https://tech.devsisters.com)
