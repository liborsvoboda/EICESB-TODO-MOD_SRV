using ServiceStack;
using ServiceStack.DataAnnotations;
using ServiceStack.Jobs;

namespace AiServer.ServiceModel;

[ValidateApiKey]
[Tag("AI")]
[Api("Convert speech to text")]
[Description("Transcribe audio content to text")]
public class SpeechToText : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "The audio stream containing the speech to be transcribed", ParameterType = "body")]
    [Description("The audio stream containing the speech to be transcribed")]
    [Required]
    [Input(Type = "file")]
    public Stream Speech { get; set; }
}

[ValidateApiKey]
[Tag("AI")]
[Api("Convert text to speech")]
[Description("Generate speech audio from text input")]
public class TextToSpeech : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "The text to be converted to speech", ParameterType = "body")]
    [Description("The text to be converted to speech")]
    [Required]
    public string Text { get; set; }

    [ApiMember(Description = "Optional seed for reproducible results in speech generation", ParameterType = "query")]
    [Description("Optional seed for reproducible results in speech generation")]
    [Range(0, int.MaxValue)]
    public int? Seed { get; set; }
}

[ValidateApiKey]
[Tag("AI")]
[Api("Generate image from text description")]
[Description("Create an image based on a text prompt")]
public class TextToImage : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "The main prompt describing the desired image", ParameterType = "body")]
    [Description("The main prompt describing the desired image")]
    [ValidateNotEmpty]
    [Input(Type = "textarea")]
    public string PositivePrompt { get; set; }

    [ApiMember(Description = "Optional prompt specifying what should not be in the image", ParameterType = "body")]
    [Description("Optional prompt specifying what should not be in the image")]
    [Input(Type = "textarea")]
    public string? NegativePrompt { get; set; }

    [ApiMember(Description = "Desired width of the generated image", ParameterType = "query")]
    [Description("Desired width of the generated image")]
    [Range(64, 2048)]
    public int? Width { get; set; }

    [ApiMember(Description = "Desired height of the generated image", ParameterType = "query")]
    [Description("Desired height of the generated image")]
    [Range(64, 2048)]
    public int? Height { get; set; }

    [ApiMember(Description = "Number of images to generate in a single batch", ParameterType = "query")]
    [Description("Number of images to generate in a single batch")]
    [Range(1, 10)]
    public int? BatchSize { get; set; }

    [ApiMember(Description = "The AI model to use for image generation", ParameterType = "query")]
    [Description("The AI model to use for image generation")]
    public string? Model { get; set; }

    [ApiMember(Description = "Optional seed for reproducible results", ParameterType = "query")]
    [Description("Optional seed for reproducible results")]
    [Range(0, int.MaxValue)]
    public int? Seed { get; set; }
}

[ValidateApiKey]
[Tag("AI")]
[Api("Generate image from another image")]
[Description("Create a new image based on an existing image and a text prompt")]
public class ImageToImage : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "The image to use as input", ParameterType = "body")]
    [Description("The image to use as input")]
    [Required]
    [Input(Type = "file")]
    public Stream Image { get; set; }

    [ApiMember(Description = "Prompt describing the desired output", ParameterType = "body")]
    [Description("Prompt describing the desired output")]
    [ValidateNotEmpty]
    [Input(Type = "textarea")]
    public string PositivePrompt { get; set; }

    [ApiMember(Description = "Negative prompt describing what should not be in the image", ParameterType = "body")]
    [Description("Negative prompt describing what should not be in the image")]
    [Input(Type = "textarea")]
    public string? NegativePrompt { get; set; }

    [ApiMember(Description = "Optional specific amount of denoise to apply", ParameterType = "query")]
    [Description("Optional specific amount of denoise to apply")]
    [Range(0, 1)]
    public float? Denoise { get; set; }

    [ApiMember(Description = "Number of images to generate in a single batch", ParameterType = "query")]
    [Description("Number of images to generate in a single batch")]
    [Range(1, 10)]
    public int? BatchSize { get; set; }

    [ApiMember(Description = "Optional seed for reproducible results in image generation", ParameterType = "query")]
    [Description("Optional seed for reproducible results in image generation")]
    [Range(0, int.MaxValue)]
    public int? Seed { get; set; }
}

[ValidateApiKey]
[Tag("AI")]
[Api("Upscale an image")]
[Description("Increase the resolution and quality of an input image")]
public class ImageUpscale : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "The image to upscale", ParameterType = "body")]
    [Description("The image to upscale")]
    [Required]
    [Input(Type = "file")]
    public Stream Image { get; set; }

    [ApiMember(Description = "Optional seed for reproducible results in image generation", ParameterType = "query")]
    [Description("Optional seed for reproducible results in image generation")]
    [Range(0, int.MaxValue)]
    public int? Seed { get; set; }
}

[ValidateApiKey]
[Tag("AI")]
[Api("Generate image with masked area")]
[Description("Create a new image by applying a mask to an existing image and generating content for the masked area")]
public class ImageWithMask : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "Prompt describing the desired output in the masked area", ParameterType = "body")]
    [Description("Prompt describing the desired output in the masked area")]
    [ValidateNotEmpty]
    [Input(Type = "textarea")]
    public string PositivePrompt { get; set; }

    [ApiMember(Description = "Negative prompt describing what should not be in the masked area", ParameterType = "body")]
    [Description("Negative prompt describing what should not be in the masked area")]
    [Input(Type = "textarea")]
    public string? NegativePrompt { get; set; }

    [ApiMember(Description = "The image to use as input", ParameterType = "body")]
    [Description("The image to use as input")]
    [Required]
    [Input(Type = "file")]
    public Stream Image { get; set; }

    [ApiMember(Description = "The mask to use as input", ParameterType = "body")]
    [Description("The mask to use as input")]
    [Required]
    [Input(Type = "file")]
    public Stream Mask { get; set; }

    [ApiMember(Description = "Optional specific amount of denoise to apply", ParameterType = "query")]
    [Description("Optional specific amount of denoise to apply")]
    [Range(0, 1)]
    public float? Denoise { get; set; }

    [ApiMember(Description = "Optional seed for reproducible results in image generation", ParameterType = "query")]
    [Description("Optional seed for reproducible results in image generation")]
    [Range(0, int.MaxValue)]
    public int? Seed { get; set; }
}

[ValidateApiKey]
[Tag("AI")]
[Api("Convert image to text")]
[Description("Extract text content from an image")]
public class ImageToText : QueueGenerationBase, IReturn<GenerationResponse>
{
    [ApiMember(Description = "The image to convert to text", ParameterType = "body")]
    [Description("The image to convert to text")]
    [Required]
    [Input(Type = "file")]
    public Stream Image { get; set; }
}

[Description("Base class for queue generation requests")]
public class QueueGenerationBase
{
    [ApiMember(Description = "Optional client-provided identifier for the request", ParameterType = "query")]
    [Description("Optional client-provided identifier for the request")]
    public string? RefId { get; set; }

    [ApiMember(Description = "Optional queue or topic to reply to", ParameterType = "query")]
    [Description("Optional queue or topic to reply to")]
    public string? ReplyTo { get; set; }

    [ApiMember(Description = "If true, wait for the generation to complete before responding", ParameterType = "query")]
    [Description("If true, wait for the generation to complete before responding")]
    public bool? Sync { get; set; }

    [ApiMember(Description = "Optional state to associate with the request", ParameterType = "query")]
    [Description("Optional state to associate with the request")]
    [Input(Type = "hidden")]
    public string? State { get; set; }
}

[ValidateApiKey]
[Tag(Tag.Jobs)]
[Api("Get job status")]
[Description("Retrieve the status of a background job")]
public class GetJobStatus : IReturn<GenerationResponse>
{
    [ApiMember(Description = "Unique identifier of the background job", ParameterType = "query")]
    [Description("Unique identifier of the background job")]
    public long? JobId { get; set; }

    [ApiMember(Description = "Client-provided identifier for the request", ParameterType = "query")]
    [Description("Client-provided identifier for the request")]
    public string? RefId { get; set; }
}

[Description("Response object for generation requests")]
public class GenerationResponse
{
    [ApiMember(Description = "Unique identifier of the background job")]
    [Description("Unique identifier of the background job")]
    public long JobId { get; set; }

    [ApiMember(Description = "Client-provided identifier for the request")]
    [Description("Client-provided identifier for the request")]
    public string RefId { get; set; }

    [ApiMember(Description = "Current state of the background job")]
    [Description("Current state of the background job")]
    public BackgroundJobState JobState { get; set; }

    [ApiMember(Description = "Current status of the generation request")]
    [Description("Current status of the generation request")]
    public string? Status { get; set; }

    [ApiMember(Description = "List of generated outputs")]
    [Description("List of generated outputs")]
    public List<ArtifactOutput>? Outputs { get; set; }

    [ApiMember(Description = "List of generated text outputs")]
    [Description("List of generated text outputs")]
    public List<TextOutput>? TextOutputs { get; set; }

    [ApiMember(Description = "Detailed response status information")]
    [Description("Detailed response status information")]
    public ResponseStatus? ResponseStatus { get; set; }
}

[Description("Output object for generated artifacts")]
public class ArtifactOutput
{
    [ApiMember(Description = "URL to access the generated image")]
    [Description("URL to access the generated image")]
    public string? Url { get; set; }

    [ApiMember(Description = "Filename of the generated image")]
    [Description("Filename of the generated image")]
    public string? FileName { get; set; }

    [ApiMember(Description = "Provider used for image generation")]
    [Description("Provider used for image generation")]
    public string? Provider { get; set; }
}

[Description("Output object for generated text")]
public class TextOutput
{
    [ApiMember(Description = "The generated text")]
    [Description("The generated text")]
    public string? Text { get; set; }
}