﻿namespace Convience.WPFClient.Models
{
    public class CaptchaModel
    {
        public string CaptchaKey { get; set; }

        public string CaptchaData { get; set; }
    }
}
