---
Title: Jon Sequeira
Location: Seattle, Washington USA
Email: josequ@microsoft.com
Language:
  - English
Topics:
  - .NET
  - Architecture
  - C#
  - DevOps
  - Human Skills
  - Microservices
  - Web Development
Twitter: https://twitter.com/jonsequitur
GitHub: https://github.com/jonsequitur
---


