﻿
namespace NuGetGallery.Operations
{
    public enum Verbosity
    {
        Normal,
        Quiet,
        Detailed
    }
}
