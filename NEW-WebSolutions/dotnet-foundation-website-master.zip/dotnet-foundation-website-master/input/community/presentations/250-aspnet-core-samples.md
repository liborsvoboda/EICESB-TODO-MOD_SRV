﻿---
type: tutorial
id: 250-aspnet-core-samples
title: 250+ ASP.NET Core Samples
repo: dodyg/practical-aspnetcore
link: https://github.com/dodyg/practical-aspnetcore
---

Dody has built an amazing collection of over 180 code samples for ASP.NET Core 2.1, 2.2, and 3.0 fundamentals. These are really focused samples that are quick to set up and run, and he keeps them really up to date.