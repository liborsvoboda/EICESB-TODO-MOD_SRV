cd .\Westwind.Webstore.Web
dotnet watch run --no-hot-reload