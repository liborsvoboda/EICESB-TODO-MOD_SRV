export class DicData {
    id?: number;
    dicTypeId?:number;
    name?: string;
    sort?: number;    
}