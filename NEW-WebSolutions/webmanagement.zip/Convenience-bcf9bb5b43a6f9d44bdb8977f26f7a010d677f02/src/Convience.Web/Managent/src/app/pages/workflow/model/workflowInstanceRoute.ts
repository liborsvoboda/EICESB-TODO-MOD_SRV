export class WorkflowInstanceRoute {
    id?: string;
    nodeId?: string;
    nodeName?: string;
    handlePeopleName?: string;
    handlePepleAccount?: string;
    handleComment?: string;
    handleState?: number;
    handleTime?: string;
}