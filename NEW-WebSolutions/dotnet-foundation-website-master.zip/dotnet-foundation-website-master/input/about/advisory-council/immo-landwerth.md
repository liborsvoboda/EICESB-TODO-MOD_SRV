---
title: Immo Landwerth
image: immo-landwerth.jpg
order: 2
twitter: terrajobst
location: United States
company: Program Manager at Microsoft
advisor: true
---

Helping lead open source initiatives.
