﻿namespace SideBySideExplorer.Model
{
    public enum FileMoveMode
    {
        None=0,
        Drag = 1,
        Cut = 2,
        Copy =3
    }
}
