Title: Haitham Shaddad
Location: Sydney, Australia
Email: haitham.shaddad@outlook.com
Language:
  - English
  - Arabic
Topics:
  - .NET
  - ASP.NET
  - ASP.NET MVC
  - ASP.NET Web API
  - Azure
  - C#
  - Containers
  - Entity Framework
  - Microservices
  - Serverless
  - SignalR
Blog: https://haithamshaddad.com/
Twitter: https://twitter.com/haitham_shaddad
GitHub: https://github.com/haitham-shaddad/
StackOverflow: https://stackoverflow.com/users/2156200/haitham-shaddad
LinkedIn: https://www.linkedin.com/in/haitham-shaddad-82668924/
Sessionize: https://sessionize.com/haitham-shaddad/
MeetUp: https://www.meetup.com/members/200138928/
YouTube: https://youtube.com/haithamshaddad
---
Hi, I work at WooliesX as a Technology Lead. I do a lot of microservices, DDD on Azure and I love talking about dot net and Azure and presenting exciting and interesting demos.
