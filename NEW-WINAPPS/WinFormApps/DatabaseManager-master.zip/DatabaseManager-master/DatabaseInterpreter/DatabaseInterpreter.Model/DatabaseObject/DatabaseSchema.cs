﻿namespace DatabaseInterpreter.Model
{
    public class DatabaseSchema : DatabaseObject
    {

    }
}
