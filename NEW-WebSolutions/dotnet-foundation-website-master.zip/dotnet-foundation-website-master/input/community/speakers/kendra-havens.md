---
Title: Kendra Havens
Location: Seattle, Washington USA and part-time Los Angeles, California USA
Email: kehavens@microsoft.com
Language:
  - English
Topics:
  - .NET
  - C#
  - Visual Studio
Twitter: https://twitter.com/gotheap
GitHub: https://github.com/kendrahavens
LinkedIn: https://www.linkedin.com/in/kendrahavens
---

