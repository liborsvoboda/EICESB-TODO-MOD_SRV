﻿namespace SqlAnalyser.Model
{
    public class ContinueStatement : Statement
    {

    }
}
