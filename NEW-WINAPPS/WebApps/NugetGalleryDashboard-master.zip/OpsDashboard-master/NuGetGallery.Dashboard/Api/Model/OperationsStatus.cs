﻿namespace NuGetGallery.Dashboard.Api.Model
{
    public class OperationsStatus
    {

    }
}