﻿namespace SqlAnalyser.Model
{
    public class ReturnStatement : Statement
    {
        public TokenInfo Value { get; set; }
    }
}
