﻿using System;

namespace DatabaseInterpreter.Model
{
    public class DataTableColumnChangeInfo
    {
        public Type Type { get; set; }
        public int? MaxLength { get; set; }
    }
}
