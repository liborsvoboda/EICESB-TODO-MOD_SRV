﻿
### This is Embedded Markdown from a File
This is embedded Markdown that is loaded into the page **from an external Markdown file** (`~/EmbeddedMarkdownFile.md`) using the `Filename` property on the `<markdown>` control.

This allows you to edit markdown in an external Markdown editor and keep it without having to paste the Markdown into a Markdown control.


