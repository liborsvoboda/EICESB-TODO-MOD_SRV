﻿---
type: tutorial
id: aspnet-core-a-z-e-book
title: ASP.NET Core A-Z e-book
link: https://wakeupandcode.com/release-asp-net-core-a-z-ebook/
---

This is a great way to learn ASP.NET Core key concepts, with A-Z deep dives on important concepts and features from “Authentication & Authorization” to “Zero-Downtime Web Apps”.